# Reproducibility package

Source code accompanying the manuscript

> **Structure-preserving precise integration for superconducting electrodynamics:
> from Maxwell–London to Ginzburg–Landau**

Every figure and every number of the manuscript is produced by the scripts in
`code/`.  No external data files are required and the drivers are
self-contained: running them from scratch regenerates the results shipped in
`figures/` and `results/` here (see the reproducibility notes below).

## Contents

```
code/       the six Python modules listed below
figures/    reference output: the figure files used in the manuscript (png + pdf)
results/    reference output: results.json and the console logs of the two drivers
```

| File | What it contains |
|---|---|
| `code/scph.py` | Library. Discrete de Rham (Yee) complexes in 1D/2D/3D, the port-Hamiltonian Maxwell–London two-fluid model (uniform and non-uniform materials), precise integration and Strang–Yoshida splittings, the matrix-free 3D Yee operator, the Krylov exponential with metric (M-inner-product) variants, the reduced Ginzburg–Landau-type IMEX model, and the gauge-invariant TDGL discretization on the torus. |
| `code/run_experiments.py` | The thirteen numerical experiments E1–E13 and all data figures of the manuscript. |
| `code/check_theory.py` | Thirty-one groups of independent consistency checks of the theoretical statements (residual levels, structure identities, convergence orders). Writes no files; its printed residuals are the ones quoted in the text. |
| `code/bench_compare.py` | Exponential action computed by four different realizations on the non-uniform two-fluid model (Table 1). |
| `code/make_setup_1d.py` | Schematic of the 1D driven-boundary Meissner test case (Fig. 5). |
| `code/make_setup_2d.py` | Schematic of the 2D non-uniform two-fluid test case (Fig. 9). |

The two remaining schematics of the manuscript (Fig. 11, Fig. 14) are drawings
that were prepared separately; they are shipped as reference files in
`figures/` but their drawing scripts are not part of this package.

## Requirements

Python ≥ 3.9 with `numpy`, `scipy` and `matplotlib` (see `requirements.txt`).
Tested with Python 3.11.9, numpy 2.4.6, scipy 1.17.1 and matplotlib 3.11.2
on Windows 11, single core.  Peak memory is ≈ 1–2 GB, reached in the
matrix-free experiment E10, where the Krylov basis at n = 1.57×10⁶ alone is
0.4 GB.

```
pip install -r requirements.txt
```

## How to run

```
python code/check_theory.py       # ~3 s    : 31 groups of checks, prints residuals
python code/run_experiments.py    # ~2 min  : E1-E13, writes figures/ and results/
python code/bench_compare.py      # ~1 min  : Table 1
python code/make_setup_1d.py      # instant : Fig. 5 schematic
python code/make_setup_2d.py      # instant : Fig. 9 schematic
```

`run_experiments.py` prints one block per experiment with the numbers it
writes into `results/results.json`, so a single run reproduces both the
figures and the values collected in Table 2 and Table 3.  The drivers write
into the `figures/` and `results/` directories **next to** the `code/`
directory, i.e. into this package, overwriting the reference copies shipped
here.

## Reproducibility notes

* All experiments are deterministic: every random seed is fixed inside the
  scripts, so a fresh run reproduces the entries of `results/results.json`
  exactly.  The only exception is the wall-clock cost, which depends on the
  machine and on its load: the entries `E1_cost`, `E10_a/matvec_us`,
  `E10_a/sparse_us`, `E10_a/step_s`, `E10_a_slope`, `E10_a_note` and the
  `wall` columns of `E10_c`.  They scatter by up to a factor of two between
  runs, which is the caveat stated in the caption of Table 3; the timing
  panel (a) of Fig. 7 is the only plot affected by this.
* `results/results.json` and the two `.log` files are the verbatim output of
  one complete run of the code in this package (all thirteen experiments plus
  the 31 groups of theory checks).  `figures/` holds the figure files as they
  are included in the manuscript.  A full run takes about two minutes on a
  single core, E10 and E12 dominating the cost.

## Mapping from the manuscript to the code

| Manuscript item | File(s) in `figures/` | Produced by |
|---|---|---|
| Fig. 1 | `fig4_penetration.png` | `run_experiments.py` (E4) |
| Fig. 2 | `fig1_accuracy.png` | `run_experiments.py` (E1) |
| Fig. 3 | `fig2_longterm_energy.png` | `run_experiments.py` (E2) |
| Fig. 4 | `fig3_poynting_dissipation.png` | `run_experiments.py` (E3) |
| Fig. 5 | `fig_setup_1d.pdf` | `make_setup_1d.py` |
| Fig. 6 | `fig5_dispersion.png`, `fig6_cfl_pi.png`, `fig6_cfl_fdtd.png` | `run_experiments.py` (E5, E6) |
| Fig. 7 | `fig9_scalability.png` | `run_experiments.py` (E10) |
| Fig. 8 | `fig7_2d_maxwell.png` | `run_experiments.py` (E7) |
| Fig. 9 | `fig_setup_2d.pdf` | `make_setup_2d.py` |
| Fig. 10 | `fig10_meissner.png` | `run_experiments.py` (E11) |
| Fig. 11 | `fig_setup_3d.png` | separate drawing (see above) |
| Fig. 12 | `fig11_absorption.png` | `run_experiments.py` (E12) |
| Fig. 13 | `fig8_tdgl.png` | `run_experiments.py` (E8) |
| Fig. 14 | `fig_setup_tdgl.png` | separate drawing (see above) |
| Fig. 15 | `fig12_vortices.png` | `run_experiments.py` (E13) |
| Table 1 | — | `bench_compare.py` |
| Table 2 | — | `run_experiments.py` (E1–E13), `check_theory.py` |
| Table 3 | — | `run_experiments.py` (E10) |

## Experiments of `run_experiments.py`

| # | Content | Manuscript |
|---|---|---|
| E1 | Accuracy of the time integrators at a fixed physical time (PI-Ex, SPI-2, SPI-4, FDTD, RK4) | Fig. 2, Table 2 |
| E2 | Long-term energy conservation (10⁵ steps, ≈1.7×10³ mode periods) | Fig. 3 |
| E3 | Discrete Poynting audit, dissipation rate and quality factor | Fig. 4 |
| E4 | Driven wall: Meissner screening, penetration-depth inversion, boundary-port power audit | Fig. 1 |
| E5 | Spatial (dispersion) convergence of the semi-discrete eigenfrequencies | Fig. 6(a) |
| E6 | Robustness of the propagator and of the leapfrog beyond the CFL limit | Fig. 6(b), 6(c) |
| E7 | 2D TM Maxwell on the periodic Yee grid: de Rham, skew-adjointness, energy, decay | Fig. 8 |
| E8 | Reduced 1D Ginzburg–Landau-type model: IMEX Strang monotonicity and second order | Fig. 13 |
| E9 | 3D periodic Maxwell: structure preservation at n = 1296 | Table 2 |
| E10 | Scale-up of the matrix-free Krylov propagator: dimension law m(θ), memory, accuracy per unit of work | Fig. 7, Table 3 |
| E11 | Non-uniform 2D two-fluid Meissner/London audit with the M-inner-product propagator | Fig. 10, Table 2 |
| E12 | Non-uniform 3D absorption (conducting sphere in vacuum), matrix-free at n = 3.84×10⁵ | Fig. 12, Table 2 |
| E13 | Gauge-invariant TDGL on the torus: vortex–antivortex annihilation and winding bookkeeping | Fig. 15, Table 2 |

## Contact

Corresponding author: *(to be filled in with the manuscript metadata)*.
