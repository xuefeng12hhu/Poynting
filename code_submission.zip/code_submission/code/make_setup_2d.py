"""Schematic of the 2D non-uniform two-fluid Meissner test case (Sec. 5.2).

Normal-metal slab (omega_p = 10, lambda = 0.1) embedded in a
superconductor (omega_p = 30, lambda = 1/30) on the periodic unit torus,
with a flux bundle trapped at the slab centre.  The material enters only
through the energy metric M = diag(1, 1, 1, lambda^2, lambda^2), hence
the local penetration depth lambda(x, y) is the object drawn here.

Outputs figures/fig_setup_2d.{png,pdf}: PNG at 600 dpi, vector PDF.
Run with:  python code/make_setup_2d.py
"""
import os

import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import Circle, FancyArrowPatch

HERE = os.path.dirname(os.path.abspath(__file__))
FIG = os.path.join(os.path.dirname(HERE), "figures")
os.makedirs(FIG, exist_ok=True)

plt.rcParams.update({
    "font.size": 9, "axes.labelsize": 9, "legend.fontsize": 8,
    "xtick.labelsize": 8, "ytick.labelsize": 8,
    "savefig.bbox": "tight", "axes.grid": False,
    "legend.frameon": False, "lines.linewidth": 1.3, "lines.markersize": 4.5,
})

WP_SC = 30.0                 # plasma frequency, superconductor
LAM_SC = 1.0 / WP_SC         # London depth, superconductor
WP_NM = 10.0                 # plasma frequency, normal-metal slab
LAM_NM = 1.0 / WP_NM         # London depth, normal-metal slab
X0, X1 = 0.44, 0.56          # slab footprint (central vertical strip)


def save_hd(fig, name):
    """Save a high-resolution PNG (600 dpi) and a vector PDF."""
    fig.savefig(os.path.join(FIG, f"{name}.png"), dpi=600)
    fig.savefig(os.path.join(FIG, f"{name}.pdf"))
    plt.close(fig)
    print(f"  [figure] figures/{name}.png  (600 dpi)")
    print(f"  [figure] figures/{name}.pdf  (vector)")


def main():
    fig, ax = plt.subplots(figsize=(4.0, 3.6))
    ax.set_axis_off()
    ax.set_aspect("equal")
    ax.set_xlim(-0.30, 1.32)
    ax.set_ylim(-0.36, 1.40)

    # ---- the material field lambda(x, y) ----------------------------------
    n = 400
    xs = np.linspace(0.0, 1.0, n)
    X, Y = np.meshgrid(xs, xs, indexing="ij")
    lam = np.where((X >= X0) & (X <= X1), LAM_NM, LAM_SC)
    ax.imshow(lam.T, origin="lower", extent=(0.0, 1.0, 0.0, 1.0),
              cmap="cividis", vmin=0.0, vmax=0.12, zorder=1,
              interpolation="nearest")
    ax.add_patch(plt.Rectangle((0.0, 0.0), 1.0, 1.0, facecolor="none",
                               edgecolor="k", linewidth=1.1, zorder=3))

    # ---- slab boundaries and region labels --------------------------------
    for xb in (X0, X1):
        ax.plot([xb, xb], [0.0, 1.0], color="w", lw=1.6, ls="--", zorder=4)
    ax.text(0.5, 0.925, "normal-metal slab", fontsize=8, color="k",
            ha="center", va="center", zorder=6)
    ax.text(0.5, 0.855, r"$\omega_p=10,\ \lambda=0.1$", fontsize=7.5,
            color="k", ha="center", va="center", zorder=6)
    ax.text(0.06, 0.27, "superconductor", fontsize=8.5, color="w",
            ha="left", va="center", zorder=6)
    ax.text(0.06, 0.19, r"$\omega_p=30,\ \lambda=1/30$", fontsize=7.5,
            color="w", ha="left", va="center", zorder=6)

    # ---- trapped flux bundle at the slab centre ---------------------------
    ax.add_patch(Circle((0.5, 0.5), 0.055, facecolor="w", edgecolor="k",
                        linewidth=1.0, zorder=6))
    ax.add_patch(Circle((0.5, 0.5), 0.014, facecolor="k", edgecolor="none",
                        zorder=7))
    ax.annotate("", xy=(0.578, 0.545), xytext=(0.528, 0.568),
                arrowprops=dict(arrowstyle="-|>", color="k", lw=1.2,
                                connectionstyle="arc3,rad=-0.4"), zorder=7)
    ax.text(0.5, 0.405, r"trapped flux bundle $h^{*}$", fontsize=7.5,
            ha="center", va="top", zorder=7,
            bbox=dict(fc="w", ec="none", alpha=0.75, pad=1.2))

    # ---- the 1D cut used in Fig. 10(b) ------------------------------------
    ax.plot([0.0, 1.0], [0.5, 0.5], color="w", lw=1.0, ls=(0, (5, 4)), zorder=5)
    ax.text(0.015, 0.535, "cut", fontsize=7.5, color="w", ha="left",
            va="bottom", zorder=6)

    # ---- periodic seams of the torus --------------------------------------
    ax.add_patch(FancyArrowPatch((0.35, 1.09), (0.65, 1.09), arrowstyle="<->",
                                 mutation_scale=10, color="k", lw=0.9,
                                 zorder=6, clip_on=False))
    ax.text(0.5, 1.15, "periodic (torus)", fontsize=7.5, ha="center",
            va="bottom", zorder=6)
    ax.add_patch(FancyArrowPatch((1.09, 0.35), (1.09, 0.65), arrowstyle="<->",
                                 mutation_scale=10, color="k", lw=0.9,
                                 zorder=6, clip_on=False))

    # ---- coordinate axes ----------------------------------------------------
    ax.annotate("", xy=(0.98, -0.16), xytext=(0.02, -0.16),
                arrowprops=dict(arrowstyle="-|>", color="k", lw=1.0))
    ax.text(0.5, -0.24, r"$x$", fontsize=9, ha="center", va="top")
    ax.annotate("", xy=(-0.16, 0.98), xytext=(-0.16, 0.02),
                arrowprops=dict(arrowstyle="-|>", color="k", lw=1.0))
    ax.text(-0.22, 0.5, r"$y$", fontsize=9, ha="right", va="center",
            rotation=90)
    ax.text(0.0, -0.06, r"$0$", fontsize=7.5, ha="center", va="top")
    ax.text(1.0, -0.06, r"$1$", fontsize=7.5, ha="center", va="top")
    ax.text(-0.06, 0.0, r"$0$", fontsize=7.5, ha="right", va="center")
    ax.text(-0.06, 1.0, r"$1$", fontsize=7.5, ha="right", va="center")

    fig.tight_layout(pad=0.2)
    save_hd(fig, "fig_setup_2d")


if __name__ == "__main__":
    main()
