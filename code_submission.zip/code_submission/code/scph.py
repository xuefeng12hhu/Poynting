"""
scph.py
==========================================================================
Structure-preserving time integration for the Maxwell-London (two-fluid)
superconducting electrodynamics system, extended to d=1,2,3 dimensions
through the discrete de Rham (Yee staggered) complex, and to a *reduced*
one-dimensional Ginzburg-Landau-type relaxation model via an IMEX Strang
splitting whose nonlinear sub-flow is solved cell-wise in closed form.

The semi-discrete system is a port-Hamiltonian system

    du/dt = (J - R) Q u                    (linear part, see ph_structure_1d)
    du/dt = L u + N(u)                     (reduced GL model)

with a skew-symmetric J, a positive semi-definite diagonal R and a
positive diagonal energy metric Q, so that

    A^T Q + Q A = -2 Q R Q <= 0   (skew-adjoint if sigma = 0)

Note that the metric Q is *free*: the structure only requires Q diagonal
positive definite, which is what a non-uniform material distribution
(non-constant eps, mu, London weight) will use.  With a boundary input
v(t) = E_y at a driven wall the conjugate output y = b^T Q u obeys the
exact (node-wise) power balance

    dW/dt = -sigma ||e||^2 + v y ,      W = 1/2 u^T Q u ,

which is the discrete form of the generalized Poynting identity with a
boundary port.

The split linear sub-flows (Maxwell-field, London rotation, dissipation,
driver) are evaluated to machine precision through Zhong Wanxie's 2^N
precise integration.

Model scope of the nonlinear part (deliberately *not* a full TDGL
discretization): the order-parameter block is local, i.e. it carries no
gradient (kinetic) term, no vector potential and no gauge coupling; the
"energy" W of the reduced model is the electromagnetic energy plus the
order-parameter penalty, not the Ginzburg-Landau free energy.  The
nonlinear sub-flow is dissipation-dominated, so its exact
Crank-Nicolson step is a per-cell proportional scaling with a scalar
Newton solve (see TDGLModel1D.scaling_factor).

The Yee (staggered) grids in d dimensions satisfy the discrete de Rham
complex

    C^0 --grad--> C^1 --curl--> C^2 --div--> C^3

with the adjoint relations grad = -div^T, curl^T = -curl on periodic
walls, so that the discrete energy identity is exact.

Two operator backends are provided.  Dense/sparse assemblies are used
for the small verification problems; for large n the whole method is
matrix-free:

    YeeOperator3D        A applied by np.roll shifts, O(n) memory, no
                         matrix stored (Part 1b);
    KrylovExponential    exp(A dt) v by an Arnoldi projection of the
                         exponential, with Saad's adaptive stopping
                         criterion (Part 1c).

The matrix-free path reproduces the assembled operator to round-off
(check_theory item 22) and makes the structure-preserving propagator
usable at n >= 10^6 (experiment E10).
==========================================================================
"""

import numpy as np
import scipy.linalg as sla
import scipy.sparse as sp
import scipy.sparse.linalg as spla


# =========================================================================
# Part 1: Discrete de Rham operators on Yee staggered grids
# =========================================================================


def yee_operators_1d(N, L=1.0):
    """1D Yee staggered difference operators on [0, L] with N cells.

    Returns D (Ne x Nh), Dt (Nh x Ne) = -D^T, dz.
    """
    dz = L / N
    Ne, Nh = N - 1, N
    D = np.zeros((Ne, Nh))
    for k in range(Ne):
        D[k, k] = -1.0 / dz
        D[k, k + 1] = 1.0 / dz
    return D, -D.T, dz


def ph_structure_1d(N, L=1.0, omega_p=1.0, sigma=0.0, Q=None):
    """Explicit port-Hamiltonian triple (J, R, Q) of the 1D Yee system.

    The assembled semi-discrete operator of :class:`SuperconductingModel`
    is, by construction, the product

        A = (J - R) Q ,

    with J skew-symmetric, R = sigma * P_e >= 0 and Q diagonal positive
    definite.  With the default Q = diag(1, 1, omega_p^-2) the returned A
    reproduces the assembled matrix exactly (verified in the test suite).

    The point of making the triple explicit is that *Q is free*: for any
    diagonal positive Q

        A^T Q + Q A = Q (J^T - R) Q + Q (J - R) Q
                    = -2 Q R Q  <=  0 ,

    so the energy W = 1/2 u^T Q u is non-increasing and, for sigma = 0,
    exp(A dt) is exactly Q-orthogonal.  This is the structural statement
    that a non-uniform material distribution can use: material weights
    enter Q only, they never break the port-Hamiltonian form.

    Parameters
    ----------
    N, L, omega_p : grid size, length, London plasma frequency.
    sigma : normal-fluid conductivity (scalar).
    Q : optional positive diagonal metric (length n array).

    Returns
    -------
    A, J, R, Q : ndarray, ndarray, ndarray, ndarray
    """
    D, Dt, dz = yee_operators_1d(N, L)
    Ne, Nh = D.shape
    n = 2 * Ne + Nh
    ie = np.arange(Ne)
    ih = np.arange(Ne, Ne + Nh)
    ij = np.arange(Ne + Nh, n)

    if Q is None:
        Q = np.ones(n)
        Q[ij] = 1.0 / omega_p ** 2
    Q = np.asarray(Q, dtype=float).copy()
    if Q.shape != (n,):
        raise ValueError(f"Q must have length {n}")
    if np.any(Q <= 0.0):
        raise ValueError("Q must be strictly positive (it is an energy metric)")

    J = np.zeros((n, n))
    J[np.ix_(ie, ih)] = D
    J[np.ix_(ih, ie)] = Dt
    J[np.ix_(ie, ij)] = -omega_p ** 2 * np.eye(Ne)
    J[np.ix_(ij, ie)] = omega_p ** 2 * np.eye(Ne)

    R = np.zeros((n, n))
    R[np.ix_(ie, ie)] = sigma * np.eye(Ne)

    A = (J - R) * Q[None, :]          # A = (J - R) diag(Q)
    return A, J, R, np.diag(Q)


def yee_operators_2d_tm(Nx, Ny, Lx=1.0, Ly=1.0, boundary="periodic"):
    """2D TM (Transverse Magnetic) Yee staggered operators.

    Fields:  E = (Ex, Ey, 0),  H = (0, 0, Hz).
    State layout (column vectors):
        Ex[i,j] at (i+1/2, j)     i = 0..Nx-1, j = 0..Ny-1
        Ey[i,j] at (i, j+1/2)     i = 0..Nx-1, j = 0..Ny-1
        Hz[i,j] at (i+1/2, j+1/2) i = 0..Nx-1, j = 0..Ny-1

    The four operators satisfy the discrete de Rham identity

        Chz_ex = -Cex_hz^T,   Chz_ey = -Cey_hz^T,

    which is the algebraic statement of (curl)^T = -curl on the staggered
    complex.  With it the Maxwell operator A built from (C_EH, Chz_full)
    is skew-symmetric in M = I, and the discrete Poynting identity
    A^T M + M A = 0 holds exactly.

    Parameters
    ----------
    boundary : "periodic" or "pec"
        "periodic": stencil wraps modulo Nx / Ny.  Skew-adjoint identity
                    is exact for the entire operator.
        "pec":      sign-mirrored ghost cells on PEC walls; skew-adjoint
                    identity is exact in the interior stencil.
    """
    dx = Lx / Nx
    dy = Ly / Ny
    n = Nx * Ny

    def idx(i, j):
        if boundary == "periodic":
            return (j % Ny) * Nx + (i % Nx)
        return j * Nx + i

    rows_e, cols_e, vals_e = [], [], []
    rows_y, cols_y, vals_y = [], [], []
    rows_hx, cols_hx, vals_hx = [], [], []
    rows_hy, cols_hy, vals_hy = [], [], []

    for j in range(Ny):
        for i in range(Nx):
            rE = idx(i, j)
            if boundary == "periodic":
                # +d_y Hz at Ex(i, j)
                rows_e.append(rE); cols_e.append(idx(i, j));     vals_e.append(1.0 / dy)
                rows_e.append(rE); cols_e.append(idx(i, j - 1)); vals_e.append(-1.0 / dy)
                # -d_x Hz at Ey(i, j)
                rows_y.append(rE); cols_y.append(idx(i, j));     vals_y.append(-1.0 / dx)
                rows_y.append(rE); cols_y.append(idx(i - 1, j)); vals_y.append(1.0 / dx)
                # +d_y Ex at Hz(i, j)
                rows_hx.append(rE); cols_hx.append(idx(i, j + 1)); vals_hx.append(1.0 / dy)
                rows_hx.append(rE); cols_hx.append(idx(i, j));     vals_hx.append(-1.0 / dy)
                # -d_x Ey at Hz(i, j): -(Ey[i+1, j] - Ey[i, j])/dx  = (Ey[i, j] - Ey[i+1, j])/dx
                rows_hy.append(rE); cols_hy.append(idx(i, j));     vals_hy.append(1.0 / dx)
                rows_hy.append(rE); cols_hy.append(idx(i + 1, j)); vals_hy.append(-1.0 / dx)
            else:
                # PEC: sign-mirror ghost cells
                if j == 0:
                    rows_e.append(rE); cols_e.append(idx(i, 0));     vals_e.append(2.0 / dy)
                else:
                    rows_e.append(rE); cols_e.append(idx(i, j));     vals_e.append(1.0 / dy)
                    rows_e.append(rE); cols_e.append(idx(i, j - 1)); vals_e.append(-1.0 / dy)
                if i == 0:
                    rows_y.append(rE); cols_y.append(idx(0, j));     vals_y.append(-2.0 / dx)
                else:
                    rows_y.append(rE); cols_y.append(idx(i, j));     vals_y.append(-1.0 / dx)
                    rows_y.append(rE); cols_y.append(idx(i - 1, j)); vals_y.append(1.0 / dx)
                if j == Ny - 1:
                    rows_hx.append(rE); cols_hx.append(idx(i, Ny - 1)); vals_hx.append(-2.0 / dy)
                else:
                    rows_hx.append(rE); cols_hx.append(idx(i, j + 1)); vals_hx.append(1.0 / dy)
                    rows_hx.append(rE); cols_hx.append(idx(i, j));     vals_hx.append(-1.0 / dy)
                if i == Nx - 1:
                    rows_hy.append(rE); cols_hy.append(idx(Nx - 1, j)); vals_hy.append(2.0 / dx)
                else:
                    rows_hy.append(rE); cols_hy.append(idx(i, j));     vals_hy.append(1.0 / dx)
                    rows_hy.append(rE); cols_hy.append(idx(i + 1, j)); vals_hy.append(-1.0 / dx)

    Cex_hz = sp.csr_matrix((vals_e, (rows_e, cols_e)), shape=(n, n))
    Cey_hz = sp.csr_matrix((vals_y, (rows_y, cols_y)), shape=(n, n))
    Chz_ex = sp.csr_matrix((vals_hx, (rows_hx, cols_hx)), shape=(n, n))
    Chz_ey = sp.csr_matrix((vals_hy, (rows_hy, cols_hy)), shape=(n, n))
    return Cex_hz, Cey_hz, Chz_ex, Chz_ey, dx, dy


def _grid_index_3d(Nx, Ny, Nz):
    """C-order index arrays ``I, J, K`` of a periodic Nx x Ny x Nz grid."""
    K, J, I = np.meshgrid(np.arange(Nz), np.arange(Ny), np.arange(Nx),
                          indexing="ij")
    return I, J, K


def yee_operators_3d(Nx, Ny, Nz, Lx=1.0, Ly=1.0, Lz=1.0, boundary="periodic",
                     stencil="one-sided"):
    """3D Yee staggered curl operators (periodic).

    Yee layout (column vectors, each Nx*Ny*Nz entries)::

        Ex[i, j, k]  at  (i+1/2, j,      k)
        Ey[i, j, k]  at  (i,      j+1/2, k)
        Ez[i, j, k]  at  (i,      j,      k+1/2)
        Hx[i, j, k]  at  (i,      j+1/2, k+1/2)
        Hy[i, j, k]  at  (i+1/2, j,      k+1/2)
        Hz[i, j, k]  at  (i+1/2, j+1/2, k)

    State ordering ``u = [Ex, Ey, Ez, Hx, Hy, Hz]``.

    The six returned blocks are the H -> E pieces of ``curl H``::

        (curl H)_x =  d_y Hz - d_z Hy
        (curl H)_y =  d_z Hx - d_x Hz
        (curl H)_z =  d_x Hy - d_y Hx

    Each block is a **one-sided (staggered) difference in the stored
    arrays**: the ``+1`` coefficient sits on the *same* stored index and
    the ``-1`` coefficient on the index shifted by one cell, exactly as
    the half-cell offsets of the Yee lattice require.  The Faraday
    blocks are then *defined* as

        Chx_ey = -Cey_hx^T,  ... ,  Chz_ey = -Cey_hz^T,

    which on a periodic grid turns the same stored-index difference into
    a one-sided difference of the opposite orientation.  Consequently

        (i)  the discrete de Rham identity  C_h = -C_EH^T  holds exactly,
        (ii) A = [[-sigma I, C_EH], [C_h, 0]] is *exactly* skew-adjoint
             in M = I when sigma = 0,
        (iii) the discrete dispersion relation of A is the Yee one,
             omega^2 = 4 sum_i sin^2(k_i h_i / 2) / h_i^2.

    .. warning::

       An earlier revision built these blocks from **centred**
       differences over a 2h stencil (coefficients on the ``+1`` and
       ``-1`` neighbours, which are themselves antisymmetric).  That
       also satisfies C_h = -C_EH^T, but it is *not* a Yee stencil: its
       symbol at the Nyquist wavenumber vanishes, so it carries a
       spurious non-propagating mode and decouples the grid into eight
       checkerboard subgrids.  The one-sided construction above removes
       both defects; see ``check_theory`` item 21.

    Parameters
    ----------
    boundary : "periodic"
        Only the periodic boundary is implemented.  PEC walls can be
        added by trimming the appropriate rows/columns from the returned
        operators; this is left for specialised applications.
    """
    if boundary != "periodic":
        raise NotImplementedError("Only periodic 3D Yee grids are supported.")

    dx = Lx / Nx
    dy = Ly / Ny
    dz = Lz / Nz
    n = Nx * Ny * Nz

    I, J, K = _grid_index_3d(Nx, Ny, Nz)
    flat = ((K * Ny + J) * Nx + I).ravel()

    def shifted_minus(axis):
        """Stored index shifted by one cell in the negative direction."""
        if axis == "x":
            g = (K * Ny + J) * Nx + (I - 1) % Nx
        elif axis == "y":
            g = (K * Ny + (J - 1) % Ny) * Nx + I
        else:
            g = (((K - 1) % Nz) * Ny + J) * Nx + I
        return g.ravel()

    def shifted_plus(axis):
        """Stored index shifted by one cell in the positive direction."""
        if axis == "x":
            g = (K * Ny + J) * Nx + (I + 1) % Nx
        elif axis == "y":
            g = (K * Ny + (J + 1) % Ny) * Nx + I
        else:
            g = (((K + 1) % Nz) * Ny + J) * Nx + I
        return g.ravel()

    def blk(axis, cp, cm):
        """Difference block along ``axis``.

        ``cp``/``cm`` are the coefficients of the **one-sided** stencil,
        i.e. for a difference ``(u[i] - u[i-1]) / h`` one passes
        ``cp = 1/h, cm = -1/h``.

        ``stencil="one-sided"`` keeps that stencil (a staggered Yee
        difference); ``stencil="centred"`` instead places ``cp``/``cm``
        on the +/-1 neighbours, which requires the extra factor 1/2 to
        represent ``(u[i+1] - u[i-1]) / (2h)``.
        """
        if stencil == "one-sided":
            cols = np.concatenate([flat, shifted_minus(axis)])
            scale = 1.0
        else:
            cols = np.concatenate([shifted_plus(axis), shifted_minus(axis)])
            scale = 0.5
        rows = np.concatenate([flat, flat])
        vals = np.concatenate([np.full(flat.size, scale * cp),
                               np.full(flat.size, scale * cm)])
        return sp.coo_matrix((vals, (rows, cols)), shape=(n, n)).tocsr()

    # (curl H)_x = d_y Hz - d_z Hy
    Cex_hz = blk("y", 1.0 / dy, -1.0 / dy)
    Cex_hy = -blk("z", 1.0 / dz, -1.0 / dz)

    # (curl H)_y = d_z Hx - d_x Hz
    Cey_hx = blk("z", 1.0 / dz, -1.0 / dz)
    Cey_hz = -blk("x", 1.0 / dx, -1.0 / dx)

    # (curl H)_z = d_x Hy - d_y Hx
    Cez_hy = blk("x", 1.0 / dx, -1.0 / dx)
    Cez_hx = -blk("y", 1.0 / dy, -1.0 / dy)

    # Faraday / -curl E pieces, i.e. Ch = -C_EH^T.
    #
    # One-sided stencil: transposing a staggered difference gives the
    # opposite one-sided difference, so the block *placement* is
    # transposed and each block is transposed as well.
    #
    # Centred stencil: the scalar kernel is antisymmetric (D^T = -D), so
    # C_EH^T = C_EH and Ch = -C_EH keeps the original placement.
    #
    # Both choices make A exactly skew-adjoint.
    if stencil == "one-sided":
        Chx_ey = -Cey_hx.T
        Chx_ez = -Cez_hx.T
        Chy_ex = -Cex_hy.T
        Chy_ez = -Cez_hy.T
        Chz_ex = -Cex_hz.T
        Chz_ey = -Cey_hz.T
    else:
        Chx_ey = -Cex_hy
        Chx_ez = -Cex_hz
        Chy_ex = -Cey_hx
        Chy_ez = -Cey_hz
        Chz_ex = -Cez_hx
        Chz_ey = -Cez_hy

    return (Cex_hz, Cex_hy, Cey_hz, Cey_hx, Cez_hx, Cez_hy,
            Chx_ey, Chx_ez, Chy_ex, Chy_ez, Chz_ex, Chz_ey,
            dx, dy, dz)


# =========================================================================
# Part 1b: Matrix-free 3D Yee operator
# =========================================================================


def _diff_view(u, h, ax, back):
    """``(u - u_shifted) / h`` along the periodic axis ``ax``.

    ``back=True``  -> ``(u[i] - u[i-1]) / h``,
    ``back=False`` -> ``(u[i+1] - u[i]) / h``.

    Written with two strided views instead of ``numpy.roll``: the roll
    kernel copies the array into a temporary which the subtraction then
    copies again, whereas the views touch the operand once.  Measured on
    a 64^3 field the twelve differences of one operator application drop
    from 18.7 ms to 6.3 ms; the matrix-free product is memory-bandwidth
    bound, so this matters at the resolutions of interest.
    """
    out = np.empty_like(u)
    d = [slice(None)] * u.ndim
    s = [slice(None)] * u.ndim
    a = [slice(None)] * u.ndim
    b = [slice(None)] * u.ndim
    if back:                            # out[i] = u[i] - u[i-1]
        d[ax], s[ax] = slice(1, None), slice(0, -1)
        np.subtract(u[tuple(d)], u[tuple(s)], out=out[tuple(d)])
        a[ax], b[ax] = slice(0, 1), slice(-1, None)
        np.subtract(u[tuple(a)], u[tuple(b)], out=out[tuple(a)])
    else:                               # out[i] = u[i+1] - u[i]
        d[ax], s[ax] = slice(0, -1), slice(1, None)
        np.subtract(u[tuple(s)], u[tuple(d)], out=out[tuple(d)])
        a[ax], b[ax] = slice(-1, None), slice(0, 1)
        np.subtract(u[tuple(b)], u[tuple(a)], out=out[tuple(a)])
    np.divide(out, h, out=out)
    return out


def _bwd(u, h, ax):
    """Backward difference ``(u[i] - u[i-1]) / h`` along axis ``ax``."""
    return _diff_view(u, h, ax, True)


def _fwd(u, h, ax):
    """Forward difference ``(u[i+1] - u[i]) / h`` along axis ``ax``."""
    return _diff_view(u, h, ax, False)


def _cen(u, h, ax):
    """Centred difference ``(u[i+1] - u[i-1]) / (2h)`` along axis ``ax``.

    Kept only so that the legacy (defective) 3D stencil can be
    reconstructed and compared against the staggered one.
    """
    return (_fwd(u, 1.0, ax) + _bwd(u, 1.0, ax)) / (2.0 * h)


def _curl3(v, d, h):
    """Apply ``curl`` to a 3-vector field with the difference kernel ``d``."""
    hx, hy, hz = h
    vx, vy, vz = v[0], v[1], v[2]
    out = np.empty_like(v)
    out[0] = d(vz, hy, 1) - d(vy, hz, 0)
    out[1] = d(vx, hz, 0) - d(vz, hx, 2)
    out[2] = d(vy, hx, 2) - d(vx, hy, 1)
    return out


class YeeOperator3D:
    """Matrix-free 3D Yee curl operator on a periodic grid.

    The operator is applied through twelve strided differences on a
    ``(6, Nz, Ny, Nx)`` view of the state, so **no matrix is stored**:
    the memory footprint is O(n) and the per-application cost is O(n)
    with a small constant.  It reproduces exactly the sparse operator
    assembled by :func:`yee_operators_3d` (see ``check_theory`` item 22)
    and is the workhorse of the large-scale experiments, where a sparse
    assembly of A would cost 24 n_per nnz.

    Block structure (identical to :func:`yee_operators_3d`)::

        dE/dt = C_EH H - sigma E,     C_EH  = backward-difference curl
        dH/dt = C_h  E,               C_h   = -C_EH^T (forward-difference curl)

    so that ``A^T + A = -2 sigma diag(I_E, 0)`` holds *by construction*.
    """

    dim = 3

    def __init__(self, Nx, Ny, Nz, Lx=1.0, Ly=1.0, Lz=1.0, sigma=0.0,
                 stencil="one-sided", sigma_field=None):
        self.Nx, self.Ny, self.Nz = int(Nx), int(Ny), int(Nz)
        self.grid_raw = (self.Nx, self.Ny, self.Nz)
        self.grid = (self.Nz, self.Ny, self.Nx)
        self.h = (Lx / Nx, Ly / Ny, Lz / Nz)
        self.stencil = stencil
        self.n_per = self.Nx * self.Ny * self.Nz
        self.nE = 3 * self.n_per
        self.n = 6 * self.n_per
        self.shape = (self.n, self.n)
        self.dtype = np.dtype(float)
        if sigma_field is not None:
            # Non-uniform (possibly anisotropic-per-component) Ohmic
            # conductivity: an array broadcastable to (3, Nz, Ny, Nx),
            # one weight per E-component grid point.  The structure
            # A^T + A = -2 diag(sigma) on the E block is preserved for
            # *any* non-negative field (the metric stays M = I; the
            # material enters the dissipation, not the energy).
            sf = np.asarray(sigma_field, dtype=float)
            try:
                self._sigma = np.broadcast_to(sf, (3, *self.grid)).copy()
            except ValueError:
                raise ValueError(
                    "sigma_field must be broadcastable to (3, Nz, Ny, Nx)")
            if np.any(self._sigma < 0.0):
                raise ValueError("sigma_field must be non-negative")
            self.sigma = None
            self.sigma_field = self._sigma
        else:
            self._sigma = None
            self.sigma = float(sigma)
            self.sigma_field = None
        if stencil == "one-sided":
            # staggered Yee: one-sided difference for curl H, the adjoint
            # one-sided difference for the Faraday block
            self._d = _bwd
            self._df = _fwd
        elif stencil == "centred":
            # legacy stencil: 2h centred difference.  C_EH is then
            # antisymmetric, so C_h = -C_EH^T = +C_EH and the assembly is
            # still skew, but the Nyquist mode is annihilated.
            self._d = _cen
            self._df = _cen
        else:
            raise ValueError("stencil must be 'one-sided' or 'centred'")

    # -- curl H (used by the E update) ------------------------------------
    def curl_H(self, H):
        """``C_EH @ H`` with H of shape (3, Nz, Ny, Nx)."""
        return _curl3(H, self._d, self.h)

    # -- Faraday: C_h @ E = -C_EH^T @ E (used by the H update) -------------
    def faraday(self, E):
        """``C_h @ E`` with E of shape (3, Nz, Ny, Nx).

        This is ``-C_EH^T``, i.e. the adjoint of ``curl_H`` with the
        Faraday sign, so that the assembled A is exactly skew-adjoint.
        """
        return -_curl3(E, self._df, self.h)

    def matvec(self, u):
        """``A @ u`` for a flat state vector of length 6 Nx Ny Nz."""
        U = np.asarray(u, dtype=float).reshape(6, *self.grid)
        E, H = U[:3], U[3:]
        out = np.empty_like(U)
        se = self._sigma * E if self._sigma is not None else self.sigma * E
        out[:3] = self.curl_H(H) - se
        out[3:] = self.faraday(E)
        return out.ravel()

    def __matmul__(self, u):
        return self.matvec(u)

    # -- helpers ----------------------------------------------------------
    def energy(self, u):
        return 0.5 * float(np.dot(u, u))

    def dissipative_quadratic(self, u=None, seed=0):
        """``|u^T A u + u_E^T Sigma u_E| / scale``  == 0 iff
        ``A^T + A = -2 diag(Sigma)`` on the E block.

        This is the matrix-free scalar certification of the *non-uniform*
        dissipation structure: it vanishes for every ``u`` exactly when
        the Ohmic weights are carried by the E block alone, which is how
        a spatially varying material enters the generator.  No matrix is
        ever formed, so the check is available at n >= 10^6.
        """
        if u is None:
            u = np.random.default_rng(seed).standard_normal(self.n)
        u = np.asarray(u, dtype=float)
        U = u.reshape(6, *self.grid)
        E = U[:3]
        Au = self.matvec(u)
        diss = float(np.sum(self._sigma * E * E)) if self._sigma is not None \
            else self.sigma * float(np.sum(E * E))
        lhs = float(u @ Au) + diss
        den = float(np.linalg.norm(u)) * float(np.linalg.norm(Au))
        return abs(lhs) / den if den > 0.0 else 0.0

    def skew_quadratic(self, u=None, seed=0):
        """Relative quadratic form ``|u^T A u| / (||u|| ||A u||)``.

        For a real matrix the quadratic form vanishes for *every* ``u``
        if and only if ``A`` is skew-symmetric, so this is the scalar
        check of skew-adjointness that requires no assembled matrix --
        it is the verification available at n >= 10^6, where forming A
        is out of the question.
        """
        if u is None:
            u = np.random.default_rng(seed).standard_normal(self.n)
        u = np.asarray(u, dtype=float)
        Au = self.matvec(u)
        den = float(np.linalg.norm(u)) * float(np.linalg.norm(Au))
        return abs(float(u @ Au)) / den if den > 0.0 else 0.0

    def cfl_dt(self):
        """Stability limit of the explicit Yee leapfrog (unit wave speed)."""
        hx, hy, hz = self.h
        return 1.0 / np.sqrt(1.0 / hx ** 2 + 1.0 / hy ** 2 + 1.0 / hz ** 2)

    def spectral_norm_bound(self):
        """||A||_2 for sigma = 0, i.e. the top of the curl-curl spectrum."""
        return self.omega_max_analytic()

    def omega_max_numeric(self, iters=400, seed=0):
        """Largest eigenvalue of ``C_EH C_EH^T`` by power iteration.

        ``d2 E/dt2 = C_EH C_h E = -C_EH C_EH^T E``, so the largest
        eigenvalue of ``C_EH C_EH^T`` is the square of the highest
        discrete frequency carried by the grid.
        """
        rng = np.random.default_rng(seed)
        H = rng.standard_normal((3, *self.grid))
        H /= np.linalg.norm(H)
        lam = 0.0
        for _ in range(iters):
            E = self.curl_H(H)
            # C_EH^T E = -C_h E = -faraday(E)
            Hn = -self.faraday(E)
            nrm = float(np.linalg.norm(Hn))
            if nrm == 0.0:
                return 0.0
            H = Hn / nrm
            lam = nrm
        return float(np.sqrt(lam))

    def omega_max_analytic(self):
        """Closed-form maximum of the discrete curl-curl spectrum.

        For the staggered Yee stencil the symbol is

            omega^2 = 4 sum_i sin^2(k_i h_i / 2) / h_i^2,

        and for the legacy centred stencil of step 2h it is

            omega^2 =   sum_i sin^2(k_i h_i) / h_i^2.

        The maximum is taken over the admissible wavenumbers
        ``k_i h_i = 2 pi m_i / N_i`` of the periodic grid, i.e. by
        exhaustive search over ``m_i``.  The centred symbol vanishes at
        Nyquist for even ``N_i``; this is the defect that the staggered
        construction removes (see ``check_theory`` item 21).
        """
        s = 0.0
        for N, h in zip(self.grid_raw, self.h):
            m = np.arange(N)
            if self.stencil == "one-sided":
                vals = 4.0 * np.sin(np.pi * m / N) ** 2 / h ** 2
            else:
                vals = np.sin(2.0 * np.pi * m / N) ** 2 / h ** 2
            s += float(vals.max())
        return float(np.sqrt(s))

    def dispersion_max_error(self, **kw):
        """Relative defect of the top of the discrete curl-curl spectrum.

        Compares the power-iteration value with the closed-form maximum
        :meth:`omega_max_analytic`.  This validates the *whole* stencil
        against the analytic symbol; the spurious-mode defect of a
        centred stencil is detected separately by
        :meth:`checkerboard_null_ratio`.
        """
        w_num = self.omega_max_numeric(**kw)
        w_ana = self.omega_max_analytic()
        return abs(w_num - w_ana) / w_ana

    def checkerboard_null_ratio(self):
        """Relative size of ``C_EH`` applied to the checkerboard mode.

        The **transverse** real mode ``H = (0, 0, (-1)^(i+j+k))`` is a
        genuine non-constant grid field; it is not the longitudinal
        (omega = 0) mode, which would be ``H = c (1,1,1)``.  For the
        staggered Yee stencil this transverse mode is *not* annihilated
        by the discrete curl, so the ratio is O(1); for the legacy
        centred stencil (step 2h) the centred symbol vanishes there and
        the mode is mapped to zero -- a spurious non-propagating state
        that also decouples the grid into eight checkerboard subgrids.
        The returned value is ``||C_EH H_ck|| * hbar / ||H_ck||``, which
        is dimensionless.
        """
        K, J, I = np.meshgrid(np.arange(self.Nz), np.arange(self.Ny),
                              np.arange(self.Nx), indexing="ij")
        ck = (-1.0) ** (I + J + K)
        H = np.zeros((3, *self.grid))
        H[2] = ck
        out = self.curl_H(H)
        hbar = float(np.mean(self.h))
        return float(np.linalg.norm(out) * hbar / np.linalg.norm(H))


# =========================================================================
# Part 1c: Matrix-free Krylov (Arnoldi) matrix exponential
# =========================================================================


class KrylovExponential:
    """Matrix-free evaluation of ``exp(A dt) v`` by an Arnoldi projection.

    The Krylov subspace ``K_m(A, v) = span{v, Av, ..., A^{m-1} v}`` is
    built with the Arnoldi process; with ``V_m^T A V_m = H_m`` (upper
    Hessenberg) the approximation is

        exp(A dt) v  ~=  beta V_m exp(H_m dt) e_1,   beta = ||v||,

    which needs only matrix-vector products with ``A``.  The truncation
    error is estimated by Saad's *next-term* bound

        err_m  ~=  beta |h_{m+1,m}| |e_m^T exp(H_m dt) e_1|,

    and the iteration stops once ``err_m <= tol * beta``.  The dimension
    is therefore chosen adaptively from the *attained* residual rather
    than from a norm heuristic; this matters because the spectrum of the
    Yee generator is spread over ``[0, omega_max]`` with many distinct
    eigenvalues (so no norm-based guess is informative) and, for
    ``sigma > 0``, ``A`` is only *M*-skew-adjoint, i.e. non-normal in the
    Euclidean metric.

    **Energy-metric (M-inner-product) variant.**  With ``metric`` a
    positive diagonal vector ``M`` the Arnoldi process is run in the
    M-inner product ``<x, y>_M = x^T M y``: the basis ``V_m`` is
    M-orthonormal, ``beta = sqrt(v^T M v)``, and Saad's criterion
    measures the error in the M-norm.  Algebraically this is the
    Euclidean Arnoldi process applied to the similar operator
    ``S A S^{-1}`` with ``S = M^{1/2}`` (diagonal), so the projected
    Hessenberg matrix satisfies

        H_m = V_m^{*} M A V_m ,  hence
        H_m^{*} + H_m = V_m^{*} (A^{T} M + M A) V_m .

    If the generator is M-dissipative, ``A^{T} M + M A <= 0`` -- which
    is precisely the port-Hamiltonian structure of the Yee
    semi-discretization, uniform *or not* in the material weights --
    then ``H_m^{*} + H_m <= 0``, so ``|exp(H_m dt) y| <= |y|`` for every
    real ``dt >= 0`` and

        W(u_{n+1}) = (beta^2 / 2) |exp(H_m dt) e_1|^2 <= W(u_n)

    holds *exactly*, for **every** truncation dimension ``m`` and
    **every** requested tolerance: the truncated M-Krylov propagator is
    exactly non-expansive in the energy metric, and its energy drift is
    at the round-off floor (not at the tolerance), whereas the Euclidean
    realization drifts at ``O(tol)`` whenever ``M != I``.  This is the
    structure-preserving counterpart of the exact propagator, and it is
    what makes the non-uniform-material models affordable: the metric
    carries the material, the Krylov space carries the dynamics.

    The small dense exponential ``exp(H_m dt)`` is evaluated with the
    *same* ``2^N`` precise-integration kernel that builds the dense
    propagator, so the code contains a single exponential kernel; the
    kernel used here is intentionally not ``scipy.linalg.expm``.  Saad's
    bound is an estimate, not a certified bound, and is validated against
    ``scipy.linalg.expm`` in ``check_theory`` items 23--25, where the
    library routine appears only as an independent reference.

    Parameters
    ----------
    A : ndarray, sparse matrix, or callable
        The generator, or a callable applying it to a vector.
    metric : ndarray or None
        Positive diagonal of the energy metric ``M``.  ``None`` (the
        default, and the only behaviour of earlier revisions) runs the
        classical Euclidean Arnoldi process.
    max_bytes : int or None
        Cap on the memory used by the Krylov basis (``(m+1) n`` doubles).
        When given, ``max_dim`` is reduced accordingly; the achieved
        tolerance is then reported through :attr:`tol_achieved`.

    The basis is stored in a buffer that is grown geometrically rather
    than pre-allocated at ``max_dim``.  The memory actually touched is
    therefore ``8 (m_used + 1) n`` bytes with ``m_used`` the *attained*
    Krylov dimension, which is what makes the tolerance-limited Krylov
    exponential affordable at ``n >= 10^6`` even when ``max_dim`` is
    large (see ``check_theory`` item 25 and experiment E10).

    Attributes
    ----------
    m_last : int
        Krylov dimension used on the most recent application.
    m_history : list of int
    tol_achieved : float
        Largest relative residual estimate seen so far.
    """

    def __init__(self, A, dt, tol=1e-13, max_dim=96, reortho=1,
                 max_bytes=None, n=None, metric=None):
        if callable(A) and not hasattr(A, "shape"):
            self._apply_A = lambda v: np.asarray(A(v), dtype=float)
            self.A = None
            self.n = int(n) if n is not None else None
        else:
            self.A = A
            self._apply_A = lambda v: np.asarray(A @ v, dtype=float)
            self.n = int(A.shape[0])
        if metric is not None:
            metric = np.asarray(metric, dtype=float)
            if metric.ndim != 1:
                raise ValueError("metric must be a 1-D array (diagonal of M)")
            if self.n is not None and metric.size != self.n:
                raise ValueError(f"metric must have length {self.n}")
            if np.any(metric <= 0.0):
                raise ValueError("metric must be strictly positive "
                                 "(it is an energy metric)")
            self.metric = metric
            self._s = np.sqrt(metric)
            base = self._apply_A
            # \tilde A = S A S^{-1} applied to the transformed vector w:
            self._apply_A = lambda w: self._s * base(w / self._s)
        else:
            self.metric = None
            self._s = None
        self.dt = float(dt)
        self.tol = float(tol)
        self.max_dim_soft = int(max_dim)
        if max_bytes is not None and self.n is not None:
            by_dim = int(max_bytes // (8 * max(self.n, 1)))
            self.max_dim_soft = max(2, min(self.max_dim_soft, by_dim))
        self.reortho = int(max(1, reortho))
        self.m_last = 0
        self.m_history = []
        self.tol_achieved = 0.0
        self.calls = 0
        self.matvecs = 0
        self.peak_bytes = 0

    def apply(self, v):
        v = np.asarray(v, dtype=float)
        n = v.size
        # M-metric entry/exit: work in the transformed variable S v, in
        # which the classical (Euclidean) Arnoldi process below *is* the
        # M-orthogonal one for the original generator (see docstring).
        if self._s is not None and self._s.size == n:
            w_in = self._s * v
        else:
            w_in = v
        beta = float(np.linalg.norm(w_in))
        if beta == 0.0:
            return np.zeros_like(v)
        m_max = int(max(1, min(self.max_dim_soft, n)))
        H = np.zeros((m_max + 1, m_max))
        # Geometric growth of the Krylov basis: the buffer only ever holds
        # O(m_used + 1) vectors (see the class docstring).
        V = np.empty((max(2, min(8, m_max + 1)), n))
        V[0] = w_in / beta
        m_used = m_max
        err = np.inf
        j = 0
        while j < m_max:
            if j + 1 >= V.shape[0]:
                Vn = np.empty((min(m_max + 1, 2 * V.shape[0]), n))
                Vn[:j + 1] = V[:j + 1]
                V = Vn
            self.peak_bytes = max(self.peak_bytes, 8 * V.shape[0] * n)
            w = self._apply_A(V[j])
            self.matvecs += 1
            for _ in range(self.reortho):
                proj = V[:j + 1] @ w
                H[:j + 1, j] += proj
                w -= V[:j + 1].T @ proj
            h_next = float(np.linalg.norm(w))
            H[j + 1, j] = h_next
            m = j + 1
            # Saad's next-term error estimate (relative to ||v||).  The
            # small Hessenberg exponential is evaluated by the same 2^N
            # precise-integration kernel as the dense propagator
            # (see ``hessenberg_exponential``).
            y = hessenberg_exponential(H[:m, :m], self.dt)[:, 0]
            err = h_next * abs(y[-1])
            if err <= self.tol or h_next == 0.0:
                m_used = m
                break
            V[j + 1] = w / h_next
            j += 1
        self.m_last = int(m_used)
        self.m_history.append(int(m_used))
        self.tol_achieved = max(self.tol_achieved, float(err))
        self.calls += 1
        y = hessenberg_exponential(H[:m_used, :m_used], self.dt)[:, 0]
        out = beta * (V[:m_used].T @ y)
        if self._s is not None and self._s.size == n:
            return out / self._s
        return out

    def __call__(self, v):
        return self.apply(v)

    def __matmul__(self, v):
        return self.apply(v)

    @property
    def basis_bytes(self):
        """Logical size of the Krylov basis, ``8 (m_last + 1) n`` bytes."""
        return 8 * (self.m_last + 1) * (self.n or 0)


class ExponentialPropagator:
    """Uniform callable interface ``u -> exp(A dt) u`` for all backends.

    ``backend`` is one of

    ``"auto"``   dense precise integration when ``n <= dense_limit``,
                 otherwise the matrix-free Krylov exponential;
    ``"dense"``  ``precise_integration(A, dt)`` (requires a dense A);
    ``"krylov"`` :class:`KrylovExponential`.

    With ``metric`` (positive diagonal of the energy metric ``M``) the
    propagator is built for the similar operator ``S A S^{-1}``,
    ``S = M^{1/2}``, and wrapped so that ``apply(u) = S^{-1} exp(S A
    S^{-1} dt) (S u)``; for the Krylov backend this is exactly the
    M-orthogonal Arnoldi realization of :class:`KrylovExponential` (same
    Hessenberg matrix, same stopping criterion in the M-norm), and the
    step is exactly non-expansive in ``W = 1/2 u^T M u`` whenever
    ``A^T M + M A <= 0`` (see the :class:`KrylovExponential` docstring).

    The object is callable and supports ``P @ u``, so it is a drop-in
    replacement for the bare matrices used by the earlier revision.
    """

    def __init__(self, A, dt, backend="auto", tol=1e-13, max_dim=96,
                 dense_limit=2000, max_bytes=None, n=None, metric=None):
        self.A = A
        self.dt = float(dt)
        self.metric = None if metric is None else np.asarray(metric,
                                                             dtype=float)
        is_callable = callable(A) and not hasattr(A, "shape")
        if is_callable:
            if n is None:
                raise ValueError("n must be supplied when A is a callable")
            self.n = int(n)
        else:
            self.n = int(A.shape[0])
        if self.metric is not None:
            if self.metric.size != self.n:
                raise ValueError(f"metric must have length {self.n}")
            if np.any(self.metric <= 0.0):
                raise ValueError("metric must be strictly positive")
            self._s = np.sqrt(self.metric)
        else:
            self._s = None
        if backend == "auto":
            backend = "dense" if self.n <= dense_limit else "krylov"
        if backend == "dense" and is_callable:
            backend = "krylov"
        self.backend = backend
        if backend == "dense":
            if self._s is not None:
                # exp(S A S^{-1} dt) with the diagonal similarity S.
                A_t = self._similarity(A)
                self._P = precise_integration(A_t, dt)
            else:
                self._P = precise_integration(A, dt)
            self.engine = None
        else:
            self.engine = KrylovExponential(A, dt, tol=tol, max_dim=max_dim,
                                            max_bytes=max_bytes, n=self.n,
                                            metric=metric)
            self._P = None

    def _similarity(self, A):
        """``S A S^{-1}`` for the diagonal metric square root S."""
        s = self._s
        if isinstance(A, np.ndarray):
            return A * s[:, None] / s[None, :]
        A = sp.csr_matrix(A)
        D = sp.diags(s)
        Di = sp.diags(1.0 / s)
        return (D @ A @ Di).toarray()

    def apply(self, u):
        u = np.asarray(u, dtype=float)
        if self.backend == "dense":
            if self._s is not None:
                return (self._P @ (self._s * u)) / self._s
            return self._P @ u
        return self.engine.apply(u)

    def __call__(self, u):
        return self.apply(u)

    def __matmul__(self, u):
        return self.apply(u)

    @property
    def m_last(self):
        return 0 if self.engine is None else self.engine.m_last

    @property
    def m_mean(self):
        if self.engine is None or not self.engine.m_history:
            return 0.0
        return float(np.mean(self.engine.m_history))

    @property
    def matvecs(self):
        return 0 if self.engine is None else self.engine.matvecs


# =========================================================================
# Part 2: Linear Maxwell-London models (1D backward compatible)
# =========================================================================


class SuperconductingModel:
    """1D Maxwell-London semi-discrete system (backward compatible)."""

    def __init__(self, N=64, L=1.0, omega_p=10.0, sigma=0.0, driven=False,
    omega_d=None):
        self.N, self.L = N, L
        self.dz = L / N
        self.omega_p = float(omega_p)
        self.sigma = float(sigma)
        self.lambda_L = 1.0 / self.omega_p
        self.D, self.Dt, _ = yee_operators_1d(N, L)
        self.Ne, self.Nh = self.D.shape
        self.n = 2 * self.Ne + self.Nh
        self.ie = np.arange(0, self.Ne)
        self.ih = np.arange(self.Ne, self.Ne + self.Nh)
        self.ij = np.arange(self.Ne + self.Nh, self.n)
        self.driven = driven
        if driven:
            if omega_d is None:
                raise ValueError("omega_d must be given for a driven model")
            self.omega_d = float(omega_d)
            self.id_ = self.n
            self.idd = self.n + 1
            self.n_aug = self.n + 2
        else:
            self.n_aug = self.n
        self.A = self._assemble()
        self.M = self._metric()

    def _assemble(self):
        n = self.n_aug
        A = np.zeros((n, n))
        Ne, Nh = self.Ne, self.Nh
        ie, ih, ij = self.ie, self.ih, self.ij
        A[np.ix_(ie, ie)] = -self.sigma * np.eye(Ne)
        A[np.ix_(ie, ih)] = self.D
        A[np.ix_(ie, ij)] = -np.eye(Ne)
        A[np.ix_(ih, ie)] = self.Dt
        A[np.ix_(ij, ie)] = self.omega_p ** 2 * np.eye(Ne)
        if self.driven:
            A[self.ih[0], self.id_] = -1.0 / self.dz
            A[self.id_, self.idd] = 1.0
            A[self.idd, self.id_] = -self.omega_d ** 2
        return A

    def _metric(self):
        M = np.ones(self.n_aug)
        M[self.ij] = 1.0 / self.omega_p ** 2
        if self.driven:
            M[self.id_] = self.omega_d ** 2
            M[self.idd] = 1.0
        return np.diag(M)

    def energy(self, u):
        return 0.5 * float(u @ (self.M @ u))

    # ---- boundary port (driven wall) -----------------------------------
    #
    # Replacing the PEC value E_y(0) = 0 by a prescribed input v(t) adds
    # the single column  b = -e_{h_0} / dz  to the Faraday row of the
    # first dual node:
    #
    #     u' = A u + b v ,          y = b^T M u = -h_0 / dz ,
    #
    # so that (v, y) is a conjugate port pair and the node-wise power
    # balance  dW/dt = -sigma ||e||^2 + v y  holds *exactly*, with no
    # discretization error beyond the semi-discretization itself.  The
    # factor 1/dz is the discrete version of the boundary flux (it is the
    # discrete d/dz of the first cell); equivalently the flux variable
    # -h_0 = dz * y tends to the boundary field -H_x(z=0) as dz -> 0.
    def port_vector(self):
        """Input vector b of the boundary port (length n_aug)."""
        b = np.zeros(self.n_aug)
        b[self.ih[0]] = -1.0 / self.dz
        return b

    def port_output(self, u):
        """Conjugate output y = b^T M u (the boundary magnetic field)."""
        return float(self.port_vector() @ (self.M @ u))

    def port_power(self, v, u):
        """Instantaneous power v * y delivered through the port."""
        return float(v) * self.port_output(u)

    def port_balance_residual(self, u, v):
        """|dW/dt + sigma ||e||^2 - v y| at the state u.

        Both sides are evaluated exactly from the state (no time step is
        involved), so the residual must sit at the roundoff floor: this
        tests the (J - R) Q structure, the metric M and the choice of
        the conjugate port pair at once.
        """
        dW = float(u @ (self.M @ (self.A @ u)))
        diss = self.sigma * float(np.sum(u[self.ie] ** 2))
        return abs(dW + diss - self.port_power(v, u))

    def port_flux_variable(self, u):
        """Flux variable dz * y = -h_0 (-> -H_x(0) as dz -> 0)."""
        return -float(u[self.ih[0]])

    def jacobi_residual(self):
        Pe = np.zeros((self.n_aug, self.n_aug))
        Pe[np.ix_(self.ie, self.ie)] = np.eye(self.Ne)
        R = self.A.T @ self.M + self.M @ self.A + 2 * self.sigma * Pe
        return float(sla.norm(R))

    def orthogonality_residual(self, dt):
        Phi = sla.expm(self.A * dt)
        R = Phi.T @ self.M @ Phi - self.M
        return float(sla.norm(R) / sla.norm(self.M))

    def static_subspace(self):
        """Basis of ker(A): the frozen London (Meissner) states.

        For any h in R^Nh the state u = (0, h, D h) satisfies
        A u = 0: it is a static configuration with E = 0 and curl H = J,
        whose energy 0.5(|h|^2 + wp^-2 |D h|^2) is never dissipated.
        The subspace therefore has dimension Nh and is A-invariant, so
        any decay-rate measurement must first remove it -- otherwise the
        energy settles to a non-zero plateau and the fitted rate drift
        to zero.  Note that R^n = ker(A) (+) range(A) because 0 is a
        semi-simple eigenvalue.
        """
        K = np.zeros((self.n_aug, self.Nh))
        K[self.ih, :] = np.eye(self.Nh)
        K[self.ij, :] = self.D
        return K

    def remove_static_component(self, u):
        """M-orthogonal projection of u onto range(A) (kills ker(A))."""
        K = self.static_subspace()
        MK = self.M @ K
        c = np.linalg.solve(MK.T @ K, MK.T @ u)
        return u - K @ c

    def discrete_eigenfrequency(self, mode):
        k = mode * np.pi / self.L
        return np.sqrt(self.omega_p ** 2 + (2.0 * np.sin(k * self.dz / 2) / self.dz) ** 2)

    def continuum_eigenfrequency(self, mode):
        k = mode * np.pi / self.L
        return np.sqrt(self.omega_p ** 2 + k ** 2)

    def eigenmode(self, mode):
        k = mode * np.pi / self.L
        w = self.discrete_eigenfrequency(mode)
        z_e = (np.arange(1, self.N) * self.dz)
        z_h = (np.arange(self.N) + 0.5) * self.dz
        e = np.sin(k * z_e)
        h = np.cos(k * z_h) * (2.0 * np.sin(k * self.dz / 2) / self.dz) / w
        j = (self.omega_p ** 2 / w ** 2) * e
        u = np.zeros(self.n_aug)
        u[self.ie] = e
        u[self.ih] = h
        u[self.ij] = j
        return u / sla.norm(u)

    def initial_mode(self, mode=1):
        return self.eigenmode(mode)

    def exact_solution(self, u0, t):
        return sla.expm(self.A * t) @ u0


class MaxwellModelND:
    """d-dimensional Maxwell model using the Yee staggered complex.

    Supports 1D Maxwell-London, 2D TM (state dimension 3 Nx Ny) and 3D
    full-vector Maxwell (state dimension 6 Nx Ny Nz).  In M = I the
    operator A is exactly skew-symmetric (and the discrete Poynting
    identity A^T M + M A = 0 holds to machine precision) when the
    boundary is "periodic".

    **Non-uniform materials.**  ``sigma_field`` (any dimension) replaces
    the scalar Ohmic conductivity by a non-negative weight per E grid
    point; ``omega_p_field`` (2D TM only) adds the London two-fluid
    current block (Jx, Jy) with a *non-uniform* plasma frequency, which
    is a non-uniform penetration depth lambda(x, y) = 1/omega_p(x, y).
    The material enters the structure exactly where the theory puts it:

      * the dissipation ``Sigma`` enters the E block only, so
        A^T M + M A = -2 Sigma holds *exactly* for any field Sigma >= 0;
      * the London weights enter the energy metric only,
        M = diag(1, 1, 1, lambda_x^2, lambda_y^2), so
        A^T M + M A = -2 Sigma holds for any positive field omega_p,
        and exp(A dt) is exactly M-orthogonal when Sigma = 0.

    A non-uniform material distribution therefore cannot break the
    port-Hamiltonian structure -- it *is* the metric (Prop. metric
    freedom), and the M-inner-product Krylov propagator
    (:class:`KrylovExponential` with ``metric=``) is the matching
    structure-preserving time integrator for it.

    Parameters
    ----------
    dim : {1, 2, 3}
    Ns  : grid sizes per axis
    Ls  : domain lengths per axis
    sigma : normal-fluid Ohmic dissipation (set to 0 to disable)
    sigma_field : array, optional
        Non-uniform Ohmic weights, broadcastable to the E-point shape
        ((Ne,) in 1D, (Nx, Ny) or (2, Nx, Ny) in 2D TM,
        (Nx, Ny, Nz) or (3, Nx, Ny, Nz) in 3D).  Overrides ``sigma``.
    omega_p_field : array, optional (2D TM only)
        Strictly positive London plasma frequency per E point
        (broadcastable to (2, Nx, Ny)); activates the (Jx, Jy) block
        and the non-uniform energy metric.
    boundary : "periodic" or "pec" (2D TM only)
    matrix_free : bool
        3D only.  If True the sparse assembly of A is skipped and all
        operator applications go through :class:`YeeOperator3D`, whose
        memory footprint is O(n) instead of O(24 n_per) nnz.  Needed for
        the large-scale experiments.
    """

    def __init__(self, dim, Ns, Ls=None, sigma=0.0, boundary="periodic",
                 matrix_free=False, stencil="one-sided", sigma_field=None,
                 omega_p_field=None):
        self.dim = dim
        self.Ns = tuple(int(n) for n in Ns)
        self.Ls = tuple(Ls) if Ls is not None else tuple(1.0 for _ in range(dim))
        self.boundary = boundary
        self.stencil = stencil
        self.omega_p_field = None
        if sigma_field is not None and omega_p_field is None:
            sf = np.asarray(sigma_field, dtype=float)
            if np.any(sf < 0.0):
                raise ValueError("sigma_field must be non-negative")
        self.sigma_field = None if sigma_field is None else np.asarray(
            sigma_field, dtype=float)
        self.sigma = 0.0 if self.sigma_field is not None else float(sigma)

        if dim == 1:
            D, Dt, dz = yee_operators_1d(self.Ns[0], self.Ls[0])
            self.D, self.Dt = D, Dt
            self.deltas = (dz,)
            self.Ne, self.Nh = D.shape
            self.n = 2 * self.Ne + self.Nh
            self.A = sp.csr_matrix(self._assemble_1d())
            self.M = sp.eye(self.n)
        elif dim == 2:
            Cex, Cey, Chzx, Chzy, dx, dy = yee_operators_2d_tm(
                self.Ns[0], self.Ns[1], self.Ls[0], self.Ls[1], boundary=boundary)
            self.Cex_hz, self.Cey_hz, self.Chz_ex, self.Chz_ey = Cex, Cey, Chzx, Chzy
            self.deltas = (dx, dy)
            n_per = self.Ns[0] * self.Ns[1]
            self.nE = 2 * n_per
            self.nH = n_per
            if omega_p_field is not None:
                wpf = np.asarray(omega_p_field, dtype=float)
                try:
                    wpf = np.broadcast_to(wpf, (2, self.Ns[0], self.Ns[1]))
                except ValueError:
                    raise ValueError(
                        "omega_p_field must be broadcastable to (2, Nx, Ny)")
                if np.any(wpf <= 0.0):
                    raise ValueError(
                        "omega_p_field must be strictly positive; use a small "
                        "value (a large penetration depth) for normal metal")
                self.omega_p_field = np.array(wpf, dtype=float)
                self.nJ = 2 * n_per
                self.n = 5 * n_per
            else:
                self.nJ = 0
                self.n = 3 * n_per
            self.A = self._assemble_2d()
            if self.omega_p_field is not None:
                lam2 = 1.0 / self.omega_p_field ** 2
                mdiag = np.concatenate([
                    np.ones(2 * n_per), np.ones(n_per),
                    lam2[0].ravel(), lam2[1].ravel()])
                self.M = sp.diags(mdiag, format="csr")
                self.metric_diag = mdiag
            else:
                self.M = sp.eye(self.n)
                self.metric_diag = np.ones(self.n)
        elif dim == 3:
            if boundary != "periodic":
                raise ValueError("3D Maxwell only supports periodic boundaries")
            if omega_p_field is not None:
                raise ValueError("omega_p_field is only supported in 2D TM")
            n_per = self.Ns[0] * self.Ns[1] * self.Ns[2]
            self.nE = 3 * n_per
            self.nH = 3 * n_per
            self.n = 6 * n_per
            # Matrix-free representation (no 24 n_per nnz assembly).
            self.op = YeeOperator3D(
                self.Ns[0], self.Ns[1], self.Ns[2],
                self.Ls[0], self.Ls[1], self.Ls[2], sigma=self.sigma,
                stencil=stencil, sigma_field=sigma_field)
            self.deltas = self.op.h
            if matrix_free:
                self.A = None
            else:
                (Cex_hz, Cex_hy, Cey_hz, Cey_hx, Cez_hx, Cez_hy,
                 Chx_ey, Chx_ez, Chy_ex, Chy_ez, Chz_ex, Chz_ey,
                 dx, dy, dz) = yee_operators_3d(
                    self.Ns[0], self.Ns[1], self.Ns[2],
                    self.Ls[0], self.Ls[1], self.Ls[2], boundary="periodic",
                    stencil=stencil)
                self.Cex_hz, self.Cex_hy = Cex_hz, Cex_hy
                self.Cey_hz, self.Cey_hx = Cey_hz, Cey_hx
                self.Cez_hx, self.Cez_hy = Cez_hx, Cez_hy
                self.Chx_ey, self.Chx_ez = Chx_ey, Chx_ez
                self.Chy_ex, self.Chy_ez = Chy_ex, Chy_ez
                self.Chz_ex, self.Chz_ey = Chz_ex, Chz_ey
                self.A = self._assemble_3d()
            self.M = sp.eye(self.n)
            self.metric_diag = np.ones(self.n)
        else:
            raise ValueError("dim must be 1, 2 or 3")

        self.matrix_free = bool(matrix_free)

    def matvec(self, u):
        """Apply A: matrix-free for 3D, sparse/dense otherwise."""
        if self.dim == 3:
            return self.op.matvec(u)
        return self.A @ u

    def __matmul__(self, u):
        return self.matvec(u)

    def cfl_dt(self):
        """Explicit Yee leapfrog stability limit (unit wave speed)."""
        if self.dim == 3:
            return self.op.cfl_dt()
        if self.dim == 2:
            dx, dy = self.deltas
            return 1.0 / np.sqrt(1.0 / dx ** 2 + 1.0 / dy ** 2)
        dz = self.deltas[0]
        return dz

    def _assemble_1d(self):
        # Reuse the dense 1D assembly for accuracy.
        if self.sigma_field is not None:
            Ne, Nh = self.Ne, self.Nh
            # same (e, h, j) layout as SuperconductingModel (j inert here)
            sig = np.broadcast_to(np.asarray(self.sigma_field, float), (Ne,))
            top = sp.hstack([-sp.diags(np.asarray(sig, float)), self.D,
                             sp.csr_matrix((Ne, Ne))], format="csr")
            mid = sp.hstack([self.Dt, sp.csr_matrix((Nh, Nh)),
                             sp.csr_matrix((Nh, Ne))], format="csr")
            bot = sp.csr_matrix((Ne, self.n))
            return sp.vstack([top, mid, bot], format="csr")
        m = SuperconductingModel(N=self.Ns[0], L=self.Ls[0],
                                  omega_p=0.0, sigma=self.sigma)
        return m.A

    def _sigma_e_diag(self):
        """Diagonal of the Ohmic weights on the E block (length nE)."""
        if self.dim == 1:
            return np.broadcast_to(np.asarray(self.sigma_field, float),
                                   (self.Ne,))
        if self.dim == 2:
            n_per = self.Ns[0] * self.Ns[1]
            if self.sigma_field is None:
                return np.full(2 * n_per, self.sigma)
            sf = np.asarray(self.sigma_field, float)
            try:
                sf = np.broadcast_to(sf, (2, self.Ns[0], self.Ns[1]))
            except ValueError:
                raise ValueError(
                    "sigma_field must be broadcastable to (2, Nx, Ny)")
            return np.concatenate([sf[0].ravel(), sf[1].ravel()])
        n_per = self.Ns[0] * self.Ns[1] * self.Ns[2]
        if self.sigma_field is None:
            return np.full(3 * n_per, self.sigma)
        sf = np.broadcast_to(np.asarray(self.sigma_field, float),
                             (3, self.Ns[2], self.Ns[1], self.Ns[0]))
        out = np.empty(3 * n_per)
        for c in range(3):
            out[c * n_per:(c + 1) * n_per] = sf[c].ravel()
        return out

    def _assemble_2d(self):
        nE = self.nE
        nH = self.nH
        n = self.n
        # curl H -> E
        C_EH = sp.vstack([self.Cex_hz, self.Cey_hz], format="csr")
        # curl E -> H (negative for Faraday)
        Chz_full = sp.hstack([self.Chz_ex, self.Chz_ey], format="csr")
        sig = self._sigma_e_diag()
        I_E = -sp.diags(sig, format="csr")
        if self.omega_p_field is None:
            top = sp.hstack([I_E, C_EH], format="csr")
            bot = sp.hstack([Chz_full, sp.csr_matrix((nH, nH))], format="csr")
            return sp.vstack([top, bot], format="csr")
        # Two-fluid block: state (Ex, Ey, Hz, Jx, Jy),
        #   E' = C_EH H - Sigma E - J,   H' = C_h E,   J' = Omega^2 E,
        # with the non-uniform metric M = diag(1, 1, 1, lambda_x^2,
        # lambda_y^2), lambda = 1/omega_p.  A^T M + M A = -2 Sigma on the
        # E block holds *exactly* for arbitrary positive omega_p(x, y)
        # and non-negative Sigma(x, y) (the metric carries the material).
        nJ = self.nJ
        n_per = self.Ns[0] * self.Ns[1]
        w2 = self.omega_p_field ** 2
        Omega2 = sp.diags(np.concatenate([w2[0].ravel(), w2[1].ravel()]),
                          format="csr")
        EJ_I = sp.eye(nE, format="csr")       # E-rows: -J
        JE = Omega2                            # J-rows: +Omega^2 E
        # E rows: [-Sigma, C_EH, -I]
        top = sp.hstack([I_E, C_EH, -EJ_I], format="csr")
        # H rows: [C_h, 0, 0]
        mid = sp.hstack([Chz_full, sp.csr_matrix((nH, nH)),
                         sp.csr_matrix((nH, nJ))], format="csr")
        # J rows: [Omega^2, 0, 0]
        bot = sp.hstack([JE, sp.csr_matrix((nJ, nH)),
                         sp.csr_matrix((nJ, nJ))], format="csr")
        return sp.vstack([top, mid, bot], format="csr")

    def _assemble_3d(self):
        n_per = self.Ns[0] * self.Ns[1] * self.Ns[2]
        # Block from (Hx, Hy, Hz) to (Ex, Ey, Ez):
        #   Ex += Cex_hz * Hz + Cex_hy * Hy      [cols: Hx | Hy | Hz]
        #   Ey += Cey_hx * Hx + Cey_hz * Hz
        #   Ez += Cez_hx * Hx + Cez_hy * Hy
        top_right = sp.hstack([
            sp.csr_matrix((n_per, n_per)), self.Cex_hy, self.Cex_hz
        ], format="csr")
        mid_right = sp.hstack([
            self.Cey_hx, sp.csr_matrix((n_per, n_per)), self.Cey_hz
        ], format="csr")
        bot_right = sp.hstack([
            self.Cez_hx, self.Cez_hy, sp.csr_matrix((n_per, n_per))
        ], format="csr")
        C_EH = sp.vstack([top_right, mid_right, bot_right], format="csr")
        # Block from (Ex, Ey, Ez) to (Hx, Hy, Hz):
        H_from_E_top = sp.hstack([
            sp.csr_matrix((n_per, n_per)), self.Chx_ey, self.Chx_ez
        ], format="csr")
        H_from_E_mid = sp.hstack([
            self.Chy_ex, sp.csr_matrix((n_per, n_per)), self.Chy_ez
        ], format="csr")
        H_from_E_bot = sp.hstack([
            self.Chz_ex, self.Chz_ey, sp.csr_matrix((n_per, n_per))
        ], format="csr")
        Ch_full = sp.vstack([H_from_E_top, H_from_E_mid, H_from_E_bot], format="csr")
        if self.op._sigma is not None:
            sig = self.op._sigma.reshape(3, -1).ravel()
            I_E = -sp.diags(sig, format="csr")
        else:
            I_E = -self.sigma * sp.eye(self.nE)
        top = sp.hstack([I_E, C_EH], format="csr")
        bot = sp.hstack([Ch_full, sp.csr_matrix((self.nH, self.nH))], format="csr")
        return sp.vstack([top, bot], format="csr")

    def energy(self, u):
        u = np.asarray(u, dtype=float)
        return 0.5 * float(u @ (self.M @ u))

    def london_projection(self, h0, j0=None):
        """Direct solve of the characterization of the static London state.

        The kernel of the two-fluid 2D generator is K = {(0, h, C_EH h)};
        the omega -> 0 limit of exp(A t) u0 is the M-orthogonal
        projection of u0 onto K.  For u0 = (0, h0, j0) that projection is
        the minimizer of

            F(h) = 1/2 |h - h0|^2 + 1/2 <lambda^2 (C_EH h - j0), C_EH h - j0>,

        i.e. the solution of the *discrete screening (London) equation*

            (I + C_h^T lambda^2 C_EH) h* = h0 + C_h^T (lambda^2 j0),

        a sparse SPD system (C_h = -C_EH^T).  This is the state the
        relaxation dynamics must converge to; comparing the time
        integration with this direct solve is the E11 audit.
        """
        if self.dim != 2 or self.omega_p_field is None:
            raise ValueError("london_projection requires the 2D two-fluid "
                             "model (omega_p_field)")
        C_EH = sp.vstack([self.Cex_hz, self.Cey_hz], format="csr")
        n_per = self.Ns[0] * self.Ns[1]
        lam2 = 1.0 / self.omega_p_field ** 2
        L2 = sp.diags(np.concatenate([lam2[0].ravel(), lam2[1].ravel()]))
        rhs = np.asarray(h0, dtype=float).ravel()
        if j0 is not None:
            rhs = rhs + C_EH.T @ (L2 @ np.asarray(j0, dtype=float).ravel())
        K = sp.eye(n_per) + C_EH.T @ L2 @ C_EH
        return sp.linalg.spsolve(K.tocsc(), rhs)

    def kernel_residual(self, u):
        """||e|| + ||J - C_EH h||: zero iff the state is in ker(A).

        The static London manifold of the two-fluid model is exactly
        {(0, h, C_EH h)}; this residual certifies that the relaxed
        dynamics has landed on it.
        """
        u = np.asarray(u, dtype=float)
        n_per = self.Ns[0] * self.Ns[1]
        ex = u[:n_per]
        ey = u[n_per:2 * n_per]
        hz = u[2 * n_per:3 * n_per]
        jx = u[3 * n_per:4 * n_per]
        jy = u[4 * n_per:5 * n_per]
        eh = self.Cex_hz @ hz
        ee = self.Cey_hz @ hz
        num = float(np.linalg.norm(np.concatenate([ex, ey]))
                    + np.linalg.norm(jx - eh) + np.linalg.norm(jy - ee))
        den = max(float(np.linalg.norm(u)), 1e-300)
        return num / den

    def skew_quadratic(self, u=None, seed=0):
        """``|u^T A u| / (||u|| ||A u||)``: zero iff A is skew-adjoint.

        Works matrix-free, so it certifies the structure of the
        operator at the very large n used in experiment E10.
        """
        if u is None:
            u = np.random.default_rng(seed).standard_normal(self.n)
        u = np.asarray(u, dtype=float)
        Au = self.matvec(u)
        den = float(np.linalg.norm(u)) * float(np.linalg.norm(Au))
        return abs(float(u @ Au)) / den if den > 0.0 else 0.0

    def exact_solution(self, u0, t):
        if self.n <= 300:
            return sla.expm(self.A.toarray() * t) @ u0
        from scipy.sparse.linalg import expm_multiply
        return expm_multiply(self.A, u0, t)

    def dissipation_residual(self):
        """||A^T M + M A + 2 Sigma_E||_F (Sigma_E on the E block only).

        For uniform sigma this is the classical residual; with
        ``sigma_field`` / ``omega_p_field`` the metric M is non-uniform
        and the identity must hold with the *field* Sigma, which is the
        algebraic statement that a non-uniform material distribution
        cannot break the port-Hamiltonian structure.
        """
        nE = getattr(self, "nE", 0)
        if nE == 0:
            nE = self.Ne  # 1D: the E block is the first Ne rows
        A = self.A
        M = self.M
        if self.dim == 3:
            if self.op._sigma is not None:
                sig = self.op._sigma.reshape(3, -1).ravel()
            else:
                sig = np.full(self.nE, self.op.sigma)
        else:
            sig = self._sigma_e_diag()
        # 2 Sigma on the E block, zero elsewhere.
        Se = sp.vstack([
            sp.hstack([2.0 * sp.diags(sig),
                       sp.csr_matrix((nE, self.n - nE))]),
            sp.csr_matrix((self.n - nE, self.n)),
        ], format="csr")
        R = (A.T @ M + M @ A + Se)
        return float(spla.norm(R))

    def skew_residual(self):
        """||A^T + A||_F  (only for sigma = 0)."""
        A = self.A
        return float(spla.norm(A.T + A))


# =========================================================================
# Part 3: TDGL nonlinear model (1D)
# =========================================================================


class TDGLModel1D:
    """Reduced 1D Ginzburg-Landau-type relaxation model (nonlinear coupling).

    MODEL SCOPE -- this is deliberately *not* a discretization of the full
    time-dependent Ginzburg-Landau system, and is not claimed to be one:

      * the order parameter is relaxed *locally*, i.e. the psi-block below
        contains no gradient (kinetic) term  (-i grad - A)^2 psi, no vector
        potential A and hence no gauge coupling and no vortex dynamics;
      * there is no gauge-invariant discrete energy identity;
      * the "energy" of this reduced model is the electromagnetic energy
        plus the order-parameter penalty used here,
            W = 1/2 (|e|^2 + |h|^2 + |psi|^2),
        which is *not* the Ginzburg-Landau free energy
        (that one contains |(-i grad - A) psi|^2 and (1 - |psi|^2)^2/2).

    What the model does support is the structure-preserving statement we
    test: a skew-symmetric (Maxwell-London) linear sub-flow, reproducable
    by precise integration to machine precision, coupled to a strictly
    dissipative local nonlinearity, integrated by an IMEX Strang splitting
    that is energy monotone for *every* step size.

    State u = (e_y, h_x, u_psi, v_psi) with u_psi = Re(psi), v_psi = Im(psi),
    |psi|^2 = u_psi^2 + v_psi^2.

    Semi-discrete system (skew-symmetric linear sub-flow + dissipative N)

        d e /dt =  D h  -  sigma e  -  beta |psi|^2 e      (Ampere + GL current)
        d h /dt =  D^T e                                    (Faraday)
        d u /dt =  kappa v  -  beta |psi|^2 u               (Re psi)
        d v /dt = -kappa u  -  beta |psi|^2 v               (Im psi)

    Splitting  du/dt = L u + N(u):

        L is skew-symmetric in M = I except for the -sigma block (which
        is dissipative and hence neutral in the IMEX sense).  It is
        precise-integrated to machine precision.

        N is dissipative:  ⟨u, N(u)⟩ = -beta |psi|^2 (|e|^2 + |u|^2 + |v|^2)
        so  dW/dt|_N = -2 beta |psi|^2 (|e|^2 + |u|^2 + |v|^2) <= 0.

    The nonlinear sub-flow preserves the proportional scaling
    (e(t)/e_0 = u(t)/u_0 = v(t)/v_0) so the implicit Crank-Nicolson step
    is solved by a 3x3 per-cell Newton iteration; because the cell block
    acts as a single scalar scaling, that iteration collapses to one
    scalar Newton solve per cell in closed form -- see
    :meth:`scaling_factor` and :meth:`nonlinear_step_exact`.
    """

    def __init__(self, N=64, L=1.0, sigma=0.0, beta=1.0, kappa=1.0):
        self.N = N
        self.L = L
        self.dz = L / N
        self.sigma = float(sigma)
        self.beta = float(beta)
        self.kappa = float(kappa)
        self.D, self.Dt, _ = yee_operators_1d(N, L)
        self.Ne, self.Nh = self.D.shape
        self.nE = self.Ne
        self.nH = self.Nh
        self.nP = self.Ne
        self.n = 3 * self.Ne + self.Nh
        self.ie = np.arange(0, self.Ne)
        self.ih = np.arange(self.Ne, self.Ne + self.Nh)
        self.iu = np.arange(self.Ne + self.Nh, self.Ne + self.Nh + self.Ne)
        self.iv = np.arange(self.Ne + self.Nh + self.Ne, self.n)
        self.L_mat = self._assemble_linear()
        self.N_func = self._nonlinear
        self.N_jac = self._nonlinear_jac

    def _assemble_linear(self):
        n = self.n
        L = np.zeros((n, n))
        Ne, Nh = self.Ne, self.Nh
        L[np.ix_(self.ie, self.ih)] = self.D
        L[np.ix_(self.ie, self.ie)] += -self.sigma * np.eye(Ne)
        L[np.ix_(self.ih, self.ie)] = self.Dt
        # GL rotation: psi -> -i kappa psi (in real form: [u', v'] = kappa [v, -u])
        L[np.ix_(self.iu, self.iv)] = self.kappa * np.eye(Ne)
        L[np.ix_(self.iv, self.iu)] = -self.kappa * np.eye(Ne)
        return L

    def _nonlinear(self, u):
        e = u[self.ie]
        up = u[self.iu]
        vp = u[self.iv]
        r2 = up ** 2 + vp ** 2
        out = np.zeros_like(u)
        out[self.ie] = -self.beta * r2 * e
        out[self.ih] = 0.0
        out[self.iu] = -self.beta * r2 * up
        out[self.iv] = -self.beta * r2 * vp
        return out

    def _nonlinear_jac(self, u):
        n = self.n
        Ne = self.Ne
        J = np.zeros((n, n))
        e = u[self.ie]
        up = u[self.iu]
        vp = u[self.iv]
        r2 = up ** 2 + vp ** 2
        for k in range(Ne):
            r2k = r2[k]
            J[self.ie[k], self.ie[k]] = -self.beta * r2k
            J[self.ie[k], self.iu[k]] = -2 * self.beta * up[k] * e[k]
            J[self.ie[k], self.iv[k]] = -2 * self.beta * vp[k] * e[k]
            J[self.iu[k], self.iu[k]] = -self.beta * r2k - 2 * self.beta * up[k] ** 2
            J[self.iu[k], self.iv[k]] = -2 * self.beta * up[k] * vp[k]
            J[self.iv[k], self.iu[k]] = -2 * self.beta * up[k] * vp[k]
            J[self.iv[k], self.iv[k]] = -self.beta * r2k - 2 * self.beta * vp[k] ** 2
        return J

    def scaling_factor(self, u, dt, tol=1e-15, max_iter=60):
        """Closed-form per-cell Crank-Nicolson scaling factor gamma.

        The nonlinear sub-flow maps a cell state (e, u, v) onto
        gamma * (e, u, v), and the trapezoidal (Crank-Nicolson) rule of
        the cell block is the scalar cubic

            f(gamma) = gamma - 1 + (c/2) (1 + gamma^3) = 0 ,
            c = dt * beta * |psi|^2 .

        f is strictly increasing (f' = 1 + 3 c gamma^2 / 2 > 0) with
        f(-1) = -2 < 0 < f(1) = c, so its unique real root lies in the
        open interval (-1, 1).  Therefore |gamma| < 1: the discrete
        nonlinear step is non-expansive for *every* dt and the energy
        W strictly decreases, cell by cell.  For c < 2 the root is
        positive, i.e. the damping does not reverse the sign of the order
        parameter; for c > 2 the (still non-expansive) factor overshoots
        through zero, which is the usual artifact of Crank-Nicolson on a
        stiff gradient flow.
        """
        up = u[self.iu]
        vp = u[self.iv]
        c = dt * self.beta * (up ** 2 + vp ** 2)
        g = np.zeros_like(c)
        for _ in range(max_iter):
            f = g - 1.0 + 0.5 * c * (1.0 + g ** 3)
            fp = 1.0 + 1.5 * c * g ** 2
            dg = -f / fp
            g = g + dg
            if float(np.max(np.abs(dg))) < tol:
                break
        return g

    def nonlinear_step_exact(self, u, dt, **kw):
        """Exact O(n) Crank-Nicolson step of the nonlinear sub-flow.

        One scalar Newton solve per grid cell (no matrix, no dense
        Jacobian): the cell block is a single scalar scaling, so the
        nominal 3x3 Newton iteration collapses to :meth:`scaling_factor`.
        """
        g = self.scaling_factor(u, dt, **kw)
        out = u.copy()
        out[self.ie] = g * u[self.ie]
        out[self.iu] = g * u[self.iu]
        out[self.iv] = g * u[self.iv]
        return out

    def energy(self, u):
        """Reduced-model energy W = 1/2 (e^2 + h^2 + u^2 + v^2).

        dW/dt = -sigma e^2 - beta |psi|^2 (e^2 + u^2 + v^2) <= 0.

        W is *not* the Ginzburg-Landau free energy (see the model scope
        note in the class docstring): it is the electromagnetic energy
        plus the local order-parameter penalty.
        """
        return 0.5 * float(u @ u)


# =========================================================================
# Part 3b: gauge-invariant TDGL (2D, link variables)
# =========================================================================


class GaugeTDGL2D:
    """Gauge-invariant discrete TDGL with link variables (2D, periodic).

    MODEL.  The order parameter ``psi`` is a complex field on the primal
    nodes (i, j) of the periodic Yee grid; the vector potential enters
    only through the *link variables*

        U^x_{i,j} = exp(-i theta^x_{i,j}),   U^y_{i,j} = exp(-i theta^y_{i,j}),

    living on exactly the staggered locations of the electric field of
    the Yee grid (theta^x at (i+1/2, j), theta^y at (i, j+1/2)); theta
    is the dimensionless line integral of A along the link.  Links are
    free variables, so *any* flux pattern, including a background field
    on the torus, is representable.

    GAUGE GROUP.  The discrete gauge group is the node-wise phase group
    ``G = {e^{i chi}}`` acting by

        psi_{i,j}      ->  e^{i chi_{i,j}} psi_{i,j},
        theta^x_{i,j}  ->  theta^x_{i,j} + chi_{i+1,j} - chi_{i,j},
        theta^y_{i,j}  ->  theta^y_{i,j} + chi_{i,j+1} - chi_{i,j},

    under which the covariant difference

        (D_A psi)_{i+1/2,j} = (U^x_{i,j} psi_{i+1,j} - psi_{i,j}) / dx

    transforms by the *scalar* phase e^{i chi_{i,j}}.  Consequently

      * the discrete Ginzburg-Landau energy
        W = 1/2 sum_links |U psi_next - psi|^2
            + (w/2) sum_nodes (1 - |psi|^2)^2 ,  w = (h/xi)^2,
        is *exactly* gauge invariant (an algebraic identity, verified to
        round-off in ``check_theory`` item 30);
      * the gradient-flow dynamics d psi/dt = -i kappa psi - dW/d psi*
        is *exactly* gauge covariant: gauge-equivalent initial data
        remain gauge equivalent after every step of the splitting below
        (up to the tolerance of the sparse linear solves).

    SPLITTING (IMEX-Strang).  The sub-flows are

      Phi_prec(dt):   psi -> exp(-i kappa dt) psi   -- a global phase, so
        W is exactly invariant (both W-terms depend on phase differences
        and |psi| only);
      Phi_diff(dt):   psi' = (1/2)(S - 4I) psi = -(1/2) Lambda psi, the
        covariant (massive) Laplacian, by a Crank-Nicolson solve with the
        *fixed* sparse complex matrix (I + dt Lambda/4) — the Cayley
        transform of a Hermitian PSD operator, hence exactly
        non-expansive in |psi|_{L2} and exactly W_kin-dissipative for
        every dt;
      Phi_pot(dt):    psi' = w (1 - |psi|^2) psi per node -- the logistic
        flow of x = |psi|^2, integrated by its *exact* closed-form
        solution x1 = x0 E / (1 + x0 (E - 1)), E = exp(2 w dt) (the
        phase of psi is untouched), which keeps x in [0, 1], is strictly
        monotone towards 1, and strictly decreases the potential
        (1 - x)^2 for every dt >= 0 (no step-size restriction at all).

    The Strang step Phi(dt) = Phi_prec(dt/2) Phi_pot(dt/2) Phi_diff(dt)
    Phi_pot(dt/2) Phi_prec(dt/2) is symmetric (second order) and exactly
    gauge covariant.  Total-W monotonicity of the composition is
    observed at every step in all experiments (E13) but is not claimed
    as a theorem: the provable statements are the three sub-flow
    identities above.

    TOPOLOGY.  The gauge-invariant phase difference on a link,
    arg(U psi_next psi*), sums around a plaquette to 2 pi (winding +
    applied flux / 2 pi); the plaquette winding array therefore *counts
    vortices* and is the discrete counterpart of the topological charge.
    """

    def __init__(self, Nx, Ny, Lx=1.0, Ly=1.0, xi=None, kappa=0.3):
        self.Nx, self.Ny = int(Nx), int(Ny)
        self.Lx, self.Ly = float(Lx), float(Ly)
        self.hx, self.hy = Lx / Nx, Ly / Ny
        self.kappa = float(kappa)
        if xi is None:
            xi = 4.0 * max(self.hx, self.hy)
        self.xi = float(xi)
        # potential weight w = (h/xi)^2 (see the class docstring)
        self.w = (np.sqrt(self.hx * self.hy) / self.xi) ** 2
        self.shape = (Nx * Ny, Nx * Ny)
        self.n = Nx * Ny
        # link phases (dimensionless): theta_x[i, j] on link (i+1/2, j),
        # theta_y[i, j] on link (i, j+1/2).
        self.theta_x = np.zeros((Nx, Ny))
        self.theta_y = np.zeros((Nx, Ny))
        self._lu = None
        self._lu_dt = None

    # -- gauge structure ---------------------------------------------------
    def set_background_flux(self, n_flux):
        """Links carrying ``n_flux`` flux quanta through the torus.

        theta^x_{i,j} = 2 pi f j with f = n_flux / Ny: each plaquette
        then carries flux -2 pi f and the total flux is n_flux * 2 pi.
        Links are free variables, so no consistency condition appears.
        """
        f = int(n_flux) / float(self.Ny)
        self.theta_x = np.broadcast_to(
            2.0 * np.pi * f * np.arange(self.Ny)[None, :],
            (self.Nx, self.Ny)).copy()
        self.theta_y = np.zeros((self.Nx, self.Ny))
        self._lu = None
        return self

    def gauge_transform(self, psi, chi):
        """Apply the discrete gauge transform with node phases ``chi``.

        Returns (psi', theta^x', theta^y') with psi' = e^{i chi} psi and
        the link shifts chi_next - chi (see the class docstring).  The
        current link state of the object is *not* modified.
        """
        chi = np.asarray(chi, dtype=float)
        tx = self.theta_x + (np.roll(chi, -1, axis=0) - chi)
        ty = self.theta_y + (np.roll(chi, -1, axis=1) - chi)
        return np.exp(1j * chi) * psi, tx, ty

    # -- energy -------------------------------------------------------------
    def energy(self, psi, theta_x=None, theta_y=None):
        """Gauge-invariant discrete GL energy (see the class docstring)."""
        psi = np.asarray(psi, dtype=complex).reshape(self.Nx, self.Ny)
        tx = self.theta_x if theta_x is None else theta_x
        ty = self.theta_y if theta_y is None else theta_y
        Ux = np.exp(-1j * tx)
        Uy = np.exp(-1j * ty)
        dx_psi = Ux * np.roll(psi, -1, axis=0) - psi
        dy_psi = Uy * np.roll(psi, -1, axis=1) - psi
        kin = 0.5 * float(np.sum(np.abs(dx_psi) ** 2)
                          + np.sum(np.abs(dy_psi) ** 2))
        x = np.abs(psi) ** 2
        pot = 0.5 * self.w * float(np.sum((1.0 - x) ** 2))
        return kin + pot

    # -- operators ------------------------------------------------------------
    def covariant_laplacian(self, psi, theta_x=None, theta_y=None):
        """``(1/2)(S - 4I) psi`` — the dissipative covariant sub-flow RHS.

        S psi has the link-covariant neighbour sum (U psi_next); the
        matrix is Hermitian PSD (it is -(1/2) D_A^* D_A with D_A the
        covariant difference scaled by 1/h), so its Crank-Nicolson Cayley
        transform is exactly non-expansive for every dt.
        """
        psi = np.asarray(psi, dtype=complex).reshape(self.Nx, self.Ny)
        tx = self.theta_x if theta_x is None else theta_x
        ty = self.theta_y if theta_y is None else theta_y
        Ux = np.exp(-1j * tx)
        Uy = np.exp(-1j * ty)
        # forward links carry U, backward links carry conj(U) of *their*
        # own link (the link (i-1, j) -> (i, j) is U^x_{i-1, j}).
        Sx = Ux * np.roll(psi, -1, axis=0) \
            + np.conj(np.roll(Ux, 1, axis=0)) * np.roll(psi, 1, axis=0)
        Sy = Uy * np.roll(psi, -1, axis=1) \
            + np.conj(np.roll(Uy, 1, axis=1)) * np.roll(psi, 1, axis=1)
        return 0.5 * (Sx + Sy - 4.0 * psi)

    def _diffusion_matrix(self):
        """Sparse complex form of the covariant Laplacian (for CN solves)."""
        Nx, Ny = self.Nx, self.Ny
        n = Nx * Ny
        idx = np.arange(n).reshape(Nx, Ny)
        rows, cols, vals = [], [], []
        diag = -2.0 * np.ones(n)
        # x-links: (i,j) -> (i+1,j) carries U^x_{i,j} = exp(-i theta^x)
        Ux = np.exp(-1j * self.theta_x)
        Uy = np.exp(-1j * self.theta_y)
        r = idx.ravel()
        rows.append(r); cols.append(r); vals.append(diag)
        rows.append(idx.ravel())
        cols.append(np.roll(idx, -1, axis=0).ravel())
        vals.append(0.5 * Ux.ravel())
        rows.append(idx.ravel())
        cols.append(np.roll(idx, 1, axis=0).ravel())
        vals.append(0.5 * np.conj(np.roll(Ux, 1, axis=0)).ravel())
        rows.append(idx.ravel())
        cols.append(np.roll(idx, -1, axis=1).ravel())
        vals.append(0.5 * Uy.ravel())
        rows.append(idx.ravel())
        cols.append(np.roll(idx, 1, axis=1).ravel())
        vals.append(0.5 * np.conj(np.roll(Uy, 1, axis=1)).ravel())
        A = sp.csr_matrix((np.concatenate(vals),
                           (np.concatenate(rows), np.concatenate(cols))),
                          shape=(n, n), dtype=complex)
        return A

    def _factor(self, dt):
        if self._lu is None or self._lu_dt != dt:
            L = self._diffusion_matrix()
            import scipy.sparse.linalg as spla
            self._lu = spla.splu((sp.eye(self.n, dtype=complex)
                                  - 0.5 * dt * L).tocsc())
            self._lu_dt = dt
        return self._lu

    # -- sub-flows ------------------------------------------------------------
    def precession_step(self, psi, dt):
        """Phi_prec: exact global phase e^{-i kappa dt} (W-invariant)."""
        return np.exp(-1j * self.kappa * dt) * psi

    def diffusion_step(self, psi, dt, theta_x=None, theta_y=None):
        """Phi_diff: Crank-Nicolson Cayley step of the covariant Laplacian.

        Exactly non-expansive in the L2 norm and exactly W_kin-dissipative
        for every dt (the matrix is Hermitian PSD and commutes with the
        CN factor); gauge covariant up to the sparse-solve tolerance.
        """
        external = theta_x is not None
        saved = None
        if external:
            saved = (self.theta_x, self.theta_y, self._lu, self._lu_dt)
            self.theta_x = np.asarray(theta_x, dtype=float)
            self.theta_y = np.asarray(theta_y, dtype=float)
            self._lu = None
        try:
            lu = self._factor(dt)
            L = self._diffusion_matrix()
            rhs = psi.reshape(-1) + 0.5 * dt * L.dot(psi.reshape(-1))
            out = lu.solve(rhs).reshape(self.Nx, self.Ny)
        finally:
            if external:
                self.theta_x, self.theta_y, self._lu, self._lu_dt = saved
        return out

    def potential_step(self, psi, dt):
        """Phi_pot: exact closed-form logistic flow of the local potential.

        x = |psi|^2 obeys x' = 2 w (1 - x) x with the exact solution
        x1 = x0 E / (1 + x0 (E - 1)), E = exp(2 w dt), which stays in
        [0, 1], is strictly monotone towards 1 (for x0 in (0, 1)), and
        strictly decreases (1 - x)^2 for every dt >= 0.  The phase of
        psi is preserved, so the map is psi -> sqrt(x1/x0) psi.
        """
        psi = np.asarray(psi, dtype=complex)
        x0 = np.abs(psi) ** 2
        if dt == 0.0:
            return psi.copy()
        with np.errstate(over="ignore"):
            E = np.exp(2.0 * self.w * dt)
        if np.isfinite(E):
            # x1 = x0 E / (1 + x0 (E - 1)) rewritten to avoid overflow:
            # divide numerator and denominator by E.
            x1 = x0 / (x0 + (1.0 - x0) / E)
        else:
            # E -> inf: the exact flow sends x0 > 0 to 1 and x0 = 0 to 0.
            x1 = np.where(x0 > 0.0, 1.0, 0.0)
        scale = np.zeros_like(x0)
        mask = x0 > 0.0
        scale[mask] = np.sqrt(x1[mask] / x0[mask])
        return scale * psi

    def step(self, psi, dt):
        """One symmetric (Strang) step of the gauge-covariant IMEX flow."""
        psi = self.precession_step(psi, 0.5 * dt)
        psi = self.potential_step(psi, 0.5 * dt)
        psi = self.diffusion_step(psi, dt)
        psi = self.potential_step(psi, 0.5 * dt)
        psi = self.precession_step(psi, 0.5 * dt)
        return psi

    # -- diagnostics -----------------------------------------------------------
    def plaquette_winding(self, psi):
        """Gauge-invariant winding per plaquette (integer charge array).

        arg(U^x psi_next psi*) is gauge invariant on each link; the
        plaquette sum of its principal values equals 2 pi (winding +
        applied flux / 2 pi) whenever |psi| does not vanish on the loop.
        """
        psi = np.asarray(psi, dtype=complex).reshape(self.Nx, self.Ny)
        Ux = np.exp(-1j * self.theta_x)
        Uy = np.exp(-1j * self.theta_y)
        gx = np.angle(Ux * np.roll(psi, -1, axis=0) * np.conj(psi))
        gy = np.angle(Uy * np.roll(psi, -1, axis=1) * np.conj(psi))
        # plaquette (i, j): link x (i,j), link y (i+1,j), -link x (i,j+1),
        # -link y (i,j)
        w = gx + np.roll(gy, -1, axis=0) - np.roll(gx, -1, axis=1) - gy
        return w / (2.0 * np.pi)

    def total_winding(self, psi):
        """Total vortex number (applied flux quanta included).

        On the torus this telescopes to the *applied* flux only; use
        :meth:`loop_winding` for a localized measurement and
        :meth:`vortex_positions` for the per-plaquette charges.
        """
        return float(np.sum(self.plaquette_winding(psi)))

    def loop_winding(self, psi, i0, i1, j0, j1):
        """Gauge-invariant winding number around the rectangle of links
        (i0..i1) x (j0..j1) (0 <= i0 < i1 < Nx, similarly for j).

        The sum of the principal gauge-invariant phase differences along
        the closed link loop equals 2 pi times the winding number of the
        enclosed vortices (plus the enclosed applied flux / 2 pi), an
        integer whenever |psi| does not vanish on the loop.
        """
        psi = np.asarray(psi, dtype=complex).reshape(self.Nx, self.Ny)
        Ux = np.exp(-1j * self.theta_x)
        Uy = np.exp(-1j * self.theta_y)
        gx = np.angle(Ux * np.roll(psi, -1, axis=0) * np.conj(psi))
        gy = np.angle(Uy * np.roll(psi, -1, axis=1) * np.conj(psi))
        total = (np.sum(gx[i0:i1, j0]) + np.sum(gy[i1, j0:j1])
                 - np.sum(gx[i0:i1, j1]) - np.sum(gy[i0, j0:j1]))
        return total / (2.0 * np.pi)

    def vortex_positions(self, psi):
        """Grid positions of unit-winding plaquettes (rounded charges)."""
        w = self.plaquette_winding(psi)
        q = np.rint(w)
        pos = []
        for qi, qj in zip(*np.nonzero(np.abs(q) >= 0.5)):
            pos.append((float(qi), float(qj), int(q[qi, qj])))
        return pos

    def initial_vortex(self, charges_positions, amp=1.0):
        """psi = amp * prod_k tanh(r_k/xi)^{|q_k|} * exp(i phi).

        The phase phi is built so that the *plane* vortex charges (and
        only those) appear as plaquette windings: the plane angle
        theta = sum_k q_k arg(z - z_k) is sampled on the node grid, its
        *principal-value* differences are taken on every link (including
        the periodic seam links, evaluated with the plane formula at the
        wrapped coordinate), and phi is recovered by integrating the link
        phases along an L-shaped path.  Two integration paths differ by
        2 pi times the enclosed winding, which is invisible in exp(i phi),
        so the construction is exact for any configuration with total
        charge zero (a vortex-antivortex pair gives exactly two plaquette
        windings); a configuration with nonzero total charge necessarily
        leaves the compensating integer charge somewhere on the torus
        (its position depends on the integration path), which is the
        honest topological statement.
        """
        xc = (np.arange(self.Nx) + 0.5) * self.hx
        yc = (np.arange(self.Ny) + 0.5) * self.hy
        X, Y = np.meshgrid(xc, yc, indexing="ij")
        Xn, Yn = np.meshgrid(xc + self.hx, yc, indexing="ij")
        Xm, Ym = np.meshgrid(xc, yc + self.hy, indexing="ij")

        def theta_at(Xg, Yg):
            th = np.zeros_like(Xg)
            for (qx, qy, q) in charges_positions:
                th = th + q * np.arctan2(Yg - qy, Xg - qx)
            return th

        th = theta_at(X, Y)
        th_x = theta_at(Xn, Yn)          # neighbour at x + hx (plane formula:
        th_y = theta_at(Xm, Ym)          # valid across the periodic seam)
        pv = lambda d: (d + np.pi) % (2.0 * np.pi) - np.pi
        gx = pv(th_x - th)               # principal-value link phases
        gy = pv(th_y - th)

        # amplitude: product of the (periodic, minimal-image) core factors
        psi_amp = np.full((self.Nx, self.Ny), float(amp))
        for (qx, qy, q) in charges_positions:
            dx = X - qx
            dy = Y - qy
            dx = dx - self.Lx * np.rint(dx / self.Lx)
            dy = dy - self.Ly * np.rint(dy / self.Ly)
            r = np.hypot(dx, dy)
            psi_amp = psi_amp * np.tanh(np.maximum(r, 1e-12) / self.xi) ** abs(q)

        # integrate the link phases along an L-shaped path from node (0, 0):
        # first along x at j = 0, then along y in each column
        phix = np.concatenate(
            [[0.0], np.cumsum(gx[:-1, 0])])[:, None]
        phi = phix + np.concatenate(
            [np.zeros((self.Nx, 1)), np.cumsum(gy[:, :-1], axis=1)], axis=1)
        return psi_amp * np.exp(1j * phi)


# =========================================================================
# Part 4: Integrators
# =========================================================================


def precise_integration(A, dt, n_squarings=None, n_taylor=20,
                        use_expm_threshold=0):
    """Zhong Wanxie's ``2^N`` precise integration of the matrix exponential.

    The exponential is evaluated as

        exp(A dt) = [ T ]^(2^s),   T = sum_{k=0}^{n_taylor} (A tau)^k / k!,
        tau = dt / 2^s,

    with the truncated Taylor series taken over one *increment*.  Two
    error sources compete:

    * Taylor truncation   ``~ (||A||_F tau)^{n_taylor+1} / (n_taylor+1)!``
    * squaring round-off  ``~ 2^s u``  (``u`` machine epsilon)

    The classical choice ``2^s ~ 10^6`` (Zhong's ``2^20``) makes the
    truncation term vanish, but the round-off term then grows like
    ``2^s u``.  That is harmless for a *stiff* generator, yet fatal when
    ``A`` carries a **slow** mode: for Ohmic damping with
    ``sigma dt << 1`` the diagonal entry ``-sigma tau`` falls below ``u``
    and the mode is annihilated by the squaring, so the numerical flow
    becomes non-dissipative (a spurious, unbounded energy drift).

    Scaling by the generator norm instead, i.e. choosing ``2^s`` so that
    ``||A||_F tau = O(1)``, bounds the truncation error by ``1/(n_taylor+1)!``
    while keeping *every* mode of ``A tau`` -- dissipative ones included --
    far above round-off.  This is the choice made here; it recovers
    machine precision for both conservative and weakly dissipative
    generators (see ``check_theory`` items 6 and 19).

    Parameters
    ----------
    n_squarings : int or None
        ``s``; derived from ``||A||_F |dt|`` when ``None``.
    n_taylor : int
        Number of Taylor terms; 20 suffices for ``||A||_F tau <= 1``.
    use_expm_threshold : int
        If positive, matrices of size ``<= use_expm_threshold`` are routed
        to :func:`scipy.linalg.expm` (used only for cross-verification).
    """
    if sp.issparse(A):
        A = A.toarray()
    A = np.asarray(A, dtype=float)
    m = A.shape[0]
    if use_expm_threshold and m <= use_expm_threshold:
        return sla.expm(A * dt)
    if n_squarings is None:
        # The Taylor truncation is governed by the *spectral* norm; the
        # Frobenius norm can exceed it by a factor sqrt(m) and would force
        # needlessly many squarings.  (The SVD is skipped whenever ``s``
        # is supplied by the caller, e.g. by the small Krylov matrix.)
        nrm = float(sla.norm(A, 2)) * abs(dt)
        if nrm <= 1.0:
            n_squarings = 0
        else:
            n_squarings = int(np.ceil(np.log2(nrm)))
        # ``||A||_2 tau`` now lies in (1/2, 1]; fewer squarings would
        # hurt the Taylor truncation, more would amplify round-off.
        n_squarings = int(min(max(n_squarings, 0), 30))
    tau = dt / float(2 ** n_squarings)
    At = A * tau
    T = np.eye(m)
    F = np.eye(m)
    for k in range(1, n_taylor + 1):
        F = F @ At / k
        T = T + F
    for _ in range(n_squarings):
        T = T @ T
    return T


def hessenberg_exponential(H, dt, n_taylor=20):
    """``exp(H dt)`` for the small Arnoldi (Hessenberg) matrix.

    The Krylov realization of :class:`KrylovExponential` needs the
    exponential of the projected matrix only; this helper evaluates it with
    the *same* ``2^N`` precise-integration kernel as the dense propagator,
    so the code contains a single exponential kernel (``scipy``'s ``expm``
    is then used only as an independent reference in ``check_theory``).

    The number of squarings is taken from the **Frobenius** norm, which is
    available in ``O(m^2)`` instead of the ``O(m^3)`` of an SVD.  Since
    ``||H||_F <= sqrt(m) ||H||_2``, this costs at most three extra squarings
    for ``m <= 64`` and leaves the round-off of the small exponential at the
    ``10^-15`` level.  For a Krylov dimension of a few dozen the whole call
    is negligible against the ``m`` applications of ``A``.
    """
    nrm = float(sla.norm(H, "fro")) * abs(dt)
    if nrm <= 1.0:
        n_squarings = 0
    else:
        n_squarings = int(min(np.ceil(np.log2(nrm)), 30))
    return precise_integration(H, dt, n_squarings=n_squarings,
                               n_taylor=n_taylor)


def split_flows_1d(model, dt):
    """Exact propagators of the three 1D sub-flows."""
    m = model.n_aug
    Ne, Nh = model.Ne, model.Nh
    ie, ih, ij = model.ie, model.ih, model.ij
    Af = np.zeros((m, m))
    Af[np.ix_(ie, ih)] = model.D
    Af[np.ix_(ih, ie)] = model.Dt
    if model.driven:
        Af[model.ih[0], model.id_] = -1.0 / model.dz
    Phi_f = precise_integration(Af, dt)
    w = model.omega_p
    th = w * dt
    c, s = np.cos(th), np.sin(th)
    Phi_j = np.eye(m)
    Phi_j[np.ix_(ie, ie)] = c * np.eye(Ne)
    Phi_j[np.ix_(ie, ij)] = -(s / w) * np.eye(Ne)
    Phi_j[np.ix_(ij, ie)] = (w * s) * np.eye(Ne)
    Phi_j[np.ix_(ij, ij)] = c * np.eye(Ne)
    Phi_d = np.eye(m)
    Phi_d[np.ix_(ie, ie)] = np.exp(-model.sigma * dt) * np.eye(Ne)
    Phi_drv = np.eye(m)
    if model.driven:
        wd = model.omega_d
        td = wd * dt
        cd, sd = np.cos(td), np.sin(td)
        Phi_drv[model.id_, model.id_] = cd
        Phi_drv[model.id_, model.idd] = sd / wd
        Phi_drv[model.idd, model.id_] = -wd * sd
        Phi_drv[model.idd, model.idd] = cd
    return Phi_f, Phi_j, Phi_d, Phi_drv


def strang_propagator(model, dt):
    """Symmetric Strang (2nd order) for the 1D linear Maxwell-London.

    The composition places the dissipation sub-flow at the centre (full
    step), surrounded symmetrically by half-step contributions of the
    Maxwell, London and driver sub-flows::

        Phi(dt) = Pfh Pjh Prh Pd Prh Pjh Pfh       (1)

    With ``sigma = 0`` and ``driven = False`` both Pd and Pr reduce to
    the identity, so (1) collapses to the canonical 2-flow Strang
    ``Pfh Pj Pfh``.  The composition integrates over time ``dt`` exactly
    (the time integral of the piecewise-constant generator equals A*dt)
    and inherits the 2nd-order accuracy of symmetric Strang for any
    ordering of the sub-flows.
    """
    Pf, Pj, Pd, Pr = split_flows_1d(model, dt)
    Pfh, Pjh, Pdh, Prh = split_flows_1d(model, dt / 2)
    return Pfh @ Pjh @ Prh @ Pd @ Prh @ Pjh @ Pfh


def yoshida4_propagator(model, dt):
    """4th-order Yoshida composition of the 2nd-order Strang kernel (1D)."""
    w1 = 1.0 / (2.0 - 2.0 ** (1.0 / 3.0))
    w0 = -2.0 ** (1.0 / 3.0) * w1
    return (strang_propagator(model, w1 * dt)
            @ strang_propagator(model, w0 * dt)
            @ strang_propagator(model, w1 * dt))


# ---- 2D / 3D Maxwell propagation --------------------------------------

def propagator_2d(model, dt, backend="auto", tol=1e-13, max_dim=96,
                  dense_limit=2000, max_bytes=None):
    """Exact symplectic propagator for the 2D Maxwell model.

    The discretised operator A is exactly skew-symmetric in M = I (when
    ``boundary='periodic'``), so exp(A dt) is the exact symplectic flow.
    For ``sigma > 0`` the dissipative block is included in A, so the
    propagator is the exponential of the full generator.

    Returns a callable (:class:`ExponentialPropagator`) supporting both
    ``P(u)`` and ``P @ u``; the backend is dense precise integration for
    small n and the matrix-free Krylov exponential otherwise.
    """
    if model.dim == 1:
        return strang_propagator(model, dt)
    return ExponentialPropagator(model.A, dt, backend=backend, tol=tol,
                                 max_dim=max_dim, dense_limit=dense_limit,
                                 max_bytes=max_bytes, n=model.n)


def _compose(*props):
    """Composition of callables: ``u -> props[0](props[1](...))``."""
    def Phi(u):
        for P in reversed(props):
            u = P(u)
        return u
    return Phi


def yoshida4_propagator_2d(model, dt, backend="auto", tol=1e-13,
                           max_dim=96, dense_limit=2000, max_bytes=None):
    """4th-order Yoshida composition of the symplectic 2D propagator."""
    w1 = 1.0 / (2.0 - 2.0 ** (1.0 / 3.0))
    w0 = -2.0 ** (1.0 / 3.0) * w1
    Phi1 = propagator_2d(model, w1 * dt, backend=backend, tol=tol,
                         max_dim=max_dim, dense_limit=dense_limit,
                         max_bytes=max_bytes)
    Phi0 = propagator_2d(model, w0 * dt, backend=backend, tol=tol,
                         max_dim=max_dim, dense_limit=dense_limit,
                         max_bytes=max_bytes)
    return _compose(Phi1, Phi0, Phi1)


def propagator_3d(model, dt, backend="auto", tol=1e-13, max_dim=96,
                  dense_limit=2000, max_bytes=None):
    """Exact symplectic propagator for the 3D Maxwell model (periodic).

    Same logic as :func:`propagator_2d`: the discretised A is exactly
    skew-symmetric in M = I, so exp(A dt) is the machine-precision
    symplectic flow.  Large systems are handled matrix-free by the
    Arnoldi/Krylov exponential, whose cost is one application of
    :class:`YeeOperator3D` per Krylov vector and whose Krylov dimension
    is chosen adaptively from Saad's residual estimate.
    """
    A = model.matvec if model.matrix_free else model.A
    return ExponentialPropagator(A, dt, backend=backend, tol=tol,
                                 max_dim=max_dim, dense_limit=dense_limit,
                                 max_bytes=max_bytes, n=model.n)


def propagator_nd(model, dt, **kw):
    """Uniform propagator for dim in {1, 2, 3} Maxwell models."""
    if model.dim == 1:
        return strang_propagator(model, dt)
    if model.dim == 2:
        return propagator_2d(model, dt, **kw)
    return propagator_3d(model, dt, **kw)


# ---- TDGL IMEX Strang with Newton iteration ----------------------------

def newton_solve_cn(F_apply, Jac_apply, u_n, dt, tol=1e-12, max_iter=25,
                    verbose=False):
    """Crank-Nicolson Newton iteration for  du/dt = F(u).

    Solves  u_{n+1} - u_n - (dt/2)(F(u_n) + F(u_{n+1})) = 0
    with linear Jacobian  J = I - (dt/2) dF/du(u_{n+1}).

    Light damping (line search on |res|) is used to enlarge the basin of
    convergence.
    """
    u = u_n.copy()
    rhs = u_n + 0.5 * dt * F_apply(u_n)
    for it in range(max_iter):
        Fn1 = F_apply(u)
        res = u - 0.5 * dt * Fn1 - rhs
        err = float(np.linalg.norm(res))
        if err < tol:
            if verbose:
                print(f"    Newton converged in {it+1} steps, |res| = {err:.3e}")
            return u
        J = np.eye(u.size) - 0.5 * dt * Jac_apply(u)
        try:
            delta = np.linalg.solve(J, -res)
        except np.linalg.LinAlgError:
            delta = np.linalg.lstsq(J, -res, rcond=None)[0]
        s = 1.0
        while s > 1e-3:
            un = u + s * delta
            err_new = float(np.linalg.norm(un - 0.5 * dt * F_apply(un) - rhs))
            if err_new < err:
                u = un
                break
            s *= 0.5
        else:
            u = u + delta
    if verbose:
        print(f"    Newton did not converge, final |res| = {err:.3e}")
    return u


def imex_strang_tdgl(model, dt, tol=1e-12, max_iter=25, verbose=False):
    """One IMEX Strang step for a split  du/dt = L u + N(u).

    Returns a callable  u_{n+1} = Phi(u_n).  The linear half-steps use
    precise integration.  The nonlinear full step uses the closed-form
    per-cell Crank-Nicolson scaling when the model provides it (exact and
    O(n)); otherwise the CN system is solved by a dense Newton iteration.
    Both paths agree to roundoff (test-suite item 15).
    """
    Phi_lin_h = precise_integration(model.L_mat, dt / 2)
    exact = getattr(model, "nonlinear_step_exact", None)

    def step(u_n):
        u_half = Phi_lin_h @ u_n
        if exact is not None:
            u_nl = exact(u_half, dt, tol=tol)
        else:
            u_nl = newton_solve_cn(model.N_func, model.N_jac, u_half, dt,
                                    tol=tol, max_iter=max_iter, verbose=verbose)
        return Phi_lin_h @ u_nl

    return step


def yoshida4_tdgl(model, dt, tol=1e-12, max_iter=25, verbose=False):
    """4th-order Yoshida composition of the IMEX Strang kernel."""
    w1 = 1.0 / (2.0 - 2.0 ** (1.0 / 3.0))
    w0 = -2.0 ** (1.0 / 3.0) * w1

    def step_factory(d):
        return imex_strang_tdgl(model, d, tol=tol, max_iter=max_iter, verbose=verbose)

    k1 = step_factory(w1 * dt)
    k2 = step_factory(w0 * dt)

    def step(u_n):
        return k1(k2(k1(u_n)))

    return step


# =========================================================================
# Part 5: Classical baseline schemes
# =========================================================================


def leapfrog_step(model, u, dt):
    """Yee FDTD leapfrog for the 1D model."""
    e, hm, jm = u
    h = hm + dt * (model.Dt @ e)
    j = jm + dt * model.omega_p ** 2 * e
    s = 0.5 * dt * model.sigma
    e_new = ((1.0 - s) * e + dt * (model.D @ h - j)) / (1.0 + s)
    return (e_new, h, j)


def leapfrog_init(model, e0, h0, j0, dt):
    hm = h0 - 0.5 * dt * (model.Dt @ e0)
    jm = j0 - 0.5 * dt * model.omega_p ** 2 * e0
    return (e0.copy(), hm, jm)


def rk4_step(A, u, dt):
    A = np.asarray(A)
    if sp.issparse(A):
        Av = lambda v: A @ v
    else:
        Av = lambda v: A @ v
    k1 = Av(u)
    k2 = Av(u + 0.5 * dt * k1)
    k3 = Av(u + 0.5 * dt * k2)
    k4 = Av(u + dt * k3)
    return u + dt / 6.0 * (k1 + 2 * k2 + 2 * k3 + k4)


def leapfrog_step_2d(model, u, dt):
    """Yee leapfrog step for 2D TM Maxwell (state u = (Ex, Ey, Hz))."""
    n_per = model.Ns[0] * model.Ns[1]
    Ex = u[:n_per]
    Ey = u[n_per:2 * n_per]
    Hz = u[2 * n_per:]

    # H update: H^{n+1/2} = H^{n-1/2} + dt * (Chz_ex Ex^n + Chz_ey Ey^n)
    Hz_new = Hz + dt * (model.Chz_ex @ Ex + model.Chz_ey @ Ey)

    # E update with implicit midpoint for sigma:
    s = 0.5 * dt * model.sigma
    Ex_pred = Ex + dt * model.Cex_hz @ Hz_new
    Ey_pred = Ey + dt * model.Cey_hz @ Hz_new
    Ex_new = (Ex_pred - s * Ex) / (1.0 + s)
    Ey_new = (Ey_pred - s * Ey) / (1.0 + s)

    return np.concatenate([Ex_new, Ey_new, Hz_new])


# ---- 3D baselines (matrix-free, one operator application per stage) -----

def leapfrog_step_3d(op, state, dt):
    """Yee leapfrog step for the 3D matrix-free operator.

    ``state = (E, H)`` with both arrays of shape ``(3, Nz, Ny, Nx)``;
    ``H`` is stored at the half-integer time level.  Cost: one
    ``curl_H`` and one ``faraday`` application, i.e. 2 shift-based
    matvec-equivalents per step, plus a pointwise semi-implicit factor
    for the Ohmic term (unconditionally stable in sigma, as in 2D).
    """
    E, Hm = state
    H = Hm + dt * op.faraday(E)
    E_pred = E + dt * op.curl_H(H)
    if op.sigma > 0.0:
        s = 0.5 * dt * op.sigma
        E_new = (E_pred - s * E) / (1.0 + s)
    else:
        E_new = E_pred
    return (E_new, H)


def leapfrog_init_3d(op, E0, H0, dt):
    """Half-step shift of H so that the leapfrog is second-order accurate."""
    Hm = H0 - 0.5 * dt * op.faraday(E0)
    return (np.array(E0, dtype=float, copy=True),
            np.array(Hm, dtype=float, copy=True))


def rk4_apply(A, u, dt, stages=4):
    """Classical RK4 written for a generic ``A`` (matrix or matvec)."""
    Av = (lambda v: A(v)) if (callable(A) and not hasattr(A, "shape")) \
        else (lambda v: A @ v)
    k1 = Av(u)
    k2 = Av(u + 0.5 * dt * k1)
    k3 = Av(u + 0.5 * dt * k2)
    k4 = Av(u + dt * k3)
    return u + dt / 6.0 * (k1 + 2 * k2 + 2 * k3 + k4)