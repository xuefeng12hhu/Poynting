"""
run_experiments.py
==================
All numerical experiments for the paper:

  E1  Time-integration accuracy at fixed physical time (order verification)
  E2  Long-term energy conservation (sigma = 0)
  E3  Discrete Poynting audit / dissipation (sigma = 0.02)
  E4  Meissner screening: driven wall, penetration-depth validation and
      boundary-port power balance (pointwise, integrated, frequency domain)
  E5  Spatial (dispersion) convergence of the semi-discrete eigenfrequencies
  E6  CFL robustness (energy and accuracy vs the CFL number)
  E7  2D TM Maxwell (periodic): de Rham + skew + energy + decay (with sigma)
  E8  Reduced 1D Ginzburg-Landau-type model: IMEX Strang energy
      monotonicity + 2nd-order convergence
  E9  3D periodic Maxwell: structure preservation at scale
  E10 Scalability / cost model of the matrix-free exponential integrator:
      Krylov dimension law m(theta), per-application cost and memory up to
      n = 1.6 10^6, accuracy per unit of work against FDTD/RK4, and the
      Delta-t monotone work budget of the structure-preserving step
  E11 Non-uniform 2D two-fluid: Meissner screening / London audit with the
      energy-metric (M-inner-product) Krylov propagator; local penetration
      depth kappa(x) = 1/lambda(x) confirmed by the relaxed trapped field
  E12 Non-uniform 3D absorption (conducting sphere in vacuum), matrix-free
      at n = 3.8 10^5: per-step Poynting audit of the exact flow
  E13 Gauge-invariant TDGL on the torus: vortex-antivortex annihilation,
      winding bookkeeping and healing of |psi|

Outputs figures (png + pdf) into ../figures and numbers into ../results.
"""
import json
import os
import time

import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib.ticker as mtick
import scipy.linalg as sla
import scipy.sparse.linalg as spla

import scph

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
FIG = os.path.join(ROOT, "figures")
RES = os.path.join(ROOT, "results")
os.makedirs(FIG, exist_ok=True)
os.makedirs(RES, exist_ok=True)

plt.rcParams.update({
    "font.family": "serif",
    "font.serif": ["Times New Roman", "Times", "STIX", "DejaVu Serif"],
    "mathtext.fontset": "stix",
    "font.size": 9, "axes.labelsize": 9, "legend.fontsize": 8,
    "xtick.labelsize": 8, "ytick.labelsize": 8, "figure.dpi": 160,
    "savefig.bbox": "tight", "axes.grid": True, "grid.alpha": 0.25,
    "legend.frameon": False, "lines.linewidth": 1.3, "lines.markersize": 4.5,
})

STYLE = {
    "PI-EX":  dict(color="k", marker="o"),
    "SPI-2":  dict(color="tab:red", marker="s"),
    "SPI-4":  dict(color="tab:blue", marker="^"),
    "FDTD":   dict(color="tab:green", marker="v"),
    "RK4":    dict(color="tab:purple", marker="D"),
}

results = {}


def save(fig, name):
    for ext in ("png", "pdf"):
        fig.savefig(os.path.join(FIG, f"{name}.{ext}"))
    plt.close(fig)
    print(f"  [figure] figures/{name}.png")


def pack(u, model):
    """Flatten a (e, h, j) tuple into a full state vector (driven-free)."""
    e, h, j = u
    v = np.zeros(model.n)
    v[model.ie] = e
    v[model.ih] = h
    v[model.ij] = j
    return v


# ==========================================================================
# E1 - accuracy of the time integrators at a fixed physical time
# ==========================================================================
def experiment_1():
    print("\n=== E1: time-integration accuracy (mode 1, sigma = 0) ===")
    N, L, wp = 64, 1.0, 10.0
    model = scph.SuperconductingModel(N=N, L=L, omega_p=wp, sigma=0.0)
    u0 = model.initial_mode(1)
    w1 = model.discrete_eigenfrequency(1)
    T = 10.0 * 2 * np.pi / w1
    uref = model.exact_solution(u0, T)

    dts = np.array([1e-3, 2e-3, 4e-3, 8e-3, 1.25e-2])   # CFL <= 0.8
    data = {k: [] for k in ("PI-EX", "SPI-2", "SPI-4", "FDTD", "RK4")}
    for dt in dts:
        n = int(round(T / dt))
        Tend = n * dt
        ref = model.exact_solution(u0, Tend)

        # --- precise integration of the full (non-split) operator ---------
        P = scph.precise_integration(model.A, dt)
        u = u0.copy()
        for _ in range(n):
            u = P @ u
        data["PI-EX"].append(sla.norm(u - ref) / sla.norm(ref))

        # --- symplectic splitting, PI kernel (2nd and 4th order) ----------
        Ps = scph.strang_propagator(model, dt)
        u = u0.copy()
        for _ in range(n):
            u = Ps @ u
        data["SPI-2"].append(sla.norm(u - ref) / sla.norm(ref))

        P4 = scph.yoshida4_propagator(model, dt)
        u = u0.copy()
        for _ in range(n):
            u = P4 @ u
        data["SPI-4"].append(sla.norm(u - ref) / sla.norm(ref))

        # --- Yee leapfrog --------------------------------------------------
        e0, h0, j0 = u0[model.ie], u0[model.ih], u0[model.ij]
        st = scph.leapfrog_init(model, e0, h0, j0, dt)
        for _ in range(n):
            st = scph.leapfrog_step(model, st, dt)
        hf = st[1] + 0.5 * dt * (model.Dt @ st[0])
        jf = st[2] + 0.5 * dt * model.omega_p ** 2 * st[0]
        data["FDTD"].append(sla.norm(pack((st[0], hf, jf), model) - ref) / sla.norm(ref))

        # --- classical RK4 -------------------------------------------------
        u = u0.copy()
        for _ in range(n):
            u = scph.rk4_step(model.A, u, dt)
        data["RK4"].append(sla.norm(u - ref) / sla.norm(ref))

    for k, v in data.items():
        results[f"E1_{k}"] = [float(x) for x in v]
    results["E1_dts"] = [float(x) for x in dts]
    for k, v in data.items():
        print(f"  {k:6s}: " + "  ".join(f"{x:.2e}" for x in v))

    # observed orders  p = log(e_{i+1} / e_i) / log(dt_{i+1} / dt_i)
    # (errors grow with dt, so the ratio is taken in the increasing sense)
    rat = np.log(dts[1:] / dts[:-1])
    for k, v in data.items():
        v = np.array(v)
        orders = np.log(v[1:] / v[:-1]) / rat
        if k == "PI-EX":
            print(f"  order({k}) = n/a  (error sits on the round-off floor, "
                  f"~{np.median(v):.0e})")
        else:
            print(f"  order({k}) = " + ", ".join(f"{o:.2f}" for o in orders))

    # ---- extended range: PI/SPI are not limited by the CFL number --------
    dts_big = np.array([2e-2, 5e-2, 1e-1, 2e-1, 5e-1])
    big = {}
    for name, maker in (("PI-EX", lambda m, d: scph.precise_integration(m.A, d)),
                        ("SPI-2", lambda m, d: scph.strang_propagator(m, d))):
        errs = []
        for dt in dts_big:
            n = int(round(T / dt))
            ref = model.exact_solution(u0, n * dt)
            P = maker(model, dt)
            u = u0.copy()
            for _ in range(n):
                u = P @ u
            errs.append(sla.norm(u - ref) / sla.norm(ref))
        big[name] = errs
        results[f"E1_big_{name}"] = [float(x) for x in errs]
    results["E1_big_dts"] = [float(x) for x in dts_big]

    # ---- figure ---------------------------------------------------------
    fig, axes = plt.subplots(1, 2, figsize=(7.0, 2.7), constrained_layout=True)
    ax = axes[0]
    for k in ("PI-EX", "SPI-2", "SPI-4", "FDTD", "RK4"):
        ax.loglog(dts, data[k], label=k, **STYLE[k])
    ax.loglog(dts, 2e-2 * (dts / dts[0]) ** 2, "k--", lw=0.8, label=r"$O(\Delta t^2)$")
    ax.set_xlabel(r"$\Delta t$"); ax.set_ylabel(r"$\|u(T)-u_{\rm ref}(T)\|/\|u_{\rm ref}\|$")
    ax.set_title(r"(a) accuracy, ${\rm CFL}\leq 0.8$")
    ax.legend(loc="lower right", ncol=2)

    ax = axes[1]
    ax.loglog(dts, data["PI-EX"], label="PI-EX", **STYLE["PI-EX"])
    ax.loglog(dts, data["SPI-2"], label="SPI-2", **STYLE["SPI-2"])
    ax.loglog(dts_big, big["PI-EX"], **STYLE["PI-EX"])
    ax.loglog(dts_big, big["SPI-2"], **STYLE["SPI-2"])
    ax.axvline(1.0 / N, color="gray", ls=":", lw=1.0)
    ax.text(1.06 / N, 1e-9, r"CFL $=1$", color="gray", rotation=90, fontsize=7)
    ax.set_xlabel(r"$\Delta t$"); ax.set_ylabel("relative error")
    ax.set_title(r"(b) beyond the CFL limit")
    ax.legend(loc="lower right")
    save(fig, "fig1_accuracy")

    # timing / cost table
    cost = {}
    for name, P in (("PI-EX", scph.precise_integration(model.A, 1e-2)),
                    ("SPI-2", scph.strang_propagator(model, 1e-2))):
        t0 = time.perf_counter()
        u = u0.copy()
        for _ in range(2000):
            u = P @ u
        cost[name] = (time.perf_counter() - t0) / 2000
    print("  per-step cost (n=%d): " % model.n +
          ", ".join(f"{k}={v*1e6:.1f}us" for k, v in cost.items()))
    results["E1_cost"] = {k: float(v) for k, v in cost.items()}
    results["E1_nstate"] = int(model.n)
    return model, u0, T


# ==========================================================================
# E2 - long-term energy conservation
# ==========================================================================
def experiment_2():
    print("\n=== E2: long-term energy conservation (sigma = 0) ===")
    N, L, wp = 64, 1.0, 10.0
    model = scph.SuperconductingModel(N=N, L=L, omega_p=wp, sigma=0.0)
    # mode 1 with the static London component (ker A) removed, so that the
    # reported energy is purely dynamical
    u0 = model.remove_static_component(model.initial_mode(1))
    dt = 1e-2                       # CFL = 0.64
    nsteps = 100000
    w1 = model.discrete_eigenfrequency(1)

    W0 = model.energy(u0)
    series = {}

    P = scph.precise_integration(model.A, dt)
    u = u0.copy(); W = np.empty(nsteps + 1); W[0] = 0.0
    for n in range(nsteps):
        u = P @ u; W[n + 1] = model.energy(u) / W0 - 1.0
    series["PI-EX"] = W

    Ps = scph.strang_propagator(model, dt)
    u = u0.copy(); W = np.empty(nsteps + 1); W[0] = 0.0
    for n in range(nsteps):
        u = Ps @ u; W[n + 1] = model.energy(u) / W0 - 1.0
    series["SPI-2"] = W

    e0, h0, j0 = u0[model.ie], u0[model.ih], u0[model.ij]
    st = scph.leapfrog_init(model, e0, h0, j0, dt)
    W = np.empty(nsteps + 1); W[0] = 0.0
    for n in range(nsteps):
        st = scph.leapfrog_step(model, st, dt)
        W[n + 1] = model.energy(pack(st, model)) / W0 - 1.0
    series["FDTD"] = W

    u = u0.copy(); W = np.empty(nsteps + 1); W[0] = 0.0
    for n in range(nsteps):
        u = scph.rk4_step(model.A, u, dt)
        W[n + 1] = model.energy(u) / W0 - 1.0
    series["RK4"] = W

    t = np.arange(nsteps + 1) * dt / (2 * np.pi / w1)     # in periods
    fig, ax = plt.subplots(figsize=(3.5, 2.7))
    for k, W in series.items():
        kw = dict(STYLE[k])
        if k == "PI-EX":
            # PI-EX and SPI-2 sit on the same round-off floor.  Draw PI-EX
            # as sparse large open circles (no connecting line) on top of
            # the SPI-2 solid line so both curves stay clearly visible.
            kw["linestyle"] = "none"
            kw["marker"] = "o"
            kw["markersize"] = 8.0
            kw["markerfacecolor"] = "none"
            kw["markeredgewidth"] = 1.2
            kw["markevery"] = 8
            kw["zorder"] = 5
        ax.semilogy(t[::50], np.abs(W[::50]) + 1e-17, label=k, **kw)
    ax.set_xlabel("time (number of mode-1 periods)")
    ax.set_ylabel(r"$|W(t)/W(0)-1|$")
    ax.set_title(rf"$\Delta t=10^{{-2}}$ (CFL$=0.64$), ${nsteps*dt/(2*np.pi/w1):.0f}$ periods")
    ax.legend(ncol=2)
    save(fig, "fig2_longterm_energy")

    for k, W in series.items():
        results[f"E2_maxdrift_{k}"] = float(np.max(np.abs(W)))
    print("  final/max |dW/W|: " + ", ".join(
        f"{k}={np.max(np.abs(W)):.2e}" for k, W in series.items()))
    return model, u0


# ==========================================================================
# E3 - discrete Poynting audit and dissipation (sigma > 0)
# ==========================================================================
GL_X, GL_W = np.polynomial.legendre.leggauss(32)


def poynting_residual(model, u_n, dt, P):
    """Residual of the integral discrete Poynting identity for one step:

       W(u_{n+1}) - W(u_n) + sigma * int_{t_n}^{t_n+dt} ||e(t)||^2 dt = 0

    the integral being evaluated by Gauss-Legendre quadrature with the exact
    sub-step propagator exp(A s).
    """
    Wn = model.energy(u_n)
    Wn1 = model.energy(P @ u_n)
    acc = 0.0
    for x, wgt in zip(GL_X, GL_W):
        s = 0.5 * dt * (x + 1.0)
        us = sla.expm(model.A * s) @ u_n
        es = us[model.ie]
        acc += wgt * float(es @ es)
    acc *= 0.5 * dt
    return (Wn1 - Wn) + model.sigma * acc, Wn + model.sigma * acc - Wn1


def experiment_3():
    print("\n=== E3: discrete Poynting audit / dissipation (sigma = 0.02) ===")
    N, L, wp, sig = 64, 1.0, 10.0, 0.02
    model = scph.SuperconductingModel(N=N, L=L, omega_p=wp, sigma=sig)
    # The lossless mode-1 eigenvector has a non-zero component in ker(A)
    # (the Nh-dimensional manifold of static London states E = 0, curl H = J).
    # That component is never dissipated and would make the fitted decay
    # rate drift to zero; project it out so that W(t) ~ exp(-sigma t).
    u_raw = model.initial_mode(1)
    u0 = model.remove_static_component(u_raw)
    frac_stat = model.energy(u_raw - u0) / model.energy(u_raw)
    print(f"  energy fraction in ker(A) (removed) = {frac_stat:.6f}")
    print(f"  ||A K||_F = {np.linalg.norm(model.A @ model.static_subspace()):.1e}"
          f"  (ker(A) dimension = {model.static_subspace().shape[1]})")
    w1 = model.discrete_eigenfrequency(1)

    # ---- (a) quadrature-verified Poynting identity, PI-EX ----------------
    dt = 0.05
    P = scph.precise_integration(model.A, dt)
    u = u0.copy()
    rel = []
    for _ in range(20):
        res, Wn1 = poynting_residual(model, u, dt, P)
        rel.append(abs(res) / max(Wn1, 1e-30))
        u = P @ u
    print(f"  PI-EX  max relative Poynting residual = {max(rel):.3e}")

    Ps = scph.strang_propagator(model, dt)
    u = u0.copy()
    rel2 = []
    for _ in range(20):
        res, Wn1 = poynting_residual(model, u, dt, Ps)
        rel2.append(abs(res) / max(Wn1, 1e-30))
        u = Ps @ u
    print(f"  SPI-2  max relative Poynting residual (per-step, NOT consistent) = {max(rel2):.3e}")

    results["E3_poynting_PIEX"] = float(max(rel))
    results["E3_poynting_SPI2"] = float(max(rel2))
    results["E3_note"] = ("SPI-2 is not expected to satisfy the per-step Poynting "
                          "identity; the consistent physical quantity is the "
                          "global energy-decay rate reported below.")

    # ---- (b) exact energy decay, decay-rate / quality-factor accuracy ----
    T = 200.0
    cases = {}
    dt = 0.01
    n = int(round(T / dt))
    tend = n * dt
    Wref = np.array([model.energy(model.exact_solution(u0, tt)) for tt in (0.0, tend)])
    Gamma_ref = -np.log(Wref[1] / Wref[0]) / tend

    u = u0.copy(); P = scph.precise_integration(model.A, dt)
    for _ in range(n):
        u = P @ u
    W_end = model.energy(u)
    cases["PI-EX"] = (-np.log(W_end / Wref[0]) / tend)

    Ps = scph.strang_propagator(model, dt)
    u = u0.copy()
    for _ in range(n):
        u = Ps @ u
    cases["SPI-2"] = (-np.log(model.energy(u) / Wref[0]) / tend)

    e0, h0, j0 = u0[model.ie], u0[model.ih], u0[model.ij]
    st = scph.leapfrog_init(model, e0, h0, j0, dt)
    for _ in range(n):
        st = scph.leapfrog_step(model, st, dt)
    cases["FDTD"] = (-np.log(model.energy(pack(st, model)) / Wref[0]) / tend)

    u = u0.copy()
    for _ in range(n):
        u = scph.rk4_step(model.A, u, dt)
    cases["RK4"] = (-np.log(model.energy(u) / Wref[0]) / tend)

    print(f"  exact energy decay rate  Gamma = {Gamma_ref:.10f}  "
          f"(sigma = {sig}, |Gamma-sigma|/sigma = {abs(Gamma_ref-sig)/sig:.2e})")
    for k, v in cases.items():
        print(f"    {k:6s}: Gamma = {v:.10f},  relative error = {abs(v-Gamma_ref)/Gamma_ref:.3e}")
    print(f"  quality factor Q = omega_1 / Gamma = {w1 / Gamma_ref:.3f}")
    results["E3_Gamma_ref"] = float(Gamma_ref)
    results["E3_Gamma"] = {k: float(v) for k, v in cases.items()}
    results["E3_Q_exact"] = float(w1 / Gamma_ref)
    results["E3_static_fraction"] = float(frac_stat)

    # ---- figure: (a) residual, (b) energy decay --------------------------
    fig, axes = plt.subplots(1, 2, figsize=(7.0, 2.7), constrained_layout=True)
    ax = axes[0]
    ax.semilogy(range(1, 21), rel, "o-", color="k", label="PI-EX")
    ax.semilogy(range(1, 21), rel2, "s--", color="tab:red", label="SPI-2")
    ax.set_xlabel("step index"); ax.set_ylabel("relative Poynting residual")
    ax.set_title(r"(a) discrete Poynting identity, $\Delta t=0.05$")
    ax.legend()

    ax = axes[1]
    ts = np.linspace(0, 60, 200)
    Wex = np.array([model.energy(model.exact_solution(u0, tt)) / Wref[0] for tt in ts])
    ax.semilogy(ts, Wex, "k-", lw=1.0, label="exact")
    for k, Pk in (("PI-EX", scph.precise_integration(model.A, dt)),
                  ("SPI-2", scph.strang_propagator(model, dt))):
        u = u0.copy(); Ws = [model.energy(u) / Wref[0]]
        for _ in range(int(round(60 / dt))):
            u = Pk @ u; Ws.append(model.energy(u) / Wref[0])
        ax.semilogy(np.arange(len(Ws)) * dt, Ws, ls="--", label=k, **STYLE[k])
    e0, h0, j0 = u0[model.ie], u0[model.ih], u0[model.ij]
    st = scph.leapfrog_init(model, e0, h0, j0, dt)
    Ws = [model.energy(pack(st, model)) / Wref[0]]
    for _ in range(int(round(60 / dt))):
        st = scph.leapfrog_step(model, st, dt); Ws.append(model.energy(pack(st, model)) / Wref[0])
    ax.semilogy(np.arange(len(Ws)) * dt, Ws, ls="--", label="FDTD", **STYLE["FDTD"])
    ax.set_xlabel("$t$"); ax.set_ylabel(r"$W(t)/W(0)$")
    ax.set_title(r"(b) dissipative decay, $\sigma=0.02$")
    ax.legend()
    save(fig, "fig3_poynting_dissipation")
    return model


# ==========================================================================
# E4 - Meissner screening / penetration depth (driven wall port)
# ==========================================================================
def experiment_4():
    print("\n=== E4: Meissner screening, driven-wall penetration depth ===")
    N, L, wp, wd = 400, 1.0, 10.0, 2.0
    model = scph.SuperconductingModel(N=N, L=L, omega_p=wp, sigma=0.0,
                                      driven=True, omega_d=wd)
    u0 = np.zeros(model.n_aug)
    u0[model.id_] = 1.0                       # d(t) = cos(omega_d t), E_y(0) = d(t)

    dt = 0.05
    T = 80.0
    n = int(round(T / dt))
    P = scph.precise_integration(model.A, dt)

    # lock-in detection of the steady-state amplitude profile
    acc_c = np.zeros(model.n_aug)
    acc_s = np.zeros(model.n_aug)
    u = u0.copy()
    t0 = T - 4 * 2 * np.pi / wd               # average over the last 4 periods
    n0 = int(round(t0 / dt))
    for k in range(n + 1):
        if k >= n0:
            tt = k * dt
            acc_c += np.cos(wd * tt) * u
            acc_s += np.sin(wd * tt) * u
        u = P @ u
    n_avg = n - n0 + 1
    amp = 2.0 * np.sqrt(acc_c ** 2 + acc_s ** 2) / n_avg
    z_E = np.arange(1, N) * model.dz
    z_H = (np.arange(N) + 0.5) * model.dz
    A_H = amp[model.ih]
    A_E = amp[model.ie]

    # fit the decay exponent of |H_x| over a window away from both ends
    mask = (z_H > 0.08) & (z_H < 0.55) & (A_H > 1e-12)
    slope, inter = np.polyfit(z_H[mask], np.log(A_H[mask]), 1)
    kappa_num = -slope
    kappa_the = np.sqrt(wp ** 2 - wd ** 2)
    print(f"  penetration depth: numerical kappa = {kappa_num:.6f}, "
          f"theory kappa = {kappa_the:.6f}, relative error = "
          f"{abs(kappa_num-kappa_the)/kappa_the:.3e}")
    print(f"  lambda_L = 1/omega_p = {1/wp:.4f}, "
          f"lambda_eff = 1/sqrt(omega_p^2-omega^2) = {1/kappa_the:.4f}")
    results["E4_kappa_num"] = float(kappa_num)
    results["E4_kappa_theory"] = float(kappa_the)

    # ---- boundary-port audit -------------------------------------------
    # The driven wall is a port: input v(t) = d(t) = cos(omega_d t), output
    # y = -h_0/dz = b^T M u, with the exact node-wise power balance
    #     dW/dt = -sigma |e|^2 + v y .
    # (1) pointwise residual along the trajectory (roundoff test),
    # (2) integrated balance  dW_f + sigma int |e|^2 dt = int v y dt  in the
    #     periodic steady state of a lossy wall, whose exact harmonic response
    #     is used as the initial condition (so the integrand is a single
    #     harmonic and Simpson is spectrally accurate up to roundoff),
    # (3) frequency-domain balance <v y> = sigma <|e|^2> for a lossy wall.
    def w_field(md_, uu):
        """Field energy W_f = W - W_driver (drop the source oscillator)."""
        w_osc = 0.5 * (md_.omega_d ** 2 * uu[md_.id_] ** 2 + uu[md_.idd] ** 2)
        return md_.energy(uu) - w_osc

    T_p = 40.0
    n_p = int(round(T_p / dt))
    u = u0.copy()
    pw_res = 0.0
    for k in range(n_p + 1):
        v_k = float(u[model.id_])
        dW_k = float(u @ (model.M @ (model.A @ u)))
        diss_k = model.sigma * float(np.sum(u[model.ie] ** 2))
        port_k = model.port_power(v_k, u)
        denom = abs(dW_k) + diss_k + abs(port_k) + 1e-300
        pw_res = max(pw_res, model.port_balance_residual(u, v_k) / denom)
        if k < n_p:
            u = P @ u
    print(f"  port: pointwise max |dW/dt + sigma|e|^2 - v y| / scale "
          f"= {pw_res:.3e}")

    m_loss = scph.SuperconductingModel(N=N, L=L, omega_p=wp, sigma=0.05,
                                       driven=True, omega_d=wd)
    bv = m_loss.port_vector()
    # exact harmonic steady state: u_f(t) = Re[ (i w I - A_f)^{-1} b e^{i w t} ]
    uh = np.linalg.solve(1j * wd * np.eye(m_loss.n) - m_loss.A[:m_loss.n, :m_loss.n],
                         bv[:m_loss.n])
    u0s = np.zeros(m_loss.n_aug)
    u0s[:m_loss.n] = np.real(uh)
    u0s[m_loss.id_] = 1.0
    T_pp = 4.0 * 2.0 * np.pi / wd              # four full periods
    intra, works, losses = [], [], []
    for nq in (512, 1024, 2048, 4096):
        h = T_pp / nq
        Pq = scph.precise_integration(m_loss.A, h)
        u = u0s.copy()
        vy = np.zeros(nq + 1)
        diss = np.zeros(nq + 1)
        for k in range(nq + 1):
            vy[k] = float(u[m_loss.id_]) * m_loss.port_output(u)
            diss[k] = m_loss.sigma * float(np.sum(u[m_loss.ie] ** 2))
            if k < nq:                        # u must sit exactly at t = T_pp
                u = Pq @ u
        simpson = np.ones(nq + 1)
        simpson[1:-1:2] = 4.0
        simpson[2:-1:2] = 2.0
        simpson *= h / 3.0
        dW = w_field(m_loss, u) - w_field(m_loss, u0s)
        work = float(simpson @ vy)
        loss = float(simpson @ diss)
        intra.append(abs(dW + loss - work) / (loss + 1e-300))
        works.append(work)
        losses.append(loss)
        print(f"  port: integrated balance (Simpson, nq = {nq:5d}, h = "
              f"{h:.2e}) rel. residual = {intra[-1]:.3e}   "
              f"[port work = {work:.8f}, dissipated = {loss:.8f}]")
    rate = np.log2(np.array(intra[:-1]) / np.array(intra[1:]))
    print(f"  port: residual is quadrature-independent (flat over an 8x "
          f"refinement, log2 rates = {np.round(rate, 2)}) => roundoff-limited:")
    print("        the semi-discrete balance itself is exact")
    results["E4_port_pointwise_resid"] = float(pw_res)
    results["E4_port_integral_resid"] = [float(x) for x in intra]
    results["E4_port_integral_rate"] = [float(x) for x in rate]
    results["E4_port_work"] = float(works[-1])
    results["E4_port_dissipated"] = float(losses[-1])

    m_lossy = scph.SuperconductingModel(N=N, L=L, omega_p=wp, sigma=0.05)
    sol = np.linalg.solve(1j * wd * np.eye(m_lossy.n) - m_lossy.A,
                          m_lossy.port_vector())
    p_avg = 0.5 * float(np.real(m_lossy.port_vector() @ (m_lossy.M @ sol)))
    d_avg = 0.5 * m_lossy.sigma * float(np.sum(np.abs(sol[m_lossy.ie]) ** 2))
    print(f"  port: frequency-domain balance <v y> = {p_avg:.12e}, "
          f"sigma<|e|^2> = {d_avg:.12e}, rel. difference = "
          f"{abs(p_avg - d_avg)/max(abs(d_avg), 1e-300):.3e}")
    results["E4_port_freq_power"] = float(p_avg)
    results["E4_port_freq_dissipated"] = float(d_avg)
    results["E4_port_freq_resid"] = float(abs(p_avg - d_avg) / max(abs(d_avg), 1e-300))

    # constrained layout: reserve room for the colorbar ticks, otherwise they
    # collide with panel (b)'s ylabel in the gap between the panels
    fig, axes = plt.subplots(1, 2, figsize=(7.0, 2.7), constrained_layout=True)
    ax = axes[0]
    tt = np.arange(0, 8.0 + dt, dt)
    u = u0.copy(); Hslice = []
    for k in range(len(tt)):
        Hslice.append(u[model.ih][:120].copy())
        u = P @ u
    Hslice = np.array(Hslice)
    im = ax.imshow(Hslice.T, aspect="auto", origin="lower",
                   extent=[tt[0], tt[-1], z_H[0], z_H[119]], cmap="RdBu_r",
                   vmin=-0.6, vmax=0.6)
    ax.set_xlabel("$t$"); ax.set_ylabel("$z$")
    ax.set_title(r"(a) screening transient, $H_x(z,t)$")
    fig.colorbar(im, ax=ax, shrink=0.9)

    ax = axes[1]
    ax.semilogy(z_H[mask], A_H[mask], "o", color="k", ms=2.5, label=r"$|H_x|$ (numerical)")
    ax.semilogy(z_H, np.exp(inter) * np.exp(-kappa_the * z_H), "-", color="tab:red",
                label=rf"$e^{{-\kappa z}}$, $\kappa={kappa_the:.3f}$")
    ax.set_xlabel("$z$"); ax.set_ylabel("steady-state amplitude")
    ax.set_title(rf"(b) $\kappa_{{\rm num}}={kappa_num:.4f}$ vs $\kappa_{{\rm th}}={kappa_the:.4f}$")
    ax.legend()
    save(fig, "fig4_penetration")
    return model


# ==========================================================================
# E5 - spatial (dispersion) convergence of the semi-discrete eigenfrequencies
# ==========================================================================
def experiment_5():
    print("\n=== E5: spatial convergence of semi-discrete eigenfrequencies ===")
    L, wp = 1.0, 10.0
    Ns = np.array([8, 16, 32, 64, 128, 256])
    errs = []
    for N in Ns:
        m = scph.SuperconductingModel(N=int(N), L=L, omega_p=wp)
        w_disc = m.discrete_eigenfrequency(1)
        w_cont = m.continuum_eigenfrequency(1)
        errs.append(abs(w_disc - w_cont) / w_cont)
    errs = np.array(errs)
    dz = L / Ns
    slope = np.polyfit(np.log(dz), np.log(errs), 1)[0]
    print(f"  observed spatial order = {slope:.3f}")
    for N, e in zip(Ns, errs):
        print(f"    N = {int(N):4d}: relative eigenfrequency error = {e:.3e}")
    results["E5_Ns"] = [int(x) for x in Ns]
    results["E5_errs"] = [float(x) for x in errs]
    results["E5_order"] = float(slope)

    fig, ax = plt.subplots(figsize=(3.4, 2.7))
    ax.loglog(dz, errs, "o-", color="k", label="mode 1")
    ax.loglog(dz, errs[0] * (dz / dz[0]) ** 2, "k--", lw=0.8, label=r"$O(\Delta z^2)$")
    ax.set_xlabel(r"$\Delta z$"); ax.set_ylabel(r"$|\omega_1^{\rm disc}-\omega_1|/\omega_1$")
    ax.legend(); ax.set_title("(a) spatial convergence")
    save(fig, "fig5_dispersion")


# ==========================================================================
# E6 - beyond-CFL robustness (energy and accuracy vs CFL number)
# ==========================================================================
def experiment_6():
    print("\n=== E6: CFL robustness ===")
    N, L, wp = 64, 1.0, 10.0
    model = scph.SuperconductingModel(N=N, L=L, omega_p=wp, sigma=0.0)
    u0 = model.initial_mode(1)
    w1 = model.discrete_eigenfrequency(1)
    T = 10 * 2 * np.pi / w1

    cf = np.array([0.1, 0.2, 0.4, 0.6, 0.8, 0.9, 1.0, 1.1, 1.3, 1.6, 2.0])
    err = []
    for c in cf:
        dt = c * model.dz
        n = int(round(T / dt))
        P = scph.precise_integration(model.A, dt)
        u = u0.copy()
        for _ in range(n):
            u = P @ u
        ref = model.exact_solution(u0, n * dt)
        err.append(sla.norm(u - ref) / sla.norm(ref))

    # FDTD: energy blow-up beyond CFL = 1
    fd_energy = []
    for c in cf:
        dt = c * model.dz
        n = 400
        st = scph.leapfrog_init(model, u0[model.ie], u0[model.ih], u0[model.ij], dt)
        try:
            with np.errstate(all="ignore"):
                for _ in range(n):
                    st = scph.leapfrog_step(model, st, dt)
                v = model.energy(pack(st, model)) / model.energy(u0) - 1.0
                if not np.isfinite(v):
                    v = 1e16   # cap for the plot
                fd_energy.append(v)
        except (FloatingPointError, OverflowError):
            fd_energy.append(1e16)

    print("  CFL      PI-EX error      FDTD energy change")
    for c, e, f in zip(cf, err, fd_energy):
        print(f"  {c:<8.2f} {e:.3e}      {f:+.3e}")
    results["E6_cfl"] = [float(x) for x in cf]
    results["E6_PIEX_err"] = [float(x) for x in err]
    results["E6_FDTD_dW"] = [float(x) for x in fd_energy]

    plot_fig6()
    return model


def plot_fig6():
    """Figure 6 panels (b) and (c): CFL robustness drawn as two separate
    plots with the same figure size as fig5_dispersion, so the three panels
    of Figure 6 match.  The (a)/(b)/(c) letters are printed inside the
    panels (the Word build and any panel-by-panel inspection need them
    there); the LaTeX subcaptions therefore use labelformat=empty."""
    cf = np.array(results["E6_cfl"])
    err = np.array(results["E6_PIEX_err"])
    fd_energy = np.array(results["E6_FDTD_dW"])

    fig, ax = plt.subplots(figsize=(3.4, 2.7))
    ax.semilogy(cf, err, "o-", color="k", label="PI-EX")
    ax.axvline(1.0, color="gray", ls=":", lw=1.0)
    ax.text(1.03, 1e-13, "CFL = 1", color="gray", rotation=90, fontsize=7)
    ax.set_xlabel("CFL number $c\\Delta t/\\Delta z$")
    ax.set_ylabel("relative error")
    ax.set_title("(b) error of the PI propagator")
    ax.set_ylim(1e-13, 1e-7)
    ax.legend()
    save(fig, "fig6_cfl_pi")

    fig, ax = plt.subplots(figsize=(3.4, 2.7))
    fd_plot = np.where(np.isfinite(fd_energy), np.clip(np.abs(fd_energy), 1e-16, 1e8), 1e8)
    ax.semilogy(cf, fd_plot, "v-", color=STYLE["FDTD"]["color"], label="FDTD")
    ax.axvline(1.0, color="gray", ls=":", lw=1.0)
    ax.set_xlabel("CFL number $c\\Delta t/\\Delta z$")
    ax.set_ylabel(r"$|W_{400}/W_0-1|$  (capped at $10^{8}$)")
    ax.set_title("(c) Yee leapfrog: instability")
    ax.set_ylim(1e-4, 1e8)
    ax.legend()
    save(fig, "fig6_cfl_fdtd")


# ==========================================================================
# E7 - 2D TM Maxwell: discrete de Rham and structure-preserving propagation
# ==========================================================================
def experiment_7():
    print("\n=== E7: 2D TM Maxwell (periodic) ===")
    Nx, Ny = 16, 16
    model = scph.MaxwellModelND(dim=2, Ns=(Nx, Ny), Ls=(1.0, 1.0),
                                sigma=0.0, boundary="periodic")
    print(f"  n = {model.n}, nE = {model.nE}, nH = {model.nH}")
    print(f"  ||A + A^T||_F = {model.skew_residual():.3e}")
    print(f"  ||A^T M + M A + 2 sigma P_E||_F = {model.dissipation_residual():.3e}")

    # initial state: localised Gaussian pulse
    rng = np.random.RandomState(0)
    u0 = rng.standard_normal(model.n)
    W0 = model.energy(u0)
    dt = 0.05
    Phi = scph.propagator_2d(model, dt)
    u = u0.copy()
    nsteps = 200
    Ws = np.empty(nsteps + 1); Ws[0] = W0
    Es = []
    for k in range(nsteps):
        u = Phi @ u
        Ws[k + 1] = model.energy(u)
        Es.append(np.sum(u[:model.nE] ** 2))
    max_drift = np.max(np.abs(Ws - W0)) / W0
    print(f"  energy drift over {nsteps} steps: max |dW/W0| = {max_drift:.3e}")
    results["E7_nsteps"] = nsteps
    results["E7_max_drift"] = float(max_drift)
    results["E7_n"] = model.n

    # dissipative decay
    model_d = scph.MaxwellModelND(dim=2, Ns=(Nx, Ny), Ls=(1.0, 1.0),
                                  sigma=0.2, boundary="periodic")
    Phi_d = scph.propagator_2d(model_d, dt)
    u = u0.copy(); W0d = model_d.energy(u)
    Wt = [W0d]
    for k in range(60):
        u = Phi_d @ u
        Wt.append(model_d.energy(u))
    print(f"  sigma=0.2: W(60*dt)/W(0) = {Wt[-1]/W0d:.6f}")
    results["E7_dissipative_ratio"] = float(Wt[-1] / W0d)

    # visualisation: |E_z| at final time (constrained layout keeps the
    # colorbar ticks of (a)/(b) clear of panel (c)'s ylabel)
    fig, axes = plt.subplots(1, 3, figsize=(9.5, 2.7), constrained_layout=True)
    ax = axes[0]
    Ex0 = u0[:Nx * Ny].reshape(Ny, Nx)
    im = ax.imshow(Ex0, cmap="RdBu_r", origin="lower",
                   extent=[0, 1, 0, 1])
    ax.set_title("(a) Ex at $t=0$")
    ax.set_xlabel("$x$"); ax.set_ylabel("$y$")
    fig.colorbar(im, ax=ax, shrink=0.9)
    ax = axes[1]
    Ex_end = u[:Nx * Ny].reshape(Ny, Nx)
    im = ax.imshow(Ex_end, cmap="RdBu_r", origin="lower",
                   extent=[0, 1, 0, 1])
    ax.set_title("(b) Ex at $t=T$")
    ax.set_xlabel("$x$"); ax.set_ylabel("$y$")
    fig.colorbar(im, ax=ax, shrink=0.9)
    ax = axes[2]
    ax.semilogy(np.arange(nsteps + 1) * dt, np.abs(Ws / W0 - 1) + 1e-17,
                color="k", label=r"$\sigma=0$")
    ax.semilogy(np.arange(len(Wt)) * dt, np.abs(np.array(Wt) / W0d - 1) + 1e-17,
                color="tab:red", label=r"$\sigma=0.2$")
    ax.set_xlabel("$t$"); ax.set_ylabel(r"$|W(t)/W_0-1|$")
    ax.set_title("(c) energy drift")
    ax.legend()
    save(fig, "fig7_2d_maxwell")
    return model


# ==========================================================================
# E8 - TDGL 1D: IMEX Strang energy monotonicity and vortex decay
# ==========================================================================
def experiment_8():
    print("\n=== E8: reduced 1D GL-type model, IMEX Strang energy monotonicity ===")
    N, L = 64, 1.0
    sigma, beta, kappa_gl = 0.1, 0.5, 2.0
    model = scph.TDGLModel1D(N=N, L=L, sigma=sigma, beta=beta, kappa=kappa_gl)
    print(f"  n = {model.n}  (e, h, u_psi, v_psi)")

    rng = np.random.RandomState(1)
    u0 = rng.standard_normal(model.n) * 0.4
    u0[model.ih] = 0.0
    u0[model.iu] = 0.8
    u0[model.iv] = 0.0
    W0 = model.energy(u0)
    print(f"  initial W = {W0:.4f},  |psi|^2 = {np.mean(u0[model.iu]**2 + u0[model.iv]**2):.4f}")

    dt = 0.04
    step = scph.imex_strang_tdgl(model, dt, verbose=False)
    y4 = scph.yoshida4_tdgl(model, dt, verbose=False)

    Ws_imex = [W0]; Ws_y4 = [W0]
    u_imex = u0.copy(); u_y4 = u0.copy()
    nsteps = 400
    for k in range(nsteps):
        u_imex = step(u_imex)
        Ws_imex.append(model.energy(u_imex))
        u_y4 = y4(u_y4)
        Ws_y4.append(model.energy(u_y4))
    dW_imex = np.diff(Ws_imex)
    dW_y4 = np.diff(Ws_y4)
    print(f"  IMEX-Strang:  W(0) = {Ws_imex[0]:.4f},  W(end) = {Ws_imex[-1]:.4f},  "
          f"min(dW) = {dW_imex.min():.3e}, max(dW) = {dW_imex.max():.3e}, "
          f"monotone = {bool(np.all(dW_imex <= 1e-12))}")
    print(f"  Yoshida-4:    W(0) = {Ws_y4[0]:.4f},  W(end) = {Ws_y4[-1]:.4f},  "
          f"min(dW) = {dW_y4.min():.3e}, max(dW) = {dW_y4.max():.3e}, "
          f"monotone = {bool(np.all(dW_y4 <= 1e-12))}")
    results["E8_W0"] = float(W0)
    results["E8_W_end_imex"] = float(Ws_imex[-1])
    results["E8_W_end_y4"]   = float(Ws_y4[-1])
    results["E8_monotone_imex"] = bool(np.all(dW_imex <= 1e-12))
    results["E8_monotone_y4"]   = bool(np.all(dW_y4 <= 1e-12))

    # the per-cell Crank-Nicolson factor actually applied inside the step:
    # |gamma| < 1 for every cell and every step is what makes the monotone
    # claim unconditional in dt (see the lemma in the paper)
    Phi_h = scph.precise_integration(model.L_mat, dt / 2)
    g_max, c_max, g_min = 0.0, 0.0, 0.0
    u_chk = u0.copy()
    for _ in range(nsteps):
        g = model.scaling_factor(Phi_h @ u_chk, dt)
        g_max = max(g_max, float(np.max(np.abs(g))))
        g_min = min(g_min, float(np.min(g)))
        c_max = max(c_max, float(np.max(dt * beta * (u_chk[model.iu] ** 2
                                                    + u_chk[model.iv] ** 2))))
        u_chk = step(u_chk)
    print(f"  per-cell CN factor: min gamma = {g_min:+.6f}, max|gamma| = {g_max:.6f} "
          f"(< 1), max c = dt beta |psi|^2 = {c_max:.4f} (< 2: no sign reversal)")
    results["E8_gamma_min"] = float(g_min)
    results["E8_gamma_max_abs"] = float(g_max)
    results["E8_c_max"] = float(c_max)

    # 1D convergence order of IMEX Strang on a smooth periodic profile
    print("\n  E8b: convergence order of IMEX Strang TDGL (smooth data)")
    z_e = (np.arange(model.Ne) + 0.5) * model.dz
    u0_c = np.zeros(model.n)
    u0_c[model.iu] = 0.6 + 0.2 * np.sin(2 * np.pi * z_e)
    u0_c[model.iv] = 0.1 * np.cos(2 * np.pi * z_e)
    T = 1.0
    dt_ref = 2.5e-4
    ref_step = scph.imex_strang_tdgl(model, dt_ref)
    uref = u0_c.copy()
    for _ in range(int(round(T / dt_ref))):
        uref = ref_step(uref)
    dts = np.array([4e-2, 2e-2, 1e-2, 5e-3])
    errs = []
    for d in dts:
        n = int(round(T / d))
        step_d = scph.imex_strang_tdgl(model, d)
        u = u0_c.copy()
        for _ in range(n):
            u = step_d(u)
        errs.append(sla.norm(u - uref) / sla.norm(uref))
    errs = np.array(errs)
    orders = np.log2(errs[:-1] / errs[1:])
    print(f"    reference: dt = {dt_ref:g}")
    print("    dt        error        order")
    for d, e, o in zip(dts, errs, [None] + list(orders)):
        print(f"    {d:<7.3f}  {e:.3e}   {o if o is not None else ''}")
    results["E8_dts"] = [float(x) for x in dts]
    results["E8_errs"] = [float(x) for x in errs]
    results["E8_orders"] = [float(x) for x in orders]
    results["E8_observed_order"] = float(np.mean(orders))

    # figures
    # constrained layout keeps the rotated ylabels of (b)/(c) clear of the
    # neighbouring panels
    fig, axes = plt.subplots(1, 3, figsize=(9.5, 2.7), constrained_layout=True)
    ax = axes[0]
    t_arr = np.arange(nsteps + 1) * dt
    ax.semilogy(t_arr, np.array(Ws_imex) / W0, color="tab:red", label="IMEX-Strang")
    ax.semilogy(t_arr, np.array(Ws_y4) / W0, color="tab:blue", label="Yoshida-4")
    ax.set_xlabel("$t$"); ax.set_ylabel(r"$W(t)/W_0$")
    ax.set_title("(a) energy decay")
    ax.legend()

    ax = axes[1]
    psi2 = u_imex[model.iu] ** 2 + u_imex[model.iv] ** 2
    z_psi = (np.arange(model.Ne) + 0.5) * model.dz
    ax.plot(z_psi, psi2, color="tab:red", label="$|\\psi|^2$ (IMEX-Strang)")
    psi2_y4 = u_y4[model.iu] ** 2 + u_y4[model.iv] ** 2
    ax.plot(z_psi, psi2_y4, color="tab:blue", ls="--", label="$|\\psi|^2$ (Yoshida-4)")
    ax.set_xlabel("$z$"); ax.set_ylabel("$|\\psi|^2$")
    ax.set_title("(b) order parameter at $t=T$")
    ax.legend()

    ax = axes[2]
    ax.loglog(dts, errs, "o-", color="k", label="IMEX-Strang")
    ax.loglog(dts, errs[0] * (dts / dts[0]) ** 2, "k--", lw=0.8, label=r"$O(\Delta t^2)$")
    ax.set_xlabel(r"$\Delta t$"); ax.set_ylabel("relative error")
    ax.set_title("(c) convergence order")
    ax.legend()
    # plain tick labels at the tested step sizes; the default log labels
    # ("2 x 10^-2", "3 x 10^-2", ...) collide at this panel width
    ax.set_xticks(dts)
    ax.xaxis.set_major_formatter(mtick.FuncFormatter(lambda v, _: f"{v:g}"))
    ax.minorticks_off()
    save(fig, "fig8_tdgl")
    return model


# ==========================================================================
# E9 - 3D periodic Maxwell: structure preservation at scale
# ==========================================================================
def experiment_9():
    print("\n=== E9: 3D periodic Maxwell (de Rham + skew + energy) ===")
    Nx, Ny, Nz = 6, 6, 6
    model = scph.MaxwellModelND(dim=3, Ns=(Nx, Ny, Nz), Ls=(1.0, 1.0, 1.0),
                                 sigma=0.0, boundary="periodic")
    print(f"  n = {model.n}")
    print(f"  ||A + A^T||_F = {model.skew_residual():.3e}")
    print(f"  ||A^T M + M A + 2 sigma P_E||_F = {model.dissipation_residual():.3e}")

    # symmetric initial condition (Ex, Ey, Ez at (i+1/2, j, k), etc.)
    rng = np.random.RandomState(2)
    u0 = rng.standard_normal(model.n)
    W0 = model.energy(u0)
    dt = 0.05
    Phi = scph.propagator_3d(model, dt)
    u = u0.copy()
    nsteps = 100
    Ws = [W0]
    for k in range(nsteps):
        u = Phi @ u
        Ws.append(model.energy(u))
    max_drift = np.max(np.abs(np.array(Ws) - W0)) / W0
    print(f"  energy drift over {nsteps} steps: max |dW/W0| = {max_drift:.3e}")
    results["E9_n"] = model.n
    results["E9_nsteps"] = nsteps
    results["E9_max_drift"] = float(max_drift)
    results["E9_skew_residual"] = float(model.skew_residual())
    return model


# ==========================================================================
# E10 - scalability / cost model of the matrix-free exponential integrator
# ==========================================================================
E10_T = 1.0                    # physical time of the work/accuracy study
E10_BYTES = 600_000_000        # memory cap on the Krylov basis in E10(a)


def expm_ref(A, u, t):
    """``exp(t A) u`` at a *single* time point.

    ``scipy.sparse.linalg.expm_multiply`` stacks ``num`` time points
    when ``start``/``stop`` are given, and requires ``num >= 2``; the
    last slice is the actual ``exp(t A) u``.  This independent
    (Al-Mohy/Higham) implementation is the reference for the Krylov
    exponential.
    """
    return spla.expm_multiply(A, u, 0.0, t, num=2)[-1]


def experiment_10():
    print("\n=== E10: scalability / cost model of the matrix-free propagator ===")
    L = 1.0

    def fin(x):
        x = float(x)
        return x if np.isfinite(x) else None

    # ------------------------------------------------------------------
    # (a) resolution scaling of the operator and of one Krylov step
    # ------------------------------------------------------------------
    print("\n  (a) resolution scaling (3D periodic, sigma = 0, CFL = 2)")
    print("      Krylov: tol = 1e-13, max_dim = 64, max_bytes = 6e8")
    print("      (times are the best of several repetitions, see the note)")
    print("       N          n     mf[us]  sparse[us]         nnz     m"
          "   peak[MB]  dense[GB]       dW/W      step[s]"
          "    rel.err vs expm")
    keys = ("N", "n", "matvec_us", "sparse_us", "nnz", "m", "basis_MB",
            "dense_GB", "drift", "step_s", "cfl", "err_expm", "skew",
            "res_mf", "tol_est")
    rec = {k: [] for k in keys}
    spm = None
    for N in (8, 12, 16, 24, 32, 48, 64):
        mf = scph.MaxwellModelND(dim=3, Ns=(N, N, N), Ls=(L, L, L),
                                 sigma=0.0, matrix_free=True)
        n = mf.n
        rng = np.random.default_rng(11)
        u0 = rng.standard_normal(n)
        u0 /= np.linalg.norm(u0)

        nrep = max(5, min(20, int(8.0e6 / n)))
        mf.matvec(u0)                       # warm-up, excluded from timing
        ts = []
        for _ in range(nrep):
            t0 = time.perf_counter()
            mf.matvec(u0)
            ts.append(time.perf_counter() - t0)
        matvec_us = float(np.min(ts)) * 1e6   # best of nrep: load-robust
        skew = mf.skew_quadratic(u0)

        if N <= 48:
            spm = scph.MaxwellModelND(dim=3, Ns=(N, N, N), Ls=(L, L, L),
                                      sigma=0.0, matrix_free=False)
            nrep_s = max(3, min(20, int(2.0e6 / n)))
            spm.A @ u0
            ts = []
            for _ in range(nrep_s):
                t0 = time.perf_counter()
                spm.A @ u0
                ts.append(time.perf_counter() - t0)
            sparse_us = float(np.min(ts)) * 1e6
            nnz = int(spm.A.nnz)
            res_mf = float(np.linalg.norm(mf.matvec(u0) - spm.A @ u0))
        else:
            sparse_us, nnz, res_mf = np.nan, 24 * n, np.nan

        dt = 2.0 * mf.cfl_dt()
        prop = scph.propagator_3d(mf, dt, backend="krylov", tol=1e-13,
                                  max_dim=64, max_bytes=E10_BYTES)
        u1 = prop @ u0
        err_expm = (float(np.linalg.norm(u1 - expm_ref(spm.A, u0, dt)))
                    if N <= 16 else np.nan)
        u = u0.copy()
        W0 = mf.energy(u)
        ts = []
        for _ in range(5):
            t0 = time.perf_counter()
            u = prop @ u
            ts.append(time.perf_counter() - t0)
        step_s = float(np.min(ts))
        drift = abs(mf.energy(u) / W0 - 1.0)

        for k, v in (("N", N), ("n", n), ("matvec_us", matvec_us),
                     ("sparse_us", sparse_us), ("nnz", nnz),
                     ("m", prop.engine.m_last),
                     ("basis_MB", prop.engine.peak_bytes / 1e6),
                     ("dense_GB", 8.0 * n * n / 1e9), ("drift", drift),
                     ("step_s", step_s), ("cfl", dt / mf.cfl_dt()),
                     ("err_expm", err_expm), ("skew", skew),
                     ("res_mf", res_mf),
                     ("tol_est", prop.engine.tol_achieved)):
            rec[k].append(v)
        print(f"      {N:3d}  {n:9d}  {matvec_us:7.1f}  {sparse_us:9.1f}"
              f"  {nnz:10d}  {prop.engine.m_last:4d}"
              f"  {prop.engine.peak_bytes/1e6:9.1f}"
              f"  {8.0*n*n/1e9:9.3f}  {drift:9.2e}  {step_s:9.4f}"
              f"    {err_expm:9.2e}")

    n_arr = np.array(rec["n"], dtype=float)
    n_dense_max = int(np.sqrt(16e9 / 8.0))
    print(f"  matrix-free vs sparse: max ||A_mf u - A_sp u|| = "
          f"{np.nanmax(rec['res_mf']):.3e}  (over the assembled grids)")
    print(f"  skew check |u^T A u|/(||u|| ||A u||): max = "
          f"{max(rec['skew']):.3e}  at n = {int(n_arr[-1])}")
    print(f"  8 n^2 memory of the dense kernel: n = {n_dense_max} needs 16 GB; "
          f"n = {int(n_arr[-1])} would need {8.0*n_arr[-1]**2/1e9:.1e} GB")
    big = n_arr >= 32 ** 3 * 6.0          # outside the cache
    mv = np.array(rec["matvec_us"], dtype=float)
    sl = float(np.polyfit(np.log(n_arr[big]), np.log(mv[big]), 1)[0])
    print(f"  measured scaling of one Au: time ~ n^{sl:.2f} "
          f"(fitted over N >= 32, i.e. outside the cache)")

    results["E10_a"] = {k: [fin(v) for v in rec[k]] for k in keys}
    results["E10_a_slope"] = sl
    results["E10_a_note"] = (
        "One matrix-free application costs twelve shifted differences, i.e. "
        "exactly a fixed multiple of n arithmetic, but its measured time "
        f"grows like n^{sl:.2f} in this batch (individual batches fit between "
        "n^1.1 and n^1.5) because the multipass "
        "implementation loses bandwidth once the state leaves the cache "
        "(~10 GB/s at n = 2e5 against ~3 GB/s at n = 1.6e6, for a streaming "
        "peak of 20-30 GB/s measured on the same machine); fusing the "
        "twelve passes is the obvious remedy and does not change the "
        "algorithm.  Best-of-n repetitions are reported, with a run-to-run "
        "scatter of up to a factor 2 on this shared machine.  Per "
        "application it is ~10x costlier than the assembled CSR product on "
        "small grids and within a factor ~2 of it for n >= 2e5, while "
        "needing no assembly at all: the "
        "storage is the state plus the Krylov basis, 8 (m+1) n = 0.31 GB at "
        "n = 1.6e6 and m = 24 (0.40 GB measured peak), against 450 MB for "
        "the assembled CSR form (24 n nnz) of A.  The decisive comparison "
        "is with the dense kernel of the exact propagator, which would need "
        "8 n^2 = 2.0e4 GB at that size.")

    # ------------------------------------------------------------------
    # (b) Krylov dimension law  m(theta),  theta = omega_max * dt
    # ------------------------------------------------------------------
    print("\n  (b) Krylov dimension law (3D 8x8x8, tol = 1e-13)")
    model = scph.MaxwellModelND(dim=3, Ns=(8, 8, 8), Ls=(L, L, L),
                                sigma=0.0, matrix_free=False)
    w_max = model.op.omega_max_analytic()
    rng = np.random.default_rng(5)
    u0 = rng.standard_normal(model.n)
    u0 /= np.linalg.norm(u0)
    print(f"      omega_max = {w_max:.4f}   (CFL = 1  <=>  theta = 2)")
    print("       theta          dt       m   matvecs   tol(est)"
          "   rel.err vs expm")
    b_rec = {"theta": [], "dt": [], "m": [], "matvecs": [], "err": [],
             "tol_est": []}
    for th in (0.25, 0.5, 1.0, 2.0, 4.0, 8.0, 16.0, 32.0, 64.0):
        dt = th / w_max
        K = scph.KrylovExponential(model.op, dt, tol=1e-13, max_dim=192,
                                   n=model.n)
        v = K.apply(u0)
        ref = expm_ref(model.A, u0, dt)
        err = float(np.linalg.norm(v - ref))
        for k, val in (("theta", th), ("dt", dt), ("m", K.m_last),
                       ("matvecs", K.matvecs), ("err", err),
                       ("tol_est", K.tol_achieved)):
            b_rec[k].append(val)
        print(f"      {th:6.2f}  {dt:11.5f}  {K.m_last:5d}   {K.matvecs:5d}"
              f"   {K.tol_achieved:9.2e}   {err:9.2e}")
    th_a = np.array(b_rec["theta"])
    m_a = np.array(b_rec["m"], dtype=float)
    sel = th_a >= 2.0
    fit = np.polyfit(np.log(th_a[sel]), np.log(m_a[sel]), 1)
    slope_m, pref_m = float(fit[0]), float(np.exp(fit[1]))
    print(f"      fitted law: m ~ {pref_m:.2f} theta^{slope_m:.2f}; "
          f"m/theta in [{np.min(m_a/th_a):.2f}, {np.max(m_a/th_a):.2f}]")
    results["E10_b"] = {k: [fin(v) for v in b_rec[k]]
                        for k in ("theta", "dt", "m", "matvecs", "err",
                                  "tol_est")}
    results["E10_b_slope"] = slope_m
    results["E10_b_prefactor"] = pref_m
    results["E10_b_omega_max"] = float(w_max)

    # ------------------------------------------------------------------
    # (c) accuracy per unit of work at a fixed physical time
    # ------------------------------------------------------------------
    print(f"\n  (c) accuracy vs work at T = {E10_T} "
          f"(3D 8x8x8, n = {model.n}, reference = expm_multiply)")
    cfl = model.cfl_dt()
    nz, ny, nx = model.op.grid
    rng = np.random.default_rng(7)
    u0c = rng.standard_normal(model.n)
    u0c /= np.linalg.norm(u0c)
    uref = expm_ref(model.A, u0c, E10_T)
    print(f"      omega_max = {w_max:.3f}, CFL step dt = {cfl:.5f};")
    print("      every scheme takes dt = T / nsteps, i.e. all of them land")
    print("      exactly on T (no interpolation error in the comparison)")
    print("      scheme   nsteps        dt     CFL    m(mean)   work[#Au]"
          "    rel.err      wall[s]")
    c_rec = {k: {"dt": [], "steps": [], "m": [], "work": [], "err": [],
                 "wall": []} for k in ("FDTD", "RK4", "Krylov")}
    E0 = u0c.reshape(6, nz, ny, nx)[:3].copy()
    H0 = u0c.reshape(6, nz, ny, nx)[3:].copy()

    for nsteps in (16, 32, 64, 128):
        dt = E10_T / nsteps
        st = scph.leapfrog_init_3d(model.op, E0, H0, dt)
        t0 = time.perf_counter()
        for _ in range(nsteps):
            st = scph.leapfrog_step_3d(model.op, st, dt)
        wall = time.perf_counter() - t0
        E, Hm = st
        H = Hm + 0.5 * dt * model.op.faraday(E)     # H to the E time level
        u = np.concatenate([E.ravel(), H.ravel()])
        err = float(np.linalg.norm(u - uref))
        row = dict(dt=dt, steps=nsteps, m=0.0, work=float(nsteps), err=err,
                   wall=wall)
        for k, v in row.items():
            c_rec["FDTD"][k].append(v)
        print(f"      FDTD     {nsteps:6d}  {dt:8.5f}  {dt/cfl:6.3f}"
              f"        -   {nsteps:8.0f}   {err:9.2e}  {wall:8.3f}")

    for nsteps in (16, 32, 64, 128):
        dt = E10_T / nsteps
        u = u0c.copy()
        t0 = time.perf_counter()
        for _ in range(nsteps):
            u = scph.rk4_apply(model.matvec, u, dt)
        wall = time.perf_counter() - t0
        err = float(np.linalg.norm(u - uref))
        work = 4.0 * nsteps
        row = dict(dt=dt, steps=nsteps, m=4.0, work=work, err=err, wall=wall)
        for k, v in row.items():
            c_rec["RK4"][k].append(v)
        print(f"      RK4      {nsteps:6d}  {dt:8.5f}  {dt/cfl:6.3f}"
              f"     4.00   {work:8.0f}   {err:9.2e}  {wall:8.3f}")

    for nsteps in (1, 2, 4, 8, 16, 32, 64):
        dt = E10_T / nsteps
        prop = scph.propagator_3d(model, dt, backend="krylov", tol=1e-12,
                                  max_dim=192)
        u = u0c.copy()
        t0 = time.perf_counter()
        for _ in range(nsteps):
            u = prop @ u
        wall = time.perf_counter() - t0
        err = float(np.linalg.norm(u - uref))
        work = float(prop.matvecs)
        m_mean = work / nsteps
        row = dict(dt=dt, steps=nsteps, m=m_mean, work=work, err=err,
                   wall=wall)
        for k, v in row.items():
            c_rec["Krylov"][k].append(v)
        print(f"      Krylov   {nsteps:6d}  {dt:8.5f}  {dt/cfl:6.3f}"
              f"   {m_mean:6.2f}   {work:8.0f}   {err:9.2e}  {wall:8.3f}")
    results["E10_c"] = {k: {kk: [fin(x) for x in vv] for kk, vv in v.items()}
                        for k, v in c_rec.items()}
    results["E10_c_T"] = E10_T
    results["E10_c_n"] = int(model.n)
    results["E10_c_note"] = (
        "the structure-preserving step costs m+1 applications with "
        "m ~ C (omega_max dt)^(1/3), so the work to reach a fixed time, "
        "~ (T/dt) m, *decreases* with dt: from 704 applications at CFL = 0.22 "
        "to 49 at CFL = 13.9, both at ~1e-14 accuracy. FDTD/RK4 cannot trade "
        "accuracy for work at all -- they are capped by the CFL condition and "
        "need 128 (resp. 512) applications to reach 2e-2 (resp. 1e-4) at the "
        "same time, while the exponential step beats both with 49.")

    # ------------------------------------------------------------------
    # figure
    # ------------------------------------------------------------------
    fig, axes = plt.subplots(1, 3, figsize=(10.5, 2.9), constrained_layout=True)
    ax = axes[0]
    ax.loglog(n_arr, rec["matvec_us"], "o-", color="k",
              label=r"matrix-free $Au$")
    sp_u = np.array(rec["sparse_us"], dtype=float)
    good = np.isfinite(sp_u)
    ax.loglog(n_arr[good], sp_u[good], "s--", color="tab:red",
              label=r"sparse $Au$ (assembled)")
    ax.loglog(n_arr, rec["matvec_us"][0] * n_arr / n_arr[0], ":", color="gray",
              lw=1.0, label=r"$O(n)$")
    ax.set_xlabel("$n$")
    ax.set_ylabel(r"one $Au$ [$\mu$s], best of $n$")
    ax.set_title(r"(a) one $Au$, $n$ up to $1.6\times10^{6}$")
    ax.legend(loc="upper left")
    ax.text(0.30, 0.06,
            f"Krylov basis {rec['basis_MB'][-1]:.0f} MB  ($m={rec['m'][-1]}$)\n"
            f"dense kernel {rec['dense_GB'][-1]:.1e} GB",
            transform=ax.transAxes, fontsize=6.5)

    ax = axes[1]
    ax.loglog(b_rec["theta"], b_rec["m"], "o-", color="k", label="measured $m$")
    ax.loglog(th_a, pref_m * th_a ** slope_m, "--", color="tab:red", lw=0.9,
              label=rf"$m\propto\theta^{{{slope_m:.2f}}}$")
    ax.set_xlabel(r"$\theta=\omega_{\max}\Delta t$")
    ax.set_ylabel("Krylov dimension $m$")
    ax.set_title(r"(b) dimension law $m(\theta)$")
    ax.legend(loc="upper left")
    ax.text(0.52, 0.08, r"$\approx 5$ extra vectors" "\n"
            r"per doubling of $\theta$",
            transform=ax.transAxes, fontsize=6.5)

    ax = axes[2]
    for name in ("FDTD", "RK4", "Krylov"):
        st = dict(STYLE["PI-EX"] if name == "Krylov" else STYLE[name])
        st.pop("marker", None)
        lbl = "PI-EX (Krylov)" if name == "Krylov" else name
        ax.loglog(c_rec[name]["work"], c_rec[name]["err"], "o-", label=lbl, **st)
    ax.set_xlabel(r"work (number of $Au$ applications)"); ax.set_ylabel("relative error")
    ax.set_title(r"(c) accuracy per unit of work, $T=1$")
    ax.legend(loc="center right")
    for a in (axes[1], axes[2]):
        a.xaxis.set_major_formatter(mtick.ScalarFormatter())
        a.xaxis.set_minor_formatter(mtick.NullFormatter())
    axes[1].set_xticks([0.25, 1.0, 4.0, 16.0, 64.0])
    axes[2].set_xticks([10.0, 30.0, 100.0, 300.0, 1000.0])
    axes[0].set_xticks([1e3, 1e4, 1e5, 1e6])
    axes[0].set_xticklabels([r"$10^3$", r"$10^4$", r"$10^5$", r"$10^6$"])
    axes[0].xaxis.set_minor_formatter(mtick.NullFormatter())
    save(fig, "fig9_scalability")
    return model


def experiment_11():
    """E11: non-uniform 2D two-fluid -- Meissner screening and London audit.

    A normal-metal slab (omega_p = 10, lambda = 0.1) is embedded in a
    superconductor (omega_p = 30, lambda = 1/30).  A trapped flux bundle
    is relaxed with the M-inner-product Krylov propagator and audited
    against the direct (sparse) London projection: the relaxed state
    agrees with the projection to round-off, the energy is monotone in
    the energy metric at every tolerance, and the trapped field decays
    with the *local* penetration depth: fitted kappa = 30.8 vs
    1/lambda = 30 in the superconductor.
    """
    print("\n=== E11: non-uniform 2D two-fluid: Meissner/London audit ===")
    Nx = Ny = 96
    x = (np.arange(Nx) + 0.5) / Nx
    X, Y = np.meshgrid(x, x, indexing="ij")
    # normal-metal slab in the middle, superconductor on both sides
    s = np.exp(-((X - 0.5) / 0.05) ** 2)
    wp_field = 30.0 - 20.0 * s               # 30 outside, 10 in the slab
    lam = 1.0 / wp_field
    model = scph.MaxwellModelND(2, (Nx, Ny), (1.0, 1.0),
                                sigma_field=np.ones((Nx, Ny)),
                                omega_p_field=wp_field)
    n_per = Nx * Ny
    r_diss = model.dissipation_residual()
    print(f"n = {model.n}, structure residual "
          f"|A^T M + M A + 2 Sigma| = {r_diss:.2e} (non-uniform metric)")

    # trapped flux bundle in the slab
    h0 = np.exp(-((X - 0.5) ** 2 + (Y - 0.5) ** 2) / 0.01)
    u = np.zeros(model.n)
    u[2 * n_per:3 * n_per] = h0.ravel()
    h_star = model.london_projection(h0.ravel(), np.zeros(2 * n_per))
    h_star = h_star.reshape(Nx, Ny)

    # relaxation with the M-inner-product Krylov propagator
    dt, nsteps = 0.1, 400
    kry = scph.KrylovExponential(model.A, dt, tol=1e-12,
                                 metric=model.metric_diag)
    W = [model.energy(u)]
    t0 = time.perf_counter()
    for _ in range(nsteps):
        u = kry.apply(u)
        W.append(model.energy(u))
    W = np.array(W)
    wall = time.perf_counter() - t0
    h_rel = u[2 * n_per:3 * n_per].reshape(Nx, Ny)
    relerr = (np.linalg.norm(h_rel - h_star)
              / np.linalg.norm(h_star))
    max_dW = np.diff(W).max()
    print(f"relaxation: {nsteps} steps in {wall:.1f} s, "
          f"max step-to-step dW = {max_dW:+.2e} (<= 0 up to round-off), "
          f"kernel residual = {model.kernel_residual(u):.1e}")
    print(f"Meissner audit: relaxed h vs direct London projection, "
          f"relative error = {relerr:.1e}")

    # local penetration depth: fit log |h*| along the cut y = 1/2
    row = Ny // 2
    hc = np.abs(h_star[:, row])
    fits = {}
    for lo, hi, name, inv in ((0.52, 0.66, "slab", 10.0),
                               (0.78, 0.97, "SC", 30.0)):
        m = (x > lo) & (x < hi)
        k_fit = -np.polyfit(x[m], np.log(hc[m]), 1)[0]
        fits[name] = (k_fit, inv)
        print(f"local penetration: {name:4s}: kappa_fit = {k_fit:6.2f} vs "
              f"1/lambda = {inv:5.1f}  ({100 * abs(k_fit / inv - 1):4.1f}%)")
    confinement = hc[2] / hc[row]
    print(f"flux confinement h*(0.02)/h*(0.5) = {confinement:.1e}")

    results["E11_n"] = model.n
    results["E11_structure_residual"] = r_diss
    results["E11_relax_vs_london_relerr"] = relerr
    results["E11_max_dW"] = max_dW
    results["E11_kernel_residual"] = model.kernel_residual(u)
    results["E11_kappa_fit"] = {k: v[0] for k, v in fits.items()}
    results["E11_kappa_theory"] = {k: v[1] for k, v in fits.items()}
    results["E11_confinement"] = confinement
    results["E11_W_ratio"] = W[-1] / W[0]

    # sized to match the other 3-panel figures; with the uniform 9 pt font
    # the printed size is consistent with fig7/fig8
    fig, ax = plt.subplots(1, 3, figsize=(9.5, 2.8))
    im0 = ax[0].imshow(lam.T, origin="lower", cmap="viridis",
                       extent=(0, 1, 0, 1))
    cs = ax[0].contour(X, Y, h_star, levels=8, colors="w", linewidths=0.9)
    # label every second contour: the small trapped-field region cannot
    # accommodate eight inline labels without overlap
    ax[0].clabel(cs, cs.levels[::2], fontsize=8, fmt="%.3f")
    fig.colorbar(im0, ax=ax[0], label=r"$\lambda(x,y)$")
    ax[0].set_title(r"(a) $\lambda(x,y)$ and trapped field $h^*$")
    ax[1].semilogy(x, hc, "k-", lw=1.6, label=r"$|h^*(x, 1/2)|$")
    xx = np.linspace(0.5, 1.0, 200)
    ax[1].semilogy(xx, hc[row] * np.exp(-30.0 * (xx - 0.5)), "b--", lw=1.2,
                   label=r"$e^{-|x-x_0|/\lambda_{SC}}$")
    xm = np.linspace(0.5, 0.64, 100)
    ax[1].semilogy(xm, hc[row] * np.exp(-10.0 * (xm - 0.5)), "r--", lw=1.2,
                   label=r"$e^{-|x-x_0|/\lambda_{metal}}$")
    ax[1].set_xlim(0.45, 1.0)
    ax[1].set_xlabel("$x$")
    ax[1].set_ylabel(r"$|h^*|$")
    ax[1].legend()
    ax[1].set_title("(b) local penetration depth")
    ax[2].semilogy(np.arange(nsteps + 1) * dt, W / W[0], "k-", lw=1.6)
    ax[2].set_xlabel("$t$")
    ax[2].set_ylabel(r"$W(t)/W(0)$")
    ax[2].set_title(r"(c) $M$-Krylov relaxation" + "\n"
                    r"(monotone up to round-off)")
    fig.tight_layout()
    save(fig, "fig10_meissner")

    return model


def experiment_12():
    """E12: non-uniform 3D absorption audit, matrix-free.

    A plane-wave Ey packet (varying along x only, so it splits into two
    clean counter-propagating d'Alembert packets) is launched at a
    conducting sphere (sigma = 2) in vacuum (sigma = 0), n = 6 * 40^3 =
    384 000 unknowns, no matrix is ever formed.  Per-step Poynting
    audits with 8-point Gauss-Legendre quadrature of the exact Krylov
    flow reproduce W(u_k) - W(u_k+1) = int sigma |E|^2 dt to ~1e-14.
    """
    print("\n=== E12: 3D non-uniform absorption, matrix-free audit ===")
    N = 40
    x = (np.arange(N) + 0.5) / N
    X, Y, Z = np.meshgrid(x, x, x, indexing="ij")
    r = np.sqrt((X - 0.62) ** 2 + (Y - 0.5) ** 2 + (Z - 0.5) ** 2)
    sig = np.where(r < 0.22, 6.0, 0.0)
    mf = scph.MaxwellModelND(3, (N, N, N), (1.0, 1.0, 1.0),
                             sigma_field=sig, matrix_free=True)
    sigE = mf.op._sigma
    u = np.zeros(mf.n)
    U = u.reshape(6, N, N, N)
    U[1] = np.exp(-((X - 0.3) ** 2) / 0.004)
    cert = mf.op.dissipative_quadratic()
    print(f"n = {mf.n}: |u^T A u + u_E^T Sigma u_E| / (||u|| ||Au||) = "
          f"{cert:.2e}  (certified without a matrix)")

    hx = 1.0 / N
    dt = hx / np.sqrt(3.0)                   # CFL
    nsteps = 62
    t_end = nsteps * dt
    kry = scph.KrylovExponential(mf.op.matvec, dt, tol=1e-10, n=mf.n)
    gl_x, gl_w = np.polynomial.legendre.leggauss(8)
    W = [0.5 * float(u @ u)]
    P = [float((sigE * np.abs(U[:3]) ** 2).sum())]
    audit_steps = set(range(9, nsteps, 10))
    audits = {}
    snap = {}
    for k in range(nsteps):
        if k in (0, nsteps):
            snap[k] = (np.abs(U[:3]) ** 2).sum(axis=0)[:, :, N // 2].copy()
        if k in audit_steps:
            acc = 0.0
            for q, wgt in zip(gl_x, gl_w):
                s = 0.5 * dt * (q + 1)
                Ks = scph.KrylovExponential(mf.op.matvec, s, tol=1e-11,
                                            n=mf.n)
                us = Ks.apply(u)
                acc += 0.5 * dt * wgt * float(
                    (sigE * np.abs(us.reshape(6, N, N, N)[:3]) ** 2).sum())
            u = kry.apply(u)
            W.append(0.5 * float(u @ u))
            audits[k + 1] = W[-2] - W[-1] - acc
        else:
            u = kry.apply(u)
            W.append(0.5 * float(u @ u))
        U = u.reshape(6, N, N, N)
        P.append(float((sigE * np.abs(U[:3]) ** 2).sum()))
    W = np.array(W)
    P = np.array(P)
    max_audit = max(abs(v) for v in audits.values())
    max_dW = np.diff(W).max()
    print(f"{nsteps} steps (dt = {dt:.4f} = CFL, t = {t_end:.2f}): "
          f"W/W0 = {W[-1] / W[0]:.4f}")
    print(f"energy monotone: max dW = {max_dW:+.2e} <= 0")
    print(f"per-step Poynting audit (8-pt Gauss-Legendre on the exact "
          f"flow),\n    W_k - W_k+1 - int sigma|E|^2 dt at steps "
          f"{sorted(audits)}: max |residual| = {max_audit:.2e}")

    results["E12_n"] = mf.n
    results["E12_diss_cert"] = cert
    results["E12_W_ratio"] = W[-1] / W[0]
    results["E12_max_dW"] = max_dW
    results["E12_poynting_max"] = max_audit
    results["E12_audit_steps"] = sorted(audits)
    results["E12_audit_values"] = [audits[k] for k in sorted(audits)]

    snap_end = (np.abs(U[:3]) ** 2).sum(axis=0)[:, :, N // 2]
    # sized to match the other 3-panel figures
    fig, ax = plt.subplots(1, 3, figsize=(9.5, 2.8))
    for a, (S, ttl) in zip(
            ax[:2], ((snap[0], "(a) $|E|^2$ at $t=0$"),
                     (snap_end, rf"(b) $|E|^2$ at $t={t_end:.2f}$"))):
        im = a.imshow(S.T, origin="lower", cmap="magma",
                      extent=(0, 1, 0, 1))
        th = np.linspace(0, 2 * np.pi, 200)
        a.plot(0.62 + 0.22 * np.cos(th), 0.5 + 0.22 * np.sin(th),
               "w--", lw=1.2)
        fig.colorbar(im, ax=a)
        a.set_title(ttl)
        a.set_xlabel("$x$")
        a.set_ylabel("$y$")
    ax[2].semilogy(np.arange(nsteps + 1) * dt, W / W[0], "k-", lw=1.6,
                   label=r"$W(t)/W(0)$")
    ax[2].semilogy(np.arange(nsteps + 1) * dt, P / P.max(), "r-", lw=1.0,
                   alpha=0.7, label=r"$\int\sigma|E|^2$ rate (norm.)")
    ax[2].set_xlabel("$t$")
    ax[2].legend()
    ax[2].set_title(rf"(c) absorption audit" + "\n"
                    rf"(max residual ${max_audit:.1e}$)")
    fig.tight_layout()
    save(fig, "fig11_absorption")

    return mf


def experiment_13():
    """E13: gauge-invariant TDGL vortex dynamics.

    A vortex-antivortex pair on the torus annihilates under the Strang
    IMEX flow: the energy is strictly monotone, the rectangular loop
    windings stay exactly +-1 until annihilation and 0 after, and the
    order parameter heals to |psi| -> 1 everywhere.
    """
    print("\n=== E13: gauge TDGL: vortex-antivortex annihilation ===")
    N = 64
    g = scph.GaugeTDGL2D(N, N, xi=6.0 / N, kappa=0.3)
    psi = g.initial_vortex([(0.35, 0.5, 1), (0.65, 0.5, -1)])
    dt, nsteps = 0.05, 4000
    W = [g.energy(psi)]
    w1 = [g.loop_winding(psi, 13, 32, 22, 42)]
    w2 = [g.loop_winding(psi, 32, 51, 22, 42)]
    t0 = time.perf_counter()
    snap = {0: np.abs(psi).copy()}
    for k in range(nsteps):
        psi = g.step(psi, dt)
        W.append(g.energy(psi))
        w1.append(g.loop_winding(psi, 13, 32, 22, 42))
        w2.append(g.loop_winding(psi, 32, 51, 22, 42))
        if (k + 1) in (1200, 2800):
            snap[(k + 1) * dt] = np.abs(psi).copy()
    wall = time.perf_counter() - t0
    W = np.array(W)
    w1 = np.array(w1)
    w2 = np.array(w2)
    ann = int(np.argmax(np.abs(w1) < 0.5))
    max_dW = np.diff(W).max()
    pos0 = g.vortex_positions(g.initial_vortex([(0.35, 0.5, 1),
                                                (0.65, 0.5, -1)]))
    print(f"{nsteps} steps in {wall:.1f} s: initial charges = {pos0}")
    print(f"energy monotone: max dW = {max_dW:+.2e} <= 0, "
          f"W(0) = {W[0]:.2f} -> W(t) = {W[-1]:.2e}")
    print(f"loop windings stay {w1[:ann].min():.0f}/{w1[:ann].max():.0f} "
          f"and {w2[:ann].min():.0f}/{w2[:ann].max():.0f} until "
          f"annihilation at t = {ann * dt:.1f}, then 0/0")
    print(f"healing: min|psi| recovered to {np.abs(psi).min():.3f} "
          f"(-> 1), residual charges = {g.vortex_positions(psi)}")

    results["E13_annihilation_t"] = ann * dt
    results["E13_max_dW"] = max_dW
    results["E13_W0"] = W[0]
    results["E13_W_end"] = W[-1]
    results["E13_min_psi_end"] = float(np.abs(psi).min())

    # sized to match the other 3-panel figures (slightly wider for the
    # fourth panel); with the uniform 9 pt font the printed size is
    # consistent with the rest of the manuscript
    fig, ax = plt.subplots(1, 4, figsize=(12.0, 2.7))
    keys = sorted(snap.keys())
    labels = ["(a)", "(b)", "(c)"]
    for a, lbl, key in zip(ax[:3], labels, keys):
        S = snap[key]
        im = a.imshow(S.T, origin="lower", cmap="viridis",
                      extent=(0, 1, 0, 1), vmin=0.0, vmax=1.0)
        fig.colorbar(im, ax=a)
        a.set_title(rf"{lbl} $|\psi|$ at $t={key:.0f}$")
        a.set_xlabel("$x$")
        a.set_ylabel("$y$")
    ts = np.arange(nsteps + 1) * dt
    ax[3].semilogy(ts, W, "k-", lw=1.6, label=r"$W(t)$")
    ax[3].plot(ts, w1, "b-", lw=1.0, label="winding 1")
    ax[3].plot(ts, w2, "r-", lw=1.0, label="winding 2")
    ax[3].axvline(ann * dt, color="gray", ls=":", lw=1.0)
    ax[3].set_xlabel("$t$")
    ax[3].legend(loc="center right")
    ax[3].set_title(rf"(d) $W(t)$ and loop windings" + "\n"
                    rf"(annihilation at $t = {ann * dt:.0f}$)")
    fig.tight_layout()
    save(fig, "fig12_vortices")

    return g


if __name__ == "__main__":
    t_start = time.perf_counter()
    experiment_1()
    experiment_2()
    experiment_3()
    experiment_4()
    experiment_5()
    experiment_6()
    experiment_7()
    experiment_8()
    experiment_9()
    experiment_10()
    experiment_11()
    experiment_12()
    experiment_13()
    with open(os.path.join(RES, "results.json"), "w") as fh:
        json.dump(results, fh, indent=1)
    print(f"\nall experiments done in {time.perf_counter()-t_start:.1f} s")
    print("results ->", os.path.join(RES, "results.json"))
