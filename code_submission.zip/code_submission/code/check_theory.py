"""Verification of the theoretical results.

Thirty-one sets of consistency checks:

  1. Discrete summation-by-parts in 1D
  2. Port-Hamiltonian structure in 1D
  3. M-orthogonality of the exact propagator (1D, sigma=0)
  4. Analytic semi-discrete eigenfrequencies (1D)
  5. Symplectic eigenmode ansatz (1D)
  6. Precise integration vs. scipy.linalg.expm (1D)
  7. Strang splitting convergence order (1D)
  8. Strang propagator M-orthogonality (1D)

  9. Discrete de Rham complex in 2D TM (Chz = -C^T)
 10. 2D Maxwell skew-adjointness in M = I
 11. 2D energy conservation under the exact propagator
 12. 2D dissipative decay rate

 13. TDGL linear sub-flow skew-adjointness
 14. TDGL IMEX Strang energy monotonicity
 15. TDGL Newton iteration convergence

 16. 3D de Rham complex (all six pairs of Curl operators)
 17. 3D Maxwell skew-adjointness in M = I
 18. 3D energy conservation under the exact propagator

 19. Precise-integration kernel accuracy, including weakly dissipative
    generators (guards against a badly chosen number of squarings)
 20. Static London manifold ker(A) = {(0, h, D h)} and its removal
    before a decay-rate measurement

 21. 3D discrete dispersion relation: the singular values of C_EH are
     exactly the Yee symbol 4 sum sin^2(k_i h_i/2)/h_i^2 (twice) with one
     zero per mode, and the centred stencil adds spurious static modes
 22. Matrix-free Yee operator == sparse assembly, for both stencils and
     with/without damping, including a matrix-free-only skewness test at
     n = 6.6e5 where no matrix is ever formed
 23. Krylov (Arnoldi) exponential == dense expm == precise integration,
     and the Krylov dimension is independent of the grid size
 24. Krylov dimension law m(theta) with theta = omega_max dt
 25. Krylov memory/cost model: an O((m+1) n) basis against the O(n^2)
     dense propagator, and the crossover where the latter stops fitting

 26. Port-Hamiltonian metric freedom: the semi-discrete operator is
    A = (J - R) Q with J = -J^T, R >= 0 diagonal, for *any* positive
    diagonal metric Q (non-uniform material weights); A^T Q + Q A =
    -2 Q R Q <= 0, exp(A dt) is exactly Q-orthogonal for sigma = 0 and
    the energy is monotone for sigma > 0
 27. Boundary port: the conjugate pair (v, y) = (E_y|wall, -h_0/dz)
    satisfies the node-wise power balance dW/dt = -sigma|e|^2 + v y
    pointwise (roundoff), in the frequency domain for a lossy wall
    (time-averaged power balance) and -- for a lossless wall -- with
    zero net time-averaged power through an evanescent domain

 28. M-inner-product (energy-metric) Krylov: for a non-uniform metric
    M the truncated M-Krylov propagator is *exactly* non-expansive in
    W = 1/2 u^T M u for every tolerance (drift at the round-off floor),
    while the Euclidean realization drifts at O(tol); with
    A^T M + M A <= 0 the M-Krylov step is exactly energy-monotone at
    every tolerance (dissipative case)
 29. Non-uniform materials in 2D: the two-fluid Yee operator with
    *field* sigma(x, y) and omega_p(x, y) satisfies
    A^T M + M A = -2 Sigma exactly (M = diag(1,1,1,lambda^2,lambda^2));
    the relaxation exp(A t) u0 converges to the M-orthogonal projection
    onto ker(A), which is characterized by the discrete London
    (screening) equation (I + C^T lambda^2 C) h* = h0 -- the time
    integration lands on the direct sparse solve to high accuracy
 30. Gauge-invariant TDGL with link variables: the discrete GL energy
    is *exactly* invariant under random discrete gauge transforms
    (round-off); the IMEX-Strang dynamics is exactly gauge covariant;
    the covariant Laplacian is Hermitian; the closed-form CN step of
    the logistic potential keeps x = |psi|^2 in [0, 1] and is monotone
    for every dt (including dt -> infinity); the loop winding of a
    vortex is conserved by the flow
 31. Non-uniform dissipation in 3D at n = 2.8e5, matrix-free: the
    quadratic-form certification |u^T A u + u_E^T Sigma u_E| = 0
    (round-off, no matrix formed), and the Krylov step is exactly
    energy non-expansive in M = I
"""
import numpy as np
import scipy.linalg as sla
import scipy.sparse as sp
import scipy.sparse.linalg as spla
import scph

np.set_printoptions(precision=4, suppress=True)

# =========================================================================
# 1D checks (backward compatible)
# =========================================================================

print("=" * 78)
print("1) 1D Discrete summation-by-parts (skew-adjointness of D, Dt = -D^T)")
print("=" * 78)
for N in (8, 16, 33, 64):
    D, Dt, dz = scph.yee_operators_1d(N, 1.0)
    rng = np.random.default_rng(0)
    e = rng.standard_normal(N - 1)
    h = rng.standard_normal(N)
    lhs = float(e @ (D @ h) + h @ (Dt @ e))
    print(f"  N = {N:3d}: |e^T D h + h^T Dt e| = {abs(lhs):.3e}")

print()
print("=" * 78)
print("2) 1D Port-Hamiltonian structure: A^T M + M A = -2 sigma diag(I_e,0,0)")
print("=" * 78)
for sigma in (0.0, 0.05):
    m = scph.SuperconductingModel(N=24, L=1.0, omega_p=6.0, sigma=sigma)
    print(f"  sigma = {sigma:<5}: residual = {m.jacobi_residual():.3e}   (n = {m.n_aug})")

print()
print("=" * 78)
print("3) 1D M-orthogonality of exp(A dt)  (sigma = 0)")
print("=" * 78)
m = scph.SuperconductingModel(N=24, L=1.0, omega_p=6.0, sigma=0.0)
for dt in (1e-3, 1e-2, 0.1, 1.0, 10.0):
    print(f"  dt = {dt:<6}: ||Phi^T M Phi - M||_F/||M||_F = "
          f"{m.orthogonality_residual(dt):.3e}")

print()
print("=" * 78)
print("4) 1D Analytic semi-discrete eigenfrequencies vs numerical")
print("=" * 78)
m = scph.SuperconductingModel(N=64, L=1.0, omega_p=10.0, sigma=0.0)
w_num = np.sort(np.abs(np.linalg.eigvals(m.A)))
w_num = np.unique(w_num[w_num > 1e-8])[:4]
for i in range(4):
    w_an = m.discrete_eigenfrequency(i + 1)
    print(f"  mode {i+1}: discrete = {w_an:.10f},  numerical = {w_num[i]:.10f},"
          f"  rel.diff = {abs(w_an-w_num[i])/w_an:.2e}")

print()
print("=" * 78)
print("5) 1D Symplectic eigenmode ansatz")
print("=" * 78)
u0 = m.eigenmode(1)
w1 = m.discrete_eigenfrequency(1)
T = 2 * np.pi / w1
err = sla.norm(m.exact_solution(u0, T) - u0) / sla.norm(u0)
print(f"  ||exp(A T) u_1 - u_1|| / ||u_1||  (T = 2 pi / omega_1) = {err:.3e}")

print()
print("=" * 78)
print("6) 1D Precise integration vs scipy.linalg.expm")
print("=" * 78)
for N, dt in ((16, 1e-3), (16, 0.1), (16, 1.0), (32, 0.5)):
    mm = scph.SuperconductingModel(N=N, L=1.0, omega_p=10.0, sigma=0.05)
    P = scph.precise_integration(mm.A, dt)
    Pref = sla.expm(mm.A * dt)
    print(f"  N = {N:3d}, dt = {dt:<6}: relative error = "
          f"{sla.norm(P - Pref)/sla.norm(Pref):.3e}")

print()
print("=" * 78)
print("7) 1D Strang splitting convergence order")
print("=" * 78)
mm = scph.SuperconductingModel(N=32, L=1.0, omega_p=10.0, sigma=0.0)
u0 = mm.eigenmode(1)
w1 = mm.discrete_eigenfrequency(1)
T = 4 * 2 * np.pi / w1
dts = np.array([2e-2, 1e-2, 5e-3, 2.5e-3])
errs = []
for dt in dts:
    n = int(round(T / dt))
    P = scph.strang_propagator(mm, dt)
    u = u0.copy()
    for _ in range(n):
        u = P @ u
    uref = mm.exact_solution(u0, n * dt)
    errs.append(sla.norm(u - uref) / sla.norm(uref))
errs = np.array(errs)
print("  dt        error        observed order")
for i, dt in enumerate(dts):
    order = "" if i == 0 else f"{np.log2(errs[i-1]/errs[i]):.3f}"
    print(f"  {dt:<9.5f} {errs[i]:.3e}   {order}")

print()
print("=" * 78)
print("8) 1D Strang M-orthogonality (sigma = 0)")
print("=" * 78)
for dt in (1e-2, 1e-1, 0.5, 1.0):
    P = scph.strang_propagator(mm, dt)
    R = P.T @ mm.M @ P - mm.M
    print(f"  dt = {dt:<5}: ||P^T M P - M||_F/||M||_F = "
          f"{sla.norm(R)/sla.norm(mm.M):.3e}")


# =========================================================================
# 2D checks (new)
# =========================================================================

print()
print("=" * 78)
print("9) 2D de Rham complex:  Chz = -C^T  (skew-adjointness of curl)")
print("=" * 78)
for Nx, Ny in ((4, 4), (8, 8), (16, 16)):
    for bnd in ("periodic", "pec"):
        Cex_hz, Cey_hz, Chz_ex, Chz_ey, _, _ = scph.yee_operators_2d_tm(
            Nx, Ny, 1.0, 1.0, boundary=bnd)
        r1 = np.max(np.abs(Chz_ex.toarray() + Cex_hz.T.toarray()))
        r2 = np.max(np.abs(Chz_ey.toarray() + Cey_hz.T.toarray()))
        print(f"  Nx=Ny={Nx:2d} ({bnd:9}):  "
              f"||Chz_ex + Cex_hz^T||_inf = {r1:.3e},  "
              f"||Chz_ey + Cey_hz^T||_inf = {r2:.3e}")

print()
print("=" * 78)
print("10) 2D Maxwell skew-adjointness:  ||A^T + A||_F = 0  (sigma=0, periodic)")
print("=" * 78)
for Nx, Ny in ((4, 4), (8, 8), (16, 16)):
    mm = scph.MaxwellModelND(dim=2, Ns=(Nx, Ny), Ls=(1.0, 1.0),
                             sigma=0.0, boundary="periodic")
    print(f"  Nx=Ny={Nx:2d}:  ||A^T + A||_F = {mm.skew_residual():.3e}  "
          f"(n = {mm.n})")

print()
print("=" * 78)
print("11) 2D energy conservation under exp(A dt) (sigma = 0)")
print("=" * 78)
mm = scph.MaxwellModelND(dim=2, Ns=(8, 8), Ls=(1.0, 1.0),
                         sigma=0.0, boundary="periodic")
dt = 0.05
Phi = scph.propagator_2d(mm, dt)
u = np.random.RandomState(0).standard_normal(mm.n)
W0 = mm.energy(u)
for k in range(200):
    u = Phi @ u
W1 = mm.energy(u)
print(f"  W(200*dt) - W(0) = {W1 - W0:.3e}  (should be ~0)")

print()
print("=" * 78)
print("12) 2D dissipative decay:  dW/dt = -sigma |E|^2")
print("=" * 78)
mm = scph.MaxwellModelND(dim=2, Ns=(8, 8), Ls=(1.0, 1.0),
                         sigma=0.3, boundary="periodic")
Phi = scph.propagator_2d(mm, dt)
u = np.random.RandomState(0).standard_normal(mm.n)
W0 = mm.energy(u)
n_per = mm.Ns[0] * mm.Ns[1]
E0sq = float(np.sum(u[:2 * n_per] ** 2))
Ws = [W0]
for k in range(40):
    u = Phi @ u
    Ws.append(mm.energy(u))
print(f"  W(40*dt) / W(0) = {Ws[-1]/W0:.6f}  (analytic envelope ~ exp(-sigma*T))")


# =========================================================================
# 3D checks (new)
# =========================================================================

print()
print("=" * 78)
print("16) 3D de Rham complex:  Chz = -C^T  for all six pairs (periodic)")
print("=" * 78)
for Nx, Ny, Nz in ((4, 4, 4), (6, 4, 6)):
    (Cex_hz, Cex_hy, Cey_hz, Cey_hx, Cez_hx, Cez_hy,
     Chx_ey, Chx_ez, Chy_ex, Chy_ez, Chz_ex, Chz_ey, *_) = scph.yee_operators_3d(
        Nx, Ny, Nz, boundary="periodic")
    pairs = [
        ("Chz_ex + Cex_hz^T",  Chz_ex, Cex_hz),
        ("Chz_ey + Cey_hz^T",  Chz_ey, Cey_hz),
        ("Chx_ey + Cey_hx^T",  Chx_ey, Cey_hx),
        ("Chx_ez + Cez_hx^T",  Chx_ez, Cez_hx),
        ("Chy_ex + Cex_hy^T",  Chy_ex, Cex_hy),
        ("Chy_ez + Cez_hy^T",  Chy_ez, Cez_hy),
    ]
    res = ", ".join(f"||{lbl}||_F = {float(spla.norm(A + B.T)):.0e}"
                    for lbl, A, B in pairs)
    print(f"  Nx, Ny, Nz = ({Nx},{Ny},{Nz}):  {res}")

print()
print("=" * 78)
print("17) 3D Maxwell skew-adjointness:  ||A^T + A||_F = 0  (sigma = 0)")
print("=" * 78)
for Nx, Ny, Nz in ((4, 4, 4), (6, 4, 6)):
    mm = scph.MaxwellModelND(dim=3, Ns=(Nx, Ny, Nz), Ls=(1.0, 1.0, 1.0),
                              sigma=0.0, boundary="periodic")
    print(f"  {Nx}x{Ny}x{Nz}:  ||A^T + A||_F = {mm.skew_residual():.3e}  "
          f"(n = {mm.n})")

print()
print("=" * 78)
print("18) 3D energy conservation under exact propagator (sigma = 0)")
print("=" * 78)
mm = scph.MaxwellModelND(dim=3, Ns=(4, 4, 4), Ls=(1.0, 1.0, 1.0),
                          sigma=0.0, boundary="periodic")
dt = 0.05
Phi = scph.propagator_3d(mm, dt)
u = np.random.RandomState(0).standard_normal(mm.n)
W0 = mm.energy(u)
for k in range(100):
    u = Phi @ u
W1 = mm.energy(u)
print(f"  W(100*dt) - W(0) = {W1 - W0:.3e}  (should be ~0)")


# =========================================================================
# TDGL checks (new)
# =========================================================================

print()
print("=" * 78)
print("13) TDGL linear sub-flow skew-adjointness:  L^T + L = 0  (sigma = 0)")
print("=" * 78)
for N, kappa in ((16, 1.0), (32, 2.0)):
    tdgl = scph.TDGLModel1D(N=N, L=1.0, sigma=0.0, beta=0.0, kappa=kappa)
    r = np.linalg.norm(tdgl.L_mat + tdgl.L_mat.T)
    print(f"  N = {N:3d}, kappa = {kappa:<3}:  ||L + L^T||_F = {r:.3e}")

print()
print("=" * 78)
print("14) TDGL IMEX Strang: energy monotone non-increasing")
print("=" * 78)
tdgl = scph.TDGLModel1D(N=32, L=1.0, sigma=0.2, beta=0.3, kappa=1.0)
dt = 0.05
step = scph.imex_strang_tdgl(tdgl, dt)
u = np.random.RandomState(0).standard_normal(tdgl.n) * 0.5
u[tdgl.ih] = 0.0
W0 = tdgl.energy(u)
Ws = [W0]
for k in range(50):
    u = step(u)
    Ws.append(tdgl.energy(u))
deltas = np.diff(Ws)
print(f"  W(0) = {Ws[0]:.6f}, W(50*dt) = {Ws[-1]:.6f},  "
      f"min(dW) = {deltas.min():.3e}, max(dW) = {deltas.max():.3e}")
print(f"  monotone non-increasing: {bool(np.all(deltas <= 1e-10))}")

print()
print("=" * 78)
print("15) TDGL Newton iteration convergence (crank-nicolson) and the")
print("    closed-form per-cell scaling factor (dense Newton == closed form)")
print("=" * 78)
tdgl = scph.TDGLModel1D(N=16, L=1.0, sigma=0.1, beta=0.3, kappa=1.0)
dt = 0.1
u = np.random.RandomState(0).standard_normal(tdgl.n) * 0.2
u[tdgl.ih] = 0.0
u_nl = scph.newton_solve_cn(tdgl.N_func, tdgl.N_jac, u, dt,
                              tol=1e-13, max_iter=30, verbose=True)
print(f"  Initial W = {tdgl.energy(u):.6f}, after Newton W = {tdgl.energy(u_nl):.6f}")
print(f"  W change = {tdgl.energy(u_nl) - tdgl.energy(u):.3e}  (should be <= 0)")

u_cf = tdgl.nonlinear_step_exact(u, dt)
g = tdgl.scaling_factor(u, dt)
c = dt * tdgl.beta * (u[tdgl.iu] ** 2 + u[tdgl.iv] ** 2)
rel = np.linalg.norm(u_cf - u_nl) / np.linalg.norm(u_nl)
cub = float(np.max(np.abs(g - 1.0 + 0.5 * c * (1.0 + g ** 3))))
print(f"  closed-form O(n) per-cell step vs dense Newton: ||diff||/||ref|| = {rel:.3e}")
print(f"  cubic residual max|f(gamma)| = {cub:.3e};  max|gamma| = "
      f"{np.max(np.abs(g)):.6f} (< 1);  max c = {np.max(c):.3f}")
for cc in (0.5, 2.0, 2.5, 10.0, 1e3, 1e6):
    uu = np.zeros(tdgl.n)
    uu[tdgl.iu[0]] = np.sqrt(cc / (dt * tdgl.beta))
    gg = float(tdgl.scaling_factor(uu, dt)[0])
    print(f"    c = {cc:8.1f}:  gamma = {gg:+.12f}   "
          f"(|gamma| < 1 always, gamma < 0 iff c > 2)")


# =========================================================================
# The precise-integration kernel itself
# =========================================================================

print()
print("=" * 78)
print("19) Precise-integration kernel: exp(A dt) to machine precision,")
print("    including weakly dissipative generators (slow modes preserved)")
print("=" * 78)
print("   sigma     dt        s     ||P - expm||/||expm||   min|eig| rel. diff")
for sigma in (0.0, 0.02, 0.5):
    mm = scph.SuperconductingModel(N=64, L=1.0, omega_p=10.0, sigma=sigma)
    A, n2 = mm.A, sla.norm(mm.A, 2)
    for dt_pi in (1e-3, 1e-2, 5e-2, 2e-1):
        s = 0 if n2 * dt_pi <= 1.0 else int(np.ceil(np.log2(n2 * dt_pi)))
        P = scph.precise_integration(A, dt_pi)
        ref = sla.expm(A * dt_pi)
        rel = sla.norm(P - ref) / sla.norm(ref)
        eP = np.sort(np.abs(np.linalg.eigvals(P)))
        eR = np.sort(np.abs(np.linalg.eigvals(ref)))
        dr = np.max(np.abs(eP - eR)) / np.max(eR)
        print(f"  {sigma:5.3f}  {dt_pi:<8.4g} {s:3d}     {rel:.3e}"
              f"            {dr:.3e}")

print()
print("  dissipative flow over 200 steps vs scipy expm reference "
      "(sigma = 0.02, dt = 0.01)")
mm = scph.SuperconductingModel(N=64, L=1.0, omega_p=10.0, sigma=0.02)
P = scph.precise_integration(mm.A, 0.01)
Pr = sla.expm(mm.A * 0.01)
u = mm.initial_mode(1)
W0 = mm.energy(u)
for _ in range(200):
    u = P @ u
v = mm.initial_mode(1)
for _ in range(200):
    v = Pr @ v
print(f"    ||u_PI - u_expm||/||u_expm|| = "
      f"{sla.norm(u - v)/sla.norm(v):.3e}")
print(f"    W(200*dt)/W(0) - 1 :  PI-EX = {mm.energy(u)/W0 - 1.0:+.6e}, "
      f"expm = {mm.energy(v)/W0 - 1.0:+.6e}   (must decay, not stagnate)")

print()
print("=" * 78)
print("20) Static London manifold  ker(A) = {(0, h, D h)}  and its removal")
print("=" * 78)
mm = scph.SuperconductingModel(N=64, L=1.0, omega_p=10.0, sigma=0.02)
K = mm.static_subspace()
print(f"  dim ker(A) = {K.shape[1]},  ||A K||_F = {sla.norm(mm.A @ K):.3e}"
      f"   (A is singular, rank = {np.linalg.matrix_rank(mm.A)} of {mm.n_aug})")
u_raw = mm.initial_mode(1)
u_dyn = mm.remove_static_component(u_raw)
print(f"  M-orthogonality  max|K^T M u_dyn| = {np.abs(K.T @ (mm.M @ u_dyn)).max():.3e}")
print(f"  energy fraction of mode 1 inside ker(A) = "
      f"{mm.energy(u_raw - u_dyn)/mm.energy(u_raw):.6f}")
print("  fitted energy decay rate Gamma(T) = -ln(W(T)/W0)/T:")
print("      T        raw mode-1 IC        static-free IC       (sigma = 0.02)")
for T in (50.0, 100.0, 200.0, 400.0, 800.0):
    a = -np.log(mm.energy(mm.exact_solution(u_dyn, T))/mm.energy(u_dyn)) / T
    b = -np.log(mm.energy(mm.exact_solution(u_raw, T))/mm.energy(u_raw)) / T
    print(f"    {T:6.0f}      {b:.8f}          {a:.8f}")


# =========================================================================
# Matrix-free Yee operator and Krylov exponential (new)
# =========================================================================


def _ceh_3d(mm):
    """Assemble the curl block C_EH : (Hx,Hy,Hz) -> (Ex,Ey,Ez)."""
    n_per = mm.nE // 3
    z = sp.csr_matrix((n_per, n_per))
    return sp.vstack([
        sp.hstack([z, mm.Cex_hy, mm.Cex_hz]),
        sp.hstack([mm.Cey_hx, z, mm.Cey_hz]),
        sp.hstack([mm.Cez_hx, mm.Cez_hy, z]),
    ], format="csr")


def _min_poly_degree(N):
    """Degree of the minimal polynomial of the N^3 Yee operator.

    A is skew-adjoint, hence diagonalisable, with eigenvalues
    ``+- i omega(k)`` taken from the discrete dispersion relation, plus
    the static manifold.  A generic vector is cyclic, so the Arnoldi
    basis closes at ``2 * #{distinct omega > 0} + 1``.
    """
    h = 1.0 / N
    s = 4.0 * np.sin(np.pi * np.arange(N) / N) ** 2 / h ** 2
    g = np.meshgrid(s, s, s, indexing="ij")
    sums = np.unique(np.round((g[0] + g[1] + g[2]).ravel(), 8))
    return 2 * int((sums > 1e-12).sum()) + 1


def _yee_symbol(N, h, stencil):
    """Sorted multiset {0} U {omega(k), omega(k)} of the discrete symbol."""
    m = np.arange(N)
    if stencil == "one-sided":
        s = 4.0 * np.sin(np.pi * m / N) ** 2 / h ** 2
    else:
        s = np.sin(2.0 * np.pi * m / N) ** 2 / h ** 2
    w = np.sqrt(sum(np.meshgrid(s, s, s, indexing="ij")))
    return np.sort(np.concatenate([np.zeros(w.size), w.ravel(), w.ravel()]))


print()
print("=" * 78)
print("21) 3D discrete dispersion relation:  sv(C_EH) = Yee symbol,")
print("    and the spurious static mode of the centred stencil")
print("=" * 78)
for N, h in ((4, 0.25), (6, 1.0 / 6)):
    for stencil in ("one-sided", "centred"):
        mm = scph.MaxwellModelND(dim=3, Ns=(N, N, N), Ls=(1.0, 1.0, 1.0),
                                 sigma=0.0, stencil=stencil)
        sv = np.sort(np.linalg.svd(_ceh_3d(mm).toarray(), compute_uv=False))
        ana = _yee_symbol(N, h, stencil)
        tol0 = 1e-9 * ana.max()
        dev = float(np.abs(sv - ana).max() / ana.max())
        print(f"  N = {N}, {stencil:10s}: max|sv_i - omega(k_i)|/omega_max = "
              f"{dev:.2e},  dim ker(C_EH) = {int((sv < tol0).sum())} "
              f"(analytic {int((ana < tol0).sum())}),  "
              f"omega_max = {ana.max():.4f}")
print("  the staggered symbol is reproduced exactly (twice per mode, one")
print("  longitudinal zero); the centred stencil annihilates extra modes")
print()
print("  checkerboard mode H = (0,0,(-1)^(i+j+k)) on an even grid (8^3):")
for stencil in ("one-sided", "centred"):
    op = scph.YeeOperator3D(8, 8, 8, 1.0, 1.0, 1.0, stencil=stencil)
    print(f"    {stencil:10s}: ||C_EH H_ck|| h / ||H_ck|| = "
          f"{op.checkerboard_null_ratio():.4f}   "
          f"(omega_max = {op.omega_max_analytic():.4f})")

print()
print("=" * 78)
print("22) Matrix-free Yee operator == sparse assembly (round-off),")
print("    including a skewness test at n = 6.6e5 with no matrix at all")
print("=" * 78)
for Ns, Ls in (((5, 4, 3), (1.0, 2.0, 1.5)), ((8, 8, 8), (1.0, 1.0, 1.0))):
    for stencil in ("one-sided", "centred"):
        for sigma in (0.0, 0.37):
            mf = scph.MaxwellModelND(dim=3, Ns=Ns, Ls=Ls, sigma=sigma,
                                     matrix_free=True, stencil=stencil)
            spm = scph.MaxwellModelND(dim=3, Ns=Ns, Ls=Ls, sigma=sigma,
                                      matrix_free=False, stencil=stencil)
            dev = 0.0
            skw = 0.0
            for seed in (0, 1, 2):
                u = np.random.default_rng(seed).standard_normal(mf.n)
                u /= np.linalg.norm(u)
                dev = max(dev, float(np.linalg.norm(mf.matvec(u) - spm.A @ u)))
                skw = max(skw, mf.skew_quadratic(u))
            txt = f"{skw:.2e}" if sigma == 0.0 else "  -   (sigma > 0)"
            print(f"  {Ns} {Ls} {stencil:10s} sigma = {sigma:4.2f}:  "
                  f"max||A_mf u - A_sp u|| = {dev:.2e},  "
                  f"|u^T A u|/(||u|| ||A u||) = {txt}")
mm = scph.MaxwellModelND(dim=3, Ns=(48, 48, 48), Ls=(1.0, 1.0, 1.0),
                         sigma=0.0, matrix_free=True)
print(f"  no assembly at all: n = {mm.n}, A is None = {mm.A is None},  "
      f"|u^T A u|/(||u|| ||A u||) = {mm.skew_quadratic(seed=1):.2e}")

print()
print("=" * 78)
print("23) Krylov (Arnoldi) exponential == dense expm == precise integration")
print("=" * 78)
print("     N       n  sigma     theta        dt      m  matvecs"
      "   |Krylov-ref|   |Krylov-PI|   ref")
for N in (4, 6):
    for sigma in (0.0, 0.37):
        mm = scph.MaxwellModelND(dim=3, Ns=(N, N, N), Ls=(1.0, 1.0, 1.0),
                                 sigma=sigma)
        w_max = mm.op.omega_max_analytic()
        A_d = mm.A.toarray() if N == 4 else None
        u0 = np.random.default_rng(4).standard_normal(mm.n)
        u0 /= np.linalg.norm(u0)
        for theta in (0.5, 2.0, 10.0):
            dt = theta / w_max
            K = scph.KrylovExponential(mm.op, dt, tol=1e-13, max_dim=256,
                                       n=mm.n)
            v = K.apply(u0)
            if N == 4:
                ref = sla.expm(A_d * dt) @ u0
                pi_txt = f"{sla.norm(v - scph.precise_integration(A_d, dt) @ u0):.2e}"
                src = "dense expm"
            else:
                ref = spla.expm_multiply(mm.A, u0, 0.0, dt, num=2)[-1]
                pi_txt = "    -    "
                src = "expm_multiply"
            print(f"  {N:3d}  {mm.n:6d}  {sigma:4.2f}  {theta:6.2f}"
                  f"  {dt:8.5f}  {K.m_last:5d}   {K.matvecs:5d}"
                  f"     {sla.norm(v - ref):.2e}    {pi_txt}   {src}")
print()
print("  Krylov dimension at fixed theta = omega_max dt = 2 (n independent):")
print("       N         n      m   matvecs   rel.err vs expm_multiply")
for N in (4, 6, 8, 12, 16):
    mm = scph.MaxwellModelND(dim=3, Ns=(N, N, N), Ls=(1.0, 1.0, 1.0),
                             sigma=0.0)
    dt = 2.0 / mm.op.omega_max_analytic()
    K = scph.KrylovExponential(mm.op, dt, tol=1e-13, max_dim=256, n=mm.n)
    u0 = np.random.default_rng(4).standard_normal(mm.n)
    u0 /= np.linalg.norm(u0)
    v = K.apply(u0)
    ref = spla.expm_multiply(mm.A, u0, 0.0, dt, num=2)[-1]
    print(f"    {N:3d}  {mm.n:8d}  {K.m_last:5d}   {K.matvecs:5d}"
          f"     {sla.norm(v - ref):.2e}")

print()
print("=" * 78)
print("24) Krylov dimension law  m(theta),  theta = omega_max dt")
print("=" * 78)
theta_list = (0.25, 0.5, 1.0, 2.0, 4.0, 8.0, 16.0, 32.0)
print("  (a) exact closure on a coarse grid (N = 4): the minimal polynomial")
print("      degree of A is 2 * (#distinct omega > 0) + 1, so the Arnoldi")
print("      basis closes exactly and no theta can need more than that")
mm = scph.MaxwellModelND(dim=3, Ns=(4, 4, 4), Ls=(1.0, 1.0, 1.0), sigma=0.0)
w_max = mm.op.omega_max_analytic()
u0 = np.random.default_rng(9).standard_normal(mm.n)
u0 /= np.linalg.norm(u0)
min_deg = _min_poly_degree(4)
print(f"      #distinct omega > 0 = {(min_deg - 1)//2},  "
      f"minimal polynomial degree = {min_deg}")
print("      theta         dt      m   matvecs   rel.err vs dense expm")
for theta in theta_list:
    dt = theta / w_max
    K = scph.KrylovExponential(mm.op, dt, tol=1e-13, max_dim=256, n=mm.n)
    v = K.apply(u0)
    ref = sla.expm(mm.A.toarray() * dt) @ u0
    print(f"      {theta:6.2f}  {dt:8.5f}  {K.m_last:5d}   {K.matvecs:5d}"
          f"       {sla.norm(v - ref):9.2e}")

print("  (b) m(theta) on a grid whose spectrum is not exhausted (N = 6):")
mm = scph.MaxwellModelND(dim=3, Ns=(6, 6, 6), Ls=(1.0, 1.0, 1.0), sigma=0.0)
w_max = mm.op.omega_max_analytic()
u0 = np.random.default_rng(9).standard_normal(mm.n)
u0 /= np.linalg.norm(u0)
th_list, m_list = [], []
print("      theta         dt      m   matvecs   rel.err vs expm_multiply"
      "   m/theta")
for theta in theta_list:
    dt = theta / w_max
    K = scph.KrylovExponential(mm.op, dt, tol=1e-13, max_dim=256, n=mm.n)
    v = K.apply(u0)
    ref = spla.expm_multiply(mm.A, u0, 0.0, dt, num=2)[-1]
    th_list.append(theta)
    m_list.append(K.m_last)
    print(f"      {theta:6.2f}  {dt:8.5f}  {K.m_last:5d}   {K.matvecs:5d}"
          f"       {sla.norm(v - ref):9.2e}         {K.m_last/theta:6.2f}")
th_a = np.array(th_list)
m_a = np.array(m_list, dtype=float)
fit = np.polyfit(np.log(th_a), np.log(m_a), 1)
print(f"  fitted law over theta in [0.25, 32]: m ~ {np.exp(fit[1]):.2f}"
      f" theta^{fit[0]:.2f};  the work per unit time is m/theta, which"
      f" *decays* with theta")

print()
print("=" * 78)
print("25) Krylov memory/cost model vs the dense propagator")
print("=" * 78)
mm = scph.MaxwellModelND(dim=3, Ns=(12, 12, 12), Ls=(1.0, 1.0, 1.0),
                         sigma=0.0)
mmf = scph.MaxwellModelND(dim=3, Ns=(12, 12, 12), Ls=(1.0, 1.0, 1.0),
                          sigma=0.0, matrix_free=True)
dt = 2.0 / mm.op.omega_max_analytic()
K = scph.KrylovExponential(mmf.op, dt, tol=1e-13, max_dim=256, n=mmf.n)
K.apply(np.random.default_rng(2).standard_normal(mmf.n))
logical = 8 * (K.m_last + 1) * mmf.n
print(f"  n = {mmf.n}, m = {K.m_last}:  basis accounting 8 (m+1) n = "
      f"{K.basis_bytes/1e6:.2f} MB (matches formula: "
      f"{K.basis_bytes == logical}),  geometric-growth peak = "
      f"{K.peak_bytes/1e6:.2f} MB  (<= 2x logical)")
print(f"  dense propagator would need 8 n^2 = "
      f"{8.0*mmf.n**2/1e6:.1f} MB for this problem and "
      f"{8.0*(1.6e6)**2/1e9:.1e} GB at n = 1.6e6; the sparse assembly of A "
      f"costs 24 n nnz ({24*mmf.n} entries here)")
for budget in (1e9, 16e9):
    print(f"  8 n^2 = {budget/1e9:.0f} GB is exhausted at n = "
          f"{int(np.sqrt(budget/8.0))}, i.e. below the sizes reached by "
          f"the matrix-free path")
print("  => the O((m+1) n) Krylov basis is what makes the precise-integrator")
print("     flow usable at n >= 10^6 (experiment E10)")

print()
print("=" * 78)
print("26) Port-Hamiltonian metric freedom: A = (J - R) Q for ANY diagonal Q > 0")
print("=" * 78)
rng = np.random.default_rng(7)
for N, sigma in ((24, 0.0), (24, 0.05), (48, 0.02)):
    m = scph.SuperconductingModel(N=N, L=1.0, omega_p=6.0, sigma=sigma)
    A_ref, _, _, _ = scph.ph_structure_1d(N, 1.0, omega_p=6.0, sigma=sigma)
    asm = float(np.linalg.norm(A_ref - m.A) / np.linalg.norm(m.A))

    # a random positive diagonal metric = non-uniform material weights
    Q = np.exp(rng.uniform(-1.5, 1.5, size=m.n))
    A, J, R, Qd = scph.ph_structure_1d(N, 1.0, omega_p=6.0, sigma=sigma, Q=Q)
    skew = float(np.linalg.norm(J + J.T) / np.linalg.norm(J))
    ident = float(np.linalg.norm(A.T @ Qd + Qd @ A + 2 * Qd @ R @ Qd)
                  / np.linalg.norm(Qd @ A))
    sym = A.T @ Qd + Qd @ A
    lam = np.linalg.eigvalsh(sym)
    lam_max, lam_min = float(lam[-1]), float(lam[0])
    scale_sym = max(float(np.linalg.norm(Qd @ R @ Qd)), 1e-300)

    if sigma == 0.0:
        Phi = scph.precise_integration(A, 0.1)
        orth = float(np.linalg.norm(Phi.T @ Qd @ Phi - Qd) / np.linalg.norm(Qd))
        u = rng.standard_normal(m.n)
        W0 = 0.5 * float(u @ (Qd @ u))
        drift = 0.0
        for _ in range(200):
            u = Phi @ u
            drift = max(drift, abs(0.5 * float(u @ (Qd @ u)) / W0 - 1.0))
        print(f"  N = {N:3d}, sigma = {sigma:<5}: assembly match = {asm:.1e},  "
              f"||J + J^T||/||J|| = {skew:.1e},  identity = {ident:.1e}")
        print(f"                        eig(A^T Q + Q A) in [{lam_min:+.2e}, "
              f"{lam_max:+.2e}] = 0 to roundoff,  Q-orthogonality of "
              f"exp(A dt) = {orth:.1e},  energy drift(200 steps) = {drift:.1e}")
    else:
        Phi = scph.precise_integration(A, 0.1)
        u = rng.standard_normal(m.n)
        W = [0.5 * float(u @ (Qd @ u))]
        for _ in range(200):
            u = Phi @ u
            W.append(0.5 * float(u @ (Qd @ u)))
        dW = np.diff(W)
        print(f"  N = {N:3d}, sigma = {sigma:<5}: assembly match = {asm:.1e},  "
              f"||J + J^T||/||J|| = {skew:.1e},  identity = {ident:.1e}")
        print(f"                        eig(A^T Q + Q A) in [{lam_min:+.2e}, "
              f"{lam_max:+.2e}]  (lam_max/scale = {lam_max/scale_sym:+.1e} <= 0),  "
              f"min/max dW = {dW.min():+.3e} / {dW.max():+.3e} (both <= 0)")
print("  => material weights (non-uniform eps, mu, London weight) change Q")
print("     only; they cannot break the port-Hamiltonian structure")

print()
print("=" * 78)
print("27) Boundary port (v, y) = (E_y|wall, -h_0/dz): power balance")
print("=" * 78)
m = scph.SuperconductingModel(N=48, L=1.0, omega_p=6.0, sigma=0.0)
md = scph.SuperconductingModel(N=48, L=1.0, omega_p=6.0, sigma=0.05,
                               driven=True, omega_d=2.0)
rng = np.random.default_rng(11)
u = rng.standard_normal(md.n_aug) * 0.3
for v in (1.0, -1.3, 0.0):
    u[md.id_] = v
    dW = float(u @ (md.M @ (md.A @ u)))
    diss = md.sigma * float(np.sum(u[md.ie] ** 2))
    port = md.port_power(v, u)
    scale = abs(dW) + diss + abs(port) + 1e-300
    print(f"  v = {v:+5.2f}: |dW/dt + sigma|e|^2 - v y| / scale = "
          f"{md.port_balance_residual(u, v)/scale:.3e}   "
          f"(y = {md.port_output(u):+.6e}, dz*y = {md.port_flux_variable(u):+.3e})")

# frequency domain: complex steady-state response to v = cos(omega_d t),
# which gives the *time-averaged* power balance <v y> = sigma <|e|^2>
print("  frequency domain (v = cos(2t), complex amplitude V = 1):")
m_lossy = scph.SuperconductingModel(N=48, L=1.0, omega_p=6.0, sigma=0.05)
for mm_, tag in ((m, "lossless"), (m_lossy, "lossy sigma = 0.05")):
    sol = np.linalg.solve(1j * 2.0 * np.eye(mm_.n_aug) - mm_.A, mm_.port_vector())
    p_avg = 0.5 * float(np.real(mm_.port_vector() @ (mm_.M @ sol)))
    d_avg = 0.5 * mm_.sigma * float(np.sum(np.abs(sol[mm_.ie]) ** 2))
    print(f"    {tag:19s}: <v y> = {p_avg:+.12e},  sigma<|e|^2> = {d_avg:+.12e},"
          f"  |diff| = {abs(p_avg - d_avg):.2e}"
          + ("" if abs(p_avg) + abs(d_avg) > 0 else "  (both vanish: purely reactive)"))
print("  => (v, y) is the conjugate port pair of the driven wall: the field")
print("     exchanges exactly the Poynting power v y with the boundary")

# =========================================================================
# 28-31: M-Krylov, non-uniform materials, gauge TDGL
# =========================================================================

print()
print("=" * 78)
print("28) M-inner-product Krylov: exactly non-expansive in the energy metric")
print("=" * 78)
Nx = Ny = 16
X, Y = np.meshgrid((np.arange(Nx) + 0.5) / Nx, (np.arange(Ny) + 0.5) / Ny,
                   indexing="ij")
sig_field = 0.05 + 0.3 * np.abs(np.sin(2 * np.pi * X) * np.cos(2 * np.pi * Y))
wp_field = 2.0 + 6.0 * np.abs(np.cos(2 * np.pi * X) * np.sin(2 * np.pi * Y))
m0 = scph.MaxwellModelND(2, (Nx, Ny), sigma_field=np.zeros((Nx, Ny)),
                          omega_p_field=wp_field)
rng = np.random.default_rng(3)
u0 = rng.standard_normal(m0.n)
u0 /= np.sqrt(2.0 * float(u0 @ (m0.M @ u0)))
W0 = m0.energy(u0)
dt = 0.02
print("  (a) sigma = 0 (A exactly M-skew): relative W-drift of one step")
for tol in (1e-4, 1e-6, 1e-8, 1e-12):
    kM = scph.KrylovExponential(m0.A, dt, tol=tol, metric=m0.metric_diag)
    kE = scph.KrylovExponential(m0.A, dt, tol=tol)
    dM = abs(m0.energy(kM.apply(u0)) / W0 - 1.0)
    dE = abs(m0.energy(kE.apply(u0)) / W0 - 1.0)
    print(f"      tol = {tol:7.0e}:  M-Krylov {dM:9.2e}   Euclidean {dE:9.2e}"
          f"   (m = {kM.m_last}/{kE.m_last})")
print("      => the M-realization preserves W to round-off *regardless of tol*;")
print("         the Euclidean one drifts at O(tol) whenever M != I")
md = scph.MaxwellModelND(2, (Nx, Ny), sigma_field=0.0005 + 0.001 * np.abs(
    np.sin(2 * np.pi * X) * np.cos(2 * np.pi * Y)), omega_p_field=wp_field)
u = u0.copy()
kM = scph.KrylovExponential(md.A, dt, tol=1e-4, metric=md.metric_diag)
kE = scph.KrylovExponential(md.A, dt, tol=1e-4)
uE = u0.copy()
# exact reference trajectory from the dense metric (similarity) propagator
Pref = scph.ExponentialPropagator(md.A, dt, backend="dense",
                                  metric=md.metric_diag)
uR = u0.copy()
maxdW = -np.inf
dM = dE = 0.0
for _ in range(200):
    Wprev = md.energy(u)
    u = kM.apply(u)
    uE = kE.apply(uE)
    uR = Pref.apply(uR)
    WR = md.energy(uR)
    maxdW = max(maxdW, md.energy(u) - Wprev)
    dM = max(dM, abs(md.energy(u) - WR) / WR)
    dE = max(dE, abs(md.energy(uE) - WR) / WR)
print("  (b) weakly dissipative field (sigma ~ 1e-3), tol = 1e-4, 200 steps,")
print("      reference = dense exact propagator in the energy metric:")
print(f"      M-Krylov : max step-to-step energy increase = {maxdW:+.3e}"
      f"  (<= 0 up to round-off; certified at every tolerance)")
print(f"      M-Krylov trajectory error max|W - W_exact|/W = {dM:.2e}"
      f"   (round-off floor)")
print(f"      Euclidean trajectory error max|W - W_exact|/W = {dE:.2e}"
      f"   (O(tol): no energy certificate when M != I)")
P = scph.ExponentialPropagator(m0.A, dt, backend="dense",
                               metric=m0.metric_diag)
uD = P.apply(u0)
kM = scph.KrylovExponential(m0.A, dt, tol=1e-12, metric=m0.metric_diag)
print(f"  (c) M-Krylov (tol 1e-12) vs dense metric propagator: rel.err = "
      f"{sla.norm(kM.apply(u0) - uD) / sla.norm(uD):.2e}")

print()
print("=" * 78)
print("29) Non-uniform 2D two-fluid: structure + relaxation to the London BVP")
print("=" * 78)
m = scph.MaxwellModelND(2, (Nx, Ny), sigma_field=sig_field,
                        omega_p_field=wp_field)
print(f"  (a) ||A^T M + M A + 2 Sigma||_F with non-uniform sigma(x,y), "
      f"omega_p(x,y): {m.dissipation_residual():.3e}  (n = {m.n})")
# relaxation: sigma large enough for a fast decay to the kernel
sig_big = np.full((Nx, Ny), 1.0)
mR = scph.MaxwellModelND(2, (Nx, Ny), sigma_field=sig_big,
                         omega_p_field=wp_field)
h0 = np.exp(-((X - 0.5) ** 2 + (Y - 0.5) ** 2) / 0.02).ravel()
u0r = np.concatenate([np.zeros(2 * Nx * Ny), h0, np.zeros(2 * Nx * Ny)])
K = scph.ExponentialPropagator(mR.A, 0.1, backend="krylov", tol=1e-12,
                               metric=mR.metric_diag)
u = u0r.copy()
for _ in range(400):
    u = K.apply(u)
print(f"  (b) after t = 40 (sigma = 1, decay e^-20): kernel residual "
      f"||e|| + ||J - C h|| = {mR.kernel_residual(u):.3e}")
hdir = mR.london_projection(h0.reshape(Nx, Ny))
hfin = u[2 * Nx * Ny:3 * Nx * Ny]
print(f"  (c) relaxed h vs direct sparse solve of the discrete London"
      f" equation\n      (I + C^T lambda^2 C) h* = h0:  "
      f"||h - h*||/||h*|| = "
      f"{float(np.linalg.norm(hfin - hdir)) / float(np.linalg.norm(hdir)):.3e}")
print("  => the dynamics lands on the static London manifold, and the")
print("     trapped-flux profile is the screened projection of the data")

print()
print("=" * 78)
print("30) Gauge-invariant TDGL: exact gauge invariance, covariance, topology")
print("=" * 78)
g = scph.GaugeTDGL2D(32, 32, xi=4 / 32, kappa=0.3)
psi0 = g.initial_vortex([(0.5, 0.5, 1)])
chi = 2 * np.pi * np.random.default_rng(1).random((32, 32))
psi1, tx, ty = g.gauge_transform(psi0, chi)
g1 = scph.GaugeTDGL2D(32, 32, xi=4 / 32, kappa=0.3)
g1.theta_x, g1.theta_y = tx.copy(), ty.copy()
g1._lu = None
print(f"  (a) |W(e^iX psi, theta + dX) - W(psi, theta)| / W = "
      f"{abs(g1.energy(psi1) - g.energy(psi0)) / g.energy(psi0):.2e}")
ua = g.step(psi0, 0.05)
ub = g1.step(psi1, 0.05)
print(f"  (b) gauge covariance of one Strang step: "
      f"||Phi(psi') - e^iX Phi(psi)|| / ||Phi(psi)|| = "
      f"{float(np.linalg.norm(ub - np.exp(1j * chi) * ua)) / float(np.linalg.norm(ua)):.2e}")
L = g._diffusion_matrix()
print(f"  (c) covariant Laplacian Hermitian residual: "
      f"{abs(L.conj().T - L).max():.2e}")
print("  (d) closed-form CN logistic step, x = |psi|^2, for every dt:")
xr = np.linspace(0.0, 1.0, 200)
for dt in (1e-3, 1.0, 1e3, 1e6):
    # psi amplitude = sqrt(x) so that x = |psi|^2 sweeps [0, 1]
    psi = np.sqrt(xr)[None, :] * np.ones((1, 200), dtype=complex)
    out = g.potential_step(psi, dt).reshape(200)
    x1 = np.abs(out) ** 2
    print(f"      dt = {dt:8.0e}: x in [{x1.min():.4f}, {x1.max():.6f}], "
          f"monotone towards 1: {bool(np.all(x1 >= xr - 1e-15))}, "
          f"V decreasing: {bool(np.all((1 - x1) ** 2 <= (1 - xr) ** 2 + 1e-15))}")
psi = psi0.copy()
w0 = g.loop_winding(psi, 8, 24, 8, 24)
Ws = [g.energy(psi)]
for _ in range(300):
    psi = g.step(psi, 0.05)
    Ws.append(g.energy(psi))
Ws = np.array(Ws)
print(f"  (e) single vortex, 300 steps: loop winding {w0:.6f} -> "
      f"{g.loop_winding(psi, 8, 24, 8, 24):.6f} (conserved), "
      f"W monotone: max dW = {np.diff(Ws).max():+.2e} <= 0, "
      f"core min|psi| = {np.abs(psi).min():.3f}")

print()
print("=" * 78)
print("31) Non-uniform 3D dissipation, matrix-free, n = 2.8e5")
print("=" * 78)
N3 = 36
x = (np.arange(N3) + 0.5) / N3
X3, Y3, Z3 = np.meshgrid(x, x, x, indexing="ij")
r3 = np.sqrt((X3 - 0.5) ** 2 + (Y3 - 0.5) ** 2 + (Z3 - 0.5) ** 2)
sig3d = np.where(r3 < 0.3, 2.0, 0.05)
mf3 = scph.MaxwellModelND(3, (N3, N3, N3), sigma_field=sig3d,
                          matrix_free=True)
rng = np.random.default_rng(5)
u = rng.standard_normal(mf3.n)
print(f"  n = {mf3.n}: |u^T A u + u_E^T Sigma u_E| / (||u|| ||Au||) = "
      f"{mf3.op.dissipative_quadratic(u):.2e}   (no matrix formed)")
K3 = scph.KrylovExponential(mf3.op.matvec, 0.002, tol=1e-10, n=mf3.n)
u0 = u / np.linalg.norm(u)
v = K3.apply(u0)
print(f"  Krylov step (tol 1e-10, m = {K3.m_last}): "
      f"W(u1)/W(u0) = {0.5 * float(v @ v):.12f} <= 1 (exactly non-expansive)")