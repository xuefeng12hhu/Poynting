"""Schematic of the 1D driven-boundary Meissner screening test case.

Setup of Section 4.4 (``sec:exp4``): a London superconductor
(``omega_p = 10``, ``lambda_L = 1/omega_p = 0.1``) on ``z in [0, 1]``,
driven at ``z = 0`` by a harmonic boundary port
``E_y(0, t) = cos(omega_d t)`` with ``omega_d = 2`` and closed by a PEC
wall at ``z = 1``; a lock-in detection of the steady state recovers the
evanescent decay length ``1/kappa``, ``kappa = sqrt(omega_p^2 - omega_d^2)``.

Outputs ``figures/fig_setup_1d.{png,pdf}``; the PNG is written at
600 dpi (high resolution) and the PDF is a vector file, so the figure
can be included either way without loss.

Run with:  python code/make_setup_1d.py
"""
import os

import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle, FancyArrowPatch

HERE = os.path.dirname(os.path.abspath(__file__))
FIG = os.path.join(os.path.dirname(HERE), "figures")
os.makedirs(FIG, exist_ok=True)

plt.rcParams.update({
    "font.size": 9, "axes.labelsize": 9, "legend.fontsize": 8,
    "xtick.labelsize": 8, "ytick.labelsize": 8,
    "savefig.bbox": "tight", "axes.grid": False,
    "legend.frameon": False, "lines.linewidth": 1.3, "lines.markersize": 4.5,
})

# ---- physical parameters of the test case (Section 4.4) --------------------
WP = 10.0                 # plasma frequency (superconductor)
LAM = 1.0 / WP            # London penetration depth
WD = 2.0                  # drive frequency
KAPPA = np.sqrt(WP ** 2 - WD ** 2)   # evanescent wavenumber, ~ 9.798

SC_FILL = "#dce9f5"
SC_EDGE = "#3f5f88"
CURVE = "#0b3d91"
PORT = "#c62828"


def save_hd(fig, name):
    """Save a high-resolution PNG (600 dpi) and a vector PDF."""
    fig.savefig(os.path.join(FIG, f"{name}.png"), dpi=600)
    fig.savefig(os.path.join(FIG, f"{name}.pdf"))
    plt.close(fig)
    print(f"  [figure] figures/{name}.png  (600 dpi)")
    print(f"  [figure] figures/{name}.pdf  (vector)")


def main():
    fig, ax = plt.subplots(figsize=(4.8, 2.15))
    ax.set_axis_off()
    ax.set_xlim(-0.44, 1.28)
    ax.set_ylim(-0.62, 1.80)

    # ---- the superconducting domain ---------------------------------------
    ax.add_patch(Rectangle((0.0, 0.0), 1.0, 1.0, facecolor=SC_FILL,
                           edgecolor=SC_EDGE, linewidth=1.2, zorder=1))
    # sub-lambda layer just inside the driven wall (London screening layer)
    ax.add_patch(Rectangle((0.0, 0.0), LAM, 1.0, facecolor="#b9d2ea",
                           edgecolor="none", zorder=2))
    ax.annotate("", xy=(LAM, 1.10), xytext=(0.0, 1.10),
                arrowprops=dict(arrowstyle="<->", color=PORT, lw=1.0))
    ax.text(LAM + 0.03, 1.10, r"$\lambda_L=0.1$", color=PORT, fontsize=8,
            ha="left", va="center")

    # ---- driven boundary port at z = 0 ------------------------------------
    ax.plot([0.0, 0.0], [0.0, 1.0], color=PORT, lw=2.4, zorder=4)
    zs = np.linspace(-0.32, -0.06, 160)
    ax.plot(zs, 0.55 + 0.26 * np.cos(2.0 * np.pi * zs / 0.14), color=PORT,
            lw=1.1, zorder=3)
    ax.add_patch(FancyArrowPatch((-0.05, 0.55), (0.06, 0.55),
                                 arrowstyle="-|>", mutation_scale=13,
                                 color=PORT, lw=1.6, zorder=5))
    ax.text(-0.19, 1.50, "driven port", color=PORT, fontsize=8.5,
            ha="center", va="top")
    ax.text(-0.22, 0.26, r"$E_y(0,t)=\cos(\omega_d t)$", color=PORT,
            fontsize=8, ha="center", va="top")
    ax.text(-0.22, 0.13, r"$\omega_d=2$", color=PORT, fontsize=8,
            ha="center", va="top")

    # ---- PEC wall at z = 1 ------------------------------------------------
    ax.plot([1.0, 1.0], [0.0, 1.0], color="k", lw=2.4, zorder=4)
    ax.add_patch(Rectangle((1.0, 0.0), 0.075, 1.0, facecolor="#c9c9c9",
                           edgecolor="k", linewidth=0.8, hatch="////", zorder=3))
    ax.text(1.09, 0.5, "PEC", rotation=90, fontsize=8.5, ha="left",
            va="center")

    # ---- steady-state evanescent profile ----------------------------------
    z = np.linspace(0.0, 1.0, 600)
    prof = np.exp(-KAPPA * z)          # |H_x(z)| / |H_x(0)|
    ax.plot(z, 0.5 + 0.40 * prof, color=CURVE, lw=1.6, zorder=6)
    ax.plot([0.0, 1.0], [0.5, 0.5], color="#888888", lw=0.6, ls=":", zorder=2)
    ax.annotate(r"steady state $\propto e^{-\kappa z}$" "\n"
                r"$1/\kappa=0.102$",
                xy=(0.14, 0.5 + 0.40 * np.exp(-KAPPA * 0.14)),
                xytext=(0.42, 0.74), fontsize=8, color=CURVE,
                arrowprops=dict(arrowstyle="-|>", color=CURVE, lw=0.9,
                                connectionstyle="arc3,rad=-0.25"))
    ax.text(0.52, 0.30, r"superconductor $\omega_p=10$", fontsize=8.5,
            color=SC_EDGE, ha="center", va="center")
    ax.text(0.52, 0.14, r"$\lambda_L=1/\omega_p=0.1$", fontsize=8,
            color=SC_EDGE, ha="center", va="center")

    # ---- z axis ------------------------------------------------------------
    ax.annotate("", xy=(1.0, -0.26), xytext=(0.0, -0.26),
                arrowprops=dict(arrowstyle="-|>", color="k", lw=1.0))
    ax.text(0.5, -0.36, r"$z$", fontsize=9, ha="center", va="top")
    ax.text(0.0, -0.30, r"$0$", fontsize=8, ha="center", va="top")
    ax.text(1.0, -0.30, r"$1$", fontsize=8, ha="center", va="top")

    fig.tight_layout(pad=0.2)
    save_hd(fig, "fig_setup_1d")


if __name__ == "__main__":
    main()
