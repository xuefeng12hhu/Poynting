"""Cost / accuracy / structure benchmark of the exponential propagators.

Compares, on the non-uniform 2D two-fluid model (M != I):

  1. M-Krylov        (scph.KrylovExponential, metric = M)
  2. Euclidean Arnoldi (same kernel, metric = None)
  3. SciPy expm_multiply (the library Krylov action of the matrix exp)
  4. dense PI-M      (scph.ExponentialPropagator, dense, metric = M)

at n = 2880 (24 x 24) with a dense machine-precision reference, and at
n = 46080 (96 x 96, the E11 size) without a dense reference.

Usage:  python bench_compare.py   (writes results/bench_compare.log)
"""
import sys
import time

import numpy as np
import scipy.linalg as sla
import scipy.sparse.linalg as spla

import scph

REPEAT_SMALL = 5
REPEAT_LARGE = 3


def smooth_u0(rng, n):
    u0 = rng.standard_normal(n)
    return u0 / np.linalg.norm(u0)


def bench_a(nx, dt, nsteps, tol):
    """n = 5 nx^2 model, dense reference available."""
    Ny = nx
    x = np.linspace(0.0, 1.0, nx, endpoint=False)
    y = np.linspace(0.0, 1.0, Ny, endpoint=False)
    X, Y = np.meshgrid(x, y, indexing="ij")
    wp = 4.0 + 26.0 * np.abs(np.sin(np.pi * X) * np.cos(np.pi * Y))
    md = scph.MaxwellModelND(2, (nx, Ny), omega_p_field=wp)
    n = md.n
    S = np.sqrt(md.metric_diag)
    B = md.A.multiply(S[:, None]).multiply(S[None, :] ** -1).toarray()
    # B = S A S^{-1} (diagonal similarity)
    Bt = (md.A.toarray() * S[:, None]) / S[None, :]
    assert np.linalg.norm(B - Bt) / np.linalg.norm(B) < 1e-13
    expB = sla.expm(B * dt)

    rng = np.random.default_rng(11)
    u0 = smooth_u0(rng, n)

    # dense machine-precision reference trajectory (in the metric)
    uref = u0.copy()
    for _ in range(nsteps):
        uref = (expB @ (S * uref)) / S

    W0 = md.energy(u0)

    def run(krylov_metric):
        K = scph.KrylovExponential(md.A, dt, tol=tol,
                                   metric=krylov_metric)
        u = u0.copy()
        t0 = time.perf_counter()
        for _ in range(nsteps):
            u = K.apply(u)
        t1 = time.perf_counter()
        return u, K.m_last, K.matvecs, t1 - t0

    best = {}

    # 1. M-Krylov
    for _ in range(REPEAT_SMALL):
        u, m, mv, wall = run(md.metric_diag)
        best.setdefault("M-Krylov", []).append((u, m, mv, wall))
    uM, mM, mvM, wM = min(best["M-Krylov"], key=lambda r: r[3])

    # 2. Euclidean Arnoldi
    for _ in range(REPEAT_SMALL):
        u, m, mv, wall = run(None)
        best.setdefault("Euclid", []).append((u, m, mv, wall))
    uE, mE, mvE, wE = min(best["Euclid"], key=lambda r: r[3])

    # 3. SciPy expm_multiply (library Krylov action, Euclidean)
    def run_lib():
        u = u0.copy()
        t0 = time.perf_counter()
        for _ in range(nsteps):
            u = spla.expm_multiply(md.A, u, 0.0, dt, num=2)[-1]
        t1 = time.perf_counter()
        return u, t1 - t0

    uL, wL = min((run_lib() for _ in range(REPEAT_SMALL)),
                 key=lambda r: r[1])

    # 4. dense PI-M (build + apply)
    t0 = time.perf_counter()
    P = scph.ExponentialPropagator(md.A, dt, backend="dense",
                                   metric=md.metric_diag)
    t1 = time.perf_counter()
    build = t1 - t0
    uD = u0.copy()
    t0 = time.perf_counter()
    for _ in range(nsteps):
        uD = P.apply(uD)
    t1 = time.perf_counter()
    wD = t1 - t0

    def report(tag, u, wall, extra=""):
        err = np.linalg.norm(u - uref) / np.linalg.norm(uref)
        drift = max(abs(md.energy(u) / W0 - 1.0), 0.0)
        # per-step drift along the *trajectory* (re-run quickly, 1 pass)
        print(f"  {tag:22s}  wall(10 steps) = {wall:8.3f} s"
              f"   err(T) = {err:8.2e}   |dW|/W = {drift:8.2e}  {extra}")
        return err, drift

    print(f"model: 2D two-fluid, {nx}x{Ny}, n = {n}, dt = {dt}, "
          f"nsteps = {nsteps}, tol = {tol:.0e}, sigma = 0")
    print(f"  dense reference: expm(S A S^-1 dt), machine precision")
    report("M-Krylov", uM, wM, f"(m = {mM:.0f}, matvecs = {mvM:.0f})")
    report("Euclidean Arnoldi", uE, wE, f"(m = {mE:.0f}, matvecs = {mvE:.0f})")
    report("SciPy expm_multiply", uL, wL, "(library default)")
    report("dense PI-M", uD, wD + build,
           f"(build {build:.3f} s + apply {wD:.3f} s)")
    print()
    return dict(n=n, tol=tol, dt=dt, nsteps=nsteps)


def bench_b(nx, dt, tol):
    """n = 5 * 96^2 = 46080: M-Krylov vs library, no dense reference."""
    Ny = nx
    x = np.linspace(0.0, 1.0, nx, endpoint=False)
    y = np.linspace(0.0, 1.0, Ny, endpoint=False)
    X, Y = np.meshgrid(x, y, indexing="ij")
    wp = 4.0 + 26.0 * np.abs(np.sin(np.pi * X) * np.cos(np.pi * Y))
    md = scph.MaxwellModelND(2, (nx, Ny), omega_p_field=wp)
    n = md.n
    rng = np.random.default_rng(12)
    u0 = smooth_u0(rng, n)

    # reference: M-Krylov at tol 1e-13
    Kref = scph.KrylovExponential(md.A, dt, tol=1e-13,
                                  metric=md.metric_diag)
    uref = Kref.apply(u0)

    rows = []

    K = scph.KrylovExponential(md.A, dt, tol=tol, metric=md.metric_diag)
    tbest = np.inf
    for _ in range(REPEAT_LARGE):
        t0 = time.perf_counter()
        uM = K.apply(u0)
        t1 = time.perf_counter()
        tbest = min(tbest, t1 - t0)
    rows.append(("M-Krylov", tbest, K.m_last, K.matvecs,
                 np.linalg.norm(uM - uref) / np.linalg.norm(uref)))

    KE = scph.KrylovExponential(md.A, dt, tol=tol)
    tbest = np.inf
    for _ in range(REPEAT_LARGE):
        t0 = time.perf_counter()
        uE = KE.apply(u0)
        t1 = time.perf_counter()
        tbest = min(tbest, t1 - t0)
    rows.append(("Euclidean Arnoldi", tbest, KE.m_last, KE.matvecs,
                 np.linalg.norm(uE - uref) / np.linalg.norm(uref)))

    tbest = np.inf
    for _ in range(REPEAT_LARGE):
        t0 = time.perf_counter()
        uL = spla.expm_multiply(md.A, u0, 0.0, dt, num=2)[-1]
        t1 = time.perf_counter()
        tbest = min(tbest, t1 - t0)
    rows.append(("SciPy expm_multiply", tbest, None, None,
                 np.linalg.norm(uL - uref) / np.linalg.norm(uref)))

    print(f"model: 2D two-fluid, {nx}x{Ny}, n = {n}, one step dt = {dt}, "
          f"tol = {tol:.0e} (reference: M-Krylov tol 1e-13)")
    for tag, wall, m, mv, err in rows:
        ms = f"m = {m:.0f}, matvecs = {mv:.0f}" if m else "library default"
        print(f"  {tag:22s}  wall(1 step) = {wall * 1e3:9.1f} ms"
              f"   err = {err:8.2e}   ({ms})")


if __name__ == "__main__":
    out = []
    a = bench_a(24, 0.1, 10, 1e-4)
    print()
    a = bench_a(24, 0.1, 10, 1e-12)
    print()
    bench_b(96, 0.1, 1e-10)
    sys.exit(0)
